# Engineering Audit — The Product Field

Audit date: 2026-10-20 · Scope: whole repository (214 files, 17.1 MB when received) · Constraint: static, client-side, GitHub Pages only.

**How to read this.** Each finding says what was *measured* and what was *inferred*. Measurements come from a sandbox with **one CPU core, no internet, software rendering, Chromium only**. Nothing was verified on a real iPhone, Android phone, or GPU-equipped desktop (see [Measurement limits](#measurement-limits)).

## What went wrong in the first pass (and what was done about it)
The first version of this work was reviewed and found wanting. Honest account:

| Problem | Cause | Resolution |
|---|---|---|
| 85 generated `chapter-*.html` pages | I proposed them as an SEO enhancement; they cluttered the repo and changed every chapter URL | **Removed completely.** Chapters are `read.html?chapter=…` again. The trade-off is stated in §2 (UX-10). |
| **Reader outline text overlapping ("side scroll overwritten")** | My touch-target rule (`display:flex; min-height:24px`) let entries *shrink* inside the fixed-height scrolling column — 38 of 52 on one chapter | Outline rebuilt (§2). New tests check visible overlap and were **proven to fail on the old bug** (47 of 52 squashed). |
| Particle design "not up to the mark" | I kept the original wire-diagram (lines between dots, dashed ellipses): busy and technical | Replaced by a flow field (§4). I judged every iteration from screenshots, not just metrics. |
| Automated checks missed all of the above | My probe measured box sizes and skipped `position:fixed`; no check looked at text overlap or at what was on screen | Probe and tests extended; screenshots reviewed by eye on desktop, tablet-width and phone, dark and light. |
| Over-claiming | Earlier notes said "axe 6 → 0" and "CLS fixed" before they were true for the final code | Every number below was re-measured on the final code. |

Contents: [1 Architecture](#1-architecture) · [2 UX](#2-ux-audit) · [3 Accessibility](#3-accessibility-audit) · [4 Performance and particles](#4-performance-and-the-particle-field) · [5 Responsiveness](#5-responsiveness) · [6 Technical debt](#6-technical-debt) · [7 YouTube audio](#7-youtube-audio-investigation) · [8 Issue register](#8-issue-register) · [9 Validation](#9-validation) · [10 Future work](#10-future-work)

---

> **Update (latest):** the particle field described in §4 was replaced by **Reveal** (see `IMPLEMENTATION_LOG.md` → R-1) and the original icons were restored, so the benchmark and icon notes below describe the earlier flow-field version. Reveal was checked on desktop and phone in both themes, 67 functional checks pass, and a 140-click stress test stayed responsive; the Lighthouse and benchmark tables were **not** re-measured for it.

## 1. Architecture
Static multi-page site (`index`, `book`, `read`, `search`, `study`, `resource`, `privacy`, `404`) with one stylesheet and a `window.FieldSite` namespace. No framework, no bundler. Markdown → `build_site_data.py` → generated data (`library-data.js`, `chapters/*.content.js`, `resource-data.js`, `search-index.js` 1.48 MB / 301 KB brotli, `practice-data.js`). The build is the **original, unchanged** script; rebuilds are deterministic (verified byte-identical).

GitHub Pages constraints that shaped the work: no configurable headers (no CSP/cache control; `max-age=600`), static only (no SSR), 1 GB soft limit, `404.html` honoured at the root.

| Changed area | Why | Depended on by | What could break |
|---|---|---|---|
| `particles.js` (rewritten) | Visual identity | every page (script tag); `book.js`/`reader.js` call `FieldParticles.setVolume` | Look, scroll/pointer feel, battery |
| `audio.js` (new; was inside `reader.js`) | Chapter audio | `read.html`, `audio-links.js` | Playback |
| Reader outline (CSS + `makeOutline`) | Navigation | `read.html` | Section navigation |
| Fonts (self-hosted) | Typography | first paint everywhere | Layout shift on swap |

## 2. UX audit
| ID | Finding | Status |
|---|---|---|
| UX-1 | Hero volume rows looked clickable but were `<div>`s | **Fixed** — real links with hover/focus |
| UX-2 | Phones (≤ 480 px) had no route to Search from a chapter | **Fixed** — short "Search" kept in the header; footer nav on every page |
| UX-3 | Reader text size reset on every chapter | **Fixed** (persisted) |
| UX-4 | Reading progress saved but never offered back | **Fixed** — "Resume at N %" |
| UX-5 | No reading time | **Fixed** (byline) |
| UX-6 | Particles confined to each hero, disconnected from the page | **Fixed** — one field behind every page, redesigned (§4) |
| UX-7 | Decorative Unicode glyphs rendered inconsistently per OS (`▶` can become an emoji) | **Fixed** — removed (see log, C-06) |
| UX-8 | YouTube embeds without privacy disclosure | **Fixed** — `privacy.html` (needs owner review) |
| UX-9 | No 404 page; no link-preview metadata | **Fixed** — `404.html`, Open Graph tags + image |
| UX-10 | Chapter text is JS-rendered, so crawlers and link-preview bots see "Loading chapter…" | **Not addressed, by decision.** Per-chapter static pages were tried and rejected (see above). The home page has proper metadata; chapters do not. |
| UX-11 | Volume 1 and 2 repeat the same chapters; search listed both | **Fixed non-destructively** — identical hits collapse into one result with "Also in …"; chapters with the same title but different text stay separate |
| UX-12 | *(my regression)* Outline entries overlapped each other; the column trapped wheel/touch scrolling | **Fixed.** One line per entry (full title on hover), entries cannot shrink, only the current section's sub-headings are open (the list fits with no inner scrollbar), no `overscroll-behavior: contain`. Phone: solid 51 px bar. |
| UX-13 | Hero text and every section below it started at different left edges on wide screens (x ≈ 77 vs 135) | **Fixed** — all sections share the hero's edge (x = 80 at 1440 px, verified on 5 pages) |
| UX-14 | Header was 88 % opaque; reading text ghosted through it | **Fixed** (96 %) |
| UX-15 | "Start path" looked like plain text | **Fixed** — bordered action |
| UX-16 | *(my regression)* Header breadcrumb hard-clipped with no ellipsis | **Fixed** |
| UX-17 | Light mode: the field barely reached the page body, and the body had no atmosphere under it | **Fixed** — field through the whole page at a calmer strength, extra colour washes, reading column kept clean |

## 3. Accessibility audit
Baseline **axe-core: 6 distinct violations**; final: **0** (11 pages × both themes × 390/1440 px).

| Rule | Cause | Fix |
|---|---|---|
| `label-content-name-mismatch` (serious) | `A−`/`A+`/Bookmark names didn't contain their visible text | Names contain the text; bookmark = static label + `aria-pressed` |
| `scrollable-region-focusable` (serious) | Wide code/tables scroll but weren't focusable | `tabindex="0"` only when scrollable (re-checked on resize and font swap) |
| `color-contrast` (serious) | Light accent `#00725f` is 4.14–4.40:1 on tinted rows (an old changelog claimed ≥ 4.67) | `#006b59` (≥ 4.55); featured-row count uses `--muted` |
| `landmark-unique` | Two unlabelled `<aside>`s | Labelled |
| `heading-order` | Chapter text jumps h2 → h4; three chapters contain their own `<h1>` | Runtime `aria-level` repair; body `<h1>` counts as level 2 |
| `empty-table-header` | Matrix tables with an empty corner cell | Screen-reader label |

Other changes: decorative canvas hidden from assistive tech and out of the tab order; live regions moved from result lists to status lines; `<nav>` landmarks; labels ≥ 11 px (86 → 0 per page); 24 px minimum hit areas everywhere and 44 px on touch (header controls 40 px and the phone chip bar 32–36 px, deliberately compact). Reduced motion: one still image, no loop.

## 4. Performance and the particle field
**Quick wins:** fonts self-hosted (no render-blocking cross-origin CSS; 4 files preloaded ≈ 94 KB), favicon 23 KB → 6.4 KB (alpha-composited mean Δ ≈ 1/255), zero YouTube requests until Play, no layout reads in input handlers. Wire sizes were already small (home JS+CSS ≈ 29 KB brotli).

### The particle field (v3)
A *field*, literally: fine particles carried on a smooth, divergence-free current (three travelling waves), drawn with fading curved tails.
- Three depth layers (size, brightness, speed, scroll and cursor parallax); three **eddies** in the hero, one per volume (mint / blue / amber) with a soft glowing core; hovering or focusing a volume row draws its eddy in; volume and chapter pages bring their own forward.
- Cursor parts the field with a small swirl and a soft light follows; click sends a ripple. Quiet where people read: behind the hero copy, and on chapter pages the field lives in the margins while the reading column stays clean (`columnMask`).
- **Light mode** gets its own treatment: ambient strokes are halved (pale paper shows strokes far more than a dark page), and the light page background carries four soft colour washes (blue top right, mint left, amber lower right, blue lower left) so the field has atmosphere to move through across the whole page, not just the hero.
- **One canvas** (fade + strokes, ≤ 45 strokes a frame); every soft light is a CSS layer moved by `transform`, inside one clipped viewport-sized container (it cannot widen the page or allow sideways panning).
- Governor: full → balanced → lite (lower internal resolution, fewer particles, then the cursor/core lights are hidden); never steps back up. Boots after load on an idle callback and fades in.
- ≈ 530 lines (the old engine was 830). Engine JS ≈ 0.1–0.3 ms/frame.

### Particle benchmark
Chromium, CPU throttle via CDP, 4 s idle + 4 s with pointer activity. **Software rasterisation and software compositing on one core; ±4 fps run-to-run noise.**

| Viewport / CPU | Original idle / active fps | Final idle / active fps (tier reached) |
|---|---|---|
| Desktop 1440, 1× | 59.8 / 59.0 | 47.0 / 42.3 (lite) |
| Desktop 1440, 4× | 35.5 / 28.6 | 24.8 / 21.7 (lite) |
| Mobile 390, 1× | 60.0 / 57.8 | **60.0 / 60.0** (full) |
| Mobile 390, 4× | 53.8 / 49.3 | **59.5 / 59.3** (full) |

Main-thread busy: desktop 1× 64 / 75 % → 12 / 20 %; mobile 1× 44 / 47 % → 21 / 22 %.

**Honest reading:** on phones the new field is as smooth or smoother than the original. **On desktop it is slower than the original in this sandbox**, where the browser has no GPU: main-thread load is low (the code is not the bottleneck) but the *software compositor* has to blend several large translucent layers every frame. A real GPU does that essentially for free, but that is **unverified**. Mitigations in place: modest light sizes, lights hidden in lower tiers, governor. If a real desktop shows stutter, set the starting tier to `balanced` (one line, `initialTier()` in `particles.js`).

### Lighthouse (GitHub-Pages-like server, Lighthouse simulated mobile throttling)
Lighthouse mobile varies by about ±6 points run to run here, so means of three runs are shown. The original site's baseline is optimistic (its Google Fonts requests fail instantly offline).

| Page | Original | Final |
|---|---|---|
| Mobile — home | 93, 89, 81 (mean 87.7) | 87, 94, 94 (**mean 91.7**) |
| Mobile — chapter with audio | 71 (one run) | 85, 83, 73 (mean 80.3) |
| Mobile — long chapter | not measured | 74, 80, 71 (mean 75.0) |
| Desktop — home | 99 | **100** |
| Desktop — chapters | 99 | 96 and 88 (one run each) |
| Accessibility / Best practices / SEO | 100 / 96 / 100 | **100 / 100 / 100** on every page |
| CLS | mobile ≤ 0.007; desktop reader 0.055 | mobile ≤ 0.009; desktop chapters 0.087 and 0.069 |

Notes: with the particle engine stubbed out, the mobile home page scores 99 (TBT 0), so the field is what costs mobile points. The owner accepted scores in the 80s on mobile. The long chapter (`book-3-c13`, ~25 k words) is the weakest page (mobile 75, desktop 88): the cost there is injecting and measuring a very large article, not the field. Desktop chapter CLS (≈ 0.07–0.09) is slightly above the original's 0.055 and is not yet investigated.

## 5. Responsiveness
Matrix: 11 pages × 8 widths (320, 375, 390, 414, 768, 1024, 1440, 1920) × light and dark = **176 combinations**. Probe checks, per element: horizontal overflow, clipped text, targets < 24 px, text < 11 px, `<h1>` count, console errors (it deliberately ignores `.field-lights`, whose clipping is the point). Result: **0 horizontal overflow, 0 clipping, 0 console errors, 0 targets < 24 px, 0 text < 11 px, one `<h1>` everywhere.** Targets < 44 px average 18 per page (mostly desktop widths and intentionally compact header controls; the baseline was 31).

Additional behavioural checks (phone emulation): page, visual viewport and field layers cannot pan sideways; touch scrolling reaches the document; wheel over the outline scrolls the page. Player ≥ 200×200 and unobscured at all 8 widths.

## 6. Technical debt
| ID | Item | Decision |
|---|---|---|
| DEBT-1 | 3 empty, misspelled files (`assets/reamme.md`, `chapters/readmme.md`, `resources/readme.md`) | Removed after grep confirmed no references |
| DEBT-2 | Duplicate changelogs and a stale verification report | Archived in `docs/archive/` |
| DEBT-3 | ~190 lines of YouTube code inside `reader.js` | Extracted to `audio.js` |
| DEBT-4 | Dead CSS after glyph removal; tokens `--z-under`, `--z-veil` | Removed |
| DEBT-5 | Old changelog's contrast claim was wrong | Corrected |
| DEBT-6 | Volume 2 repeats 15 Volume 1 chapters (≥ 97 % line-identical) | Search collapses them; **content untouched** (editorial) |
| DEBT-7 | No automated tests | `tests/` added: 67 functional checks plus responsive, axe, player-size, particle benchmark, Lighthouse |

## 7. YouTube audio investigation
**Policy (primary sources, updated 2026-10-15):** Developer Policies III.I.7–9 forbid separating or isolating audio, promoting it separately, and background players; III.I.6 forbids modifying the player; Required Minimum Functionality requires ≥ 200×200 px, nothing overlaid or obscuring the player, no suppressed referrer; III.A requires a Terms link and a privacy notice naming YouTube API Services. So an audio-only, hidden-player, lock-screen experience on a YouTube embed is **prohibited**, and mobile browsers pause embeds on lock anyway. A real background audiobook would need self-hosted audio (declined).

**Likely cause of the mobile failure (inferred from code; not reproduced on a device):** the player was created asynchronously after the tap and started from `onReady`, outside the user gesture that iOS Safari and Android Chrome require; `allow="autoplay"` was set after the iframe loaded; `onAutoplayBlocked` was not handled; the API and a thumbnail were fetched on page load.

**Solution (`assets/audio.js`):** a text-only "Play audio" card; the official iframe is inserted *synchronously inside the click* with `allow="autoplay; encrypted-media; picture-in-picture; web-share"` present at creation; the IFrame API attaches afterwards for status only; `onAutoplayBlocked` or a 3.5 s timeout shows "press play inside the player"; resume position; next-chapter prompt; error fallbacks (153/101/150/100/2/5) with "Open on YouTube". Player 480×270 on desktop, ≥ 208 px tall on phones. Tested with a stubbed YouTube API. **Not verified:** real iOS/Android, real YouTube, whether the mapped video allows embedding; its playlist id `PLc1KzrqfBoGs` looks truncated.

## 8. Issue register
| Issue | Severity | Root cause | Files | Solution | Risk |
|---|---|---|---|---|---|
| Mobile audio fails | High | Async player creation outside the user gesture | `reader.js` → `audio.js` | §7 | Medium (device-unverified) |
| Outline text overlapped; scroll trapped (mine) | High | Flex items shrank in a fixed-height scroller; `overscroll-behavior: contain` | `site.css`, `reader.js` | §2 UX-12 | Low |
| Particle design | High | Wire-diagram look | `particles.js` | §4 | Medium (desktop GPU unverified) |
| No privacy disclosure | High | Missing page | all pages | `privacy.html` | Low (needs review) |
| No Search on phones | High | Links hidden ≤ 480 px | `site.css` | Short link + footer nav | Low |
| axe: 6 violations | Serious | §3 | several | §3 | Low |
| Contrast 4.14–4.40 | Serious | Token | `site.css` | `#006b59` | Low |
| Section edges misaligned | Medium | Different max-width/padding models | `site.css` | One width model | Low |
| Glyph icons, Google Fonts, hero rows, text size, resume | Medium | various | various | §2 | Low |
| Chapters invisible to crawlers | Medium | JS rendering on a static host | — | Not addressed (decision) | — |

## Measurement limits
- One CPU core; software rendering and compositing; Chromium only. No Safari, Firefox, real phones, or GPUs.
- No internet: YouTube was always stubbed; the early baseline runs served the real typefaces from npm packages, the final runs use the site's own.
- Lighthouse launches its own Chrome, so baseline runs could not receive Google Fonts (they fail instantly offline): baseline scores are optimistic. Mobile Lighthouse varies ±6 points run to run, so means of three runs are used.
- FPS has ±4 fps noise.

## 9. Validation
See `docs/IMPLEMENTATION_LOG.md` → *Validation*.

## 10. Future work
1. **Real-device pass** (iOS Safari, Android Chrome, a desktop with a GPU): audio autoplay, particle frame rate; tune the governor and starting tier from it. Highest priority.
2. **Contact line and review of `privacy.html`** (no contact was supplied; not legal advice).
3. **Chapter discoverability** if wanted later: only a build-time pre-render fixes it on a static host — deliberately not done.
4. **Editorial:** decide whether Volume 2 keeps repeating Volume 1.
5. **Search index:** parse as JSON or split postings; measure on a real phone first.
6. Consider `youtube-nocookie.com` (one constant in `audio.js`); verify the mapped video and fix its truncated playlist id.
