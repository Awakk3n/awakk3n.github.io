# Implementation Log

Read with `ENGINEERING_AUDIT.md` (findings, evidence, limits, and an account of what went wrong in the first pass). Baseline = the original ZIP. Date: 2026-10-20.

**Rollback in general.** Everything is static files. Commit the work as the numbered changes below and any one can be reverted with `git revert`; dependencies are noted. Generated files (`assets/*-data.js`, `chapters/*.content.js`, `books.json`) are reproducible: restore sources, run `python build_site_data.py`.

**Change control (applied to every change):** why does it exist? what depends on it? what can break? is there a safer alternative? is the gain worth the risk? The answers are in each entry's *Decision / Risk* lines.

## Validation (final code)
Run on the **finished code**: Chromium, one CPU core, no GPU, YouTube stubbed.

| Check | Result |
|---|---|
| Functional suite (`tests/functional.js`) | **67 / 67** — field, audio logic, reader, outline overlap, scroll chaining, sideways panning, alignment, search, export |
| axe-core, WCAG 2.2 AA + best practice; 11 pages × 2 themes × 2 viewports | **0 violations** (original: 6) |
| Responsive matrix: 11 pages × 8 widths × light + dark = **176** | **0** overflow / clipping / console errors / targets < 24 px / text < 11 px; one `<h1>` on every page |
| YouTube player ≥ 200×200 and unobscured, 8 widths | **pass** (238–480 px wide, ≥ 208 px tall, no overflow) |
| Outline regression test | **fails on the old CSS** (47 of 52 entries squashed, scroll trap on) and passes on the fix |
| Lighthouse mobile, mean of 3 | home **91.7**; chapters **80.3** and **75.0** (noise ±6) |
| Lighthouse desktop | home **100**; chapters 96 and 88; accessibility / best practices / SEO **100** everywhere |
| Particle benchmark | phones **60 / 60 fps** at 1× and **59.5 / 59.3** under 4× CPU throttle (original: 60 / 57.8 and 53.8 / 49.3); desktop **47 / 42** and **25 / 22** (original: 60 / 59 and 35.5 / 28.6) |

**Desktop particle performance is below the original in this GPU-less sandbox** (software compositing of the soft light layers; main thread only 12–20 % busy). Whether a real GPU desktop shows this is unverified. **Not verified:** real iOS/Android, real YouTube, Firefox/Safari rendering.

---

## R-0 Reverted: one HTML page per chapter
An earlier version of this work generated 85 `chapter-*.html` pages (pre-rendered for SEO) plus a template, a redirect shim, sitemap and robots.txt. **All of it was removed**: it was a large structural change nobody asked for, it cluttered the repo, and it changed every chapter URL. Restored: original `read.html`, original `build_site_data.py` (regenerates `chapters/*.content.js`), `books.json` reader URLs `read.html?chapter=<id>`. Consequence: chapter text is JavaScript-rendered, so crawlers and link-preview bots do not see it (audit UX-10). Rollback of the revert is not recommended.

## R-3 Flat controls, stretched-bond fix, dimmer hero (latest)
Owner review: too many boxed buttons; remove the glass look; disable A−/A+ at their limits; bonds stretch when scrolling; dim the hero field a little; check for other issues. **Root cause of the stretching:** the persistent-bond smoothing (R-2) kept drawing a bond after one of its particles wrapped around the screen edge or drifted away; measured 894 px / 542 over-length segments while scrolling vs a 165 px limit. Fix: drop a bond the moment its length exceeds 1.1× the limit and fade it as it approaches; measured afterwards: 164 px, none over 200. UI: replaced the glass system with a flat three-level control system (primary / outlined secondary / tertiary text); header navigation is text; A−/A+ joined into one control and disabled at the limits; Bookmark/Share/Print tertiary; resource toolbar is one card. Hero field strength 1.0 → 0.82. A systematic scan measured the gap between every icon and its label on 11 pages × 2 widths and found three missing spaces (fixed). Tests added for all of it. Files: `site.css`, `particles.js`, `reader.js`, `read.html`, `tests/functional.js`. Rollback: restore these files from git.

## R-2 Glass controls, calmer field, fixes
Owner review items, each fixed and tested: glossary/interview toolbar was an opaque band → frosted glass bar; header links lacked icons on some pages and were crammed on phones → one glass-button style with icon and spacing; outline scrollbar appeared only when sub-headings opened → no scrollbar in any state plus edge fade; "Mark as read" scrolled to the top (`window.scrollTo` after completing) → toast, no scroll; "How to Read the Book" row singled out → plain; audio consent line reworded; particles 28% slower with persistent, eased bonds (edge map keyed by particle id, existing bonds keep link slots first); body field 11% → 8% (reader 7% → 5%); glossary search excerpts began with raw heading markup → heading line dropped in `build_site_data.py`. Regressions caught by the checks and fixed: selected filter count 4.32:1 contrast; header overflow at 320 px. Files: `site.css`, `particles.js`, `reader.js`, `audio.js`, `build_site_data.py`, pages, `search-index.js`. Rollback: restore these files from git.

## R-1 Reveal particle field and restored icons
Particles: the flow-field engine (C-04) was replaced by **Reveal**, the concept the owner picked from six: crisp network lit by the cursor, three wandering beams and the hovered/current volume; body translucent; random create/push/destroy taps that are crowd-aware and bounded; per-particle randomness and gusts. A freeze found in testing (work arrays too small after rapid taps → endless loop) was fixed with growable arrays, a hard cap and a loop guard. Icons: the original glyph set was restored (C-06 is superseded) with `aria-hidden` and the accessibility fixes kept. Files: `particles.js`, `audio.js`, `app.js`, `home.js`, `book.js`, `reader.js`, `search.js`, `study.js`, all pages, `site.css`. Rollback: restore the previous `particles.js` and the pre-icon HTML/JS/CSS from git.

## C-01 Self-hosted fonts
Issue: render-blocking cross-origin Google Fonts CSS on every page. Decision: serve the same Archivo / Source Sans 3 / IBM Plex Mono from `assets/fonts/` (SIL OFL, licences bundled); preload the four files used above the fold; latin-ext loads on demand; metric-matched fallback faces so the swap does not reflow text. Files: `assets/fonts/*`, `site.css` §0, every `<head>`. Risk: low. Rollback: restore the Google Fonts links, delete the `@font-face` blocks.

## C-02 YouTube audio module — `assets/audio.js`
Issue: audio fails on mobile. Cause (inferred): player created after the tap, started outside the user gesture. Decision: text-only card; official iframe inserted *synchronously in the click* with `allow=autoplay…` at creation; IFrame API attached afterwards for status; `onAutoplayBlocked`/timeout hint; resume position; next-chapter prompt; error fallbacks; player ≥ 208 px tall and never covered (YouTube policy forbids audio-only/hidden/background playback). Files: `audio.js` (new), `reader.js` (−190 lines), `site.css` §9. Risk: medium (not verified on real devices; YouTube stubbed in tests). Bugs caught and fixed in testing: 198 px height (border ate `min-height`); overflow at ≤ 390 px (grid auto-minimum). Rollback: restore original `reader.js`/CSS §9, delete `audio.js`.

## C-03 Privacy & YouTube page
`privacy.html` (local-storage inventory, hosting, YouTube API Services statement, links to YouTube Terms and Google Privacy Policy), a Terms link in the audio card, footer nav. Risk: low technically; **needs owner review and a contact line**. Rollback: delete page and links.

## C-04 Particle field v3 — `assets/particles.js` (rewritten twice)
Issue: the original field was confined to each hero and looked like a technical diagram; my first rewrite kept that look. Decision: a flow field — fine particles on a smooth current with fading curved tails, three depth layers, three volume eddies with glowing cores, cursor wake and soft light, click ripple, quiet reading areas. One fixed canvas behind every page (`pointer-events:none`, `aria-hidden`); the soft lights are CSS layers in one clipped container; governor (full → balanced → lite); boots after load and fades in; reduced motion = one still image. Layering: page bg (−4) → hero atmosphere (−3) → lights (−2) → canvas (−1) → content.
Measured: phones as smooth or smoother than the original; **desktop slower than the original in the GPU-less sandbox** (audit §4). Behaviour changes: the canvas is not a keyboard stop (the old keyboard-triggered burst is gone); clicks on empty hero space send a ripple; pointer reaction disabled under reduced motion. Files: `particles.js`, `site.css` (tokens, hero, `.field-*`), `book.js`/`reader.js` (`setVolume`), all pages (per-page canvas removed). Rollback: restore the original `particles.js`, the hero/`.particle-layer` CSS and the per-page `<canvas>`; remove the `setVolume` calls.

## C-05 Hero volume rows are links
Rows were `<div>`s; now `<a href="book.html?b=N" data-field-focus>` with hover/focus, a live "LIVE FIELD / STILL FIELD" label, and `· N READ` per volume. Risk: low.

## C-06 Icon elimination
Removed all decorative Unicode glyphs (☼ ◐ ☆ ★ ↗ ↘ ↑ ← → ⌕ ♫ ▶ ▤ ○ ✓ × ↓): text, state styling and one shared underline-draw hover replace them (glyphs rendered inconsistently per OS; `▶` can become an emoji). **Retained, with reasons:** the four-square wordmark (brand logo, not an icon); the volume colour dot (`.book-marker`, encodes which volume a row belongs to); `kbd /` (text hint, hidden on touch); `A−`/`A+` (typographic labels with full accessible names); the browser's native disclosure marker on `<details>` (functional). Risk: low.

## C-07 Accessibility
See audit §3 (axe 6 → 0). Label-in-name; bookmark toggle; focusable scroll regions; `aria-level` repair; table header labels; unique landmark names; `<nav>`; live regions on status lines only; non-focusable decorative canvas. Risk: low.

## C-08 Type scale and touch targets
`--fs-2xs` 10 → 11 px, `--fs-xs` 11 → 12 px (text < 11 px: 86 → 0 per page); 24 px minimum hit areas; 44 px on touch except header controls (40) and the phone chip bar (32). Risk: low. Rollback: restore the two tokens and delete the `@media (pointer: coarse)` block.

## C-09 Light accent contrast
`--a1` light `#00725f` → `#006b59` (was 4.14–4.40:1 on tinted rows; now ≥ 4.55). Risk: low (slightly darker green).

## C-10 Phone navigation
Short "Search" kept in the header at ≤ 480 px; footer nav (Search · Study desk · Privacy) on every page. Risk: low.

## C-11 Reader UX
Text size persisted; "Resume at N %"; reading time; heading levels repaired; a chapter body's own `<h1>` counts as level 2. Risk: low.

## C-12 Outline rebuilt (fixes my regression)
Issue: outline entries overlapped; the column trapped scrolling. Cause: `display:flex; min-height:24px` let entries shrink in a fixed-height scroller; `overscroll-behavior: contain`. Decision: single-line entries that cannot shrink (full title on hover), sub-headings open only for the current section (`data-group` / `.is-collapsed`, ≥ 1151 px), no scroll trap, wider column (230 px), solid compact phone bar. Tests added and **verified to fail on the old CSS**. Files: `site.css`, `reader.js`. Risk: low.

## C-13 Layout polish
Hero and all sections share one left edge (one width model); header 96 % opaque; breadcrumb truncates with an ellipsis; "Start path" is a bordered action; one underline-draw hover for text links. Risk: low.

## C-13b Light mode
Issue: in light mode the field barely reached the page body and the body had nothing under it; when it did reach, strokes cut through text. Decision: ambient strokes halved in light mode (`ambient: 0.5`); four soft colour washes on the light page background; on chapter pages the reading column is masked (`columnMask`, 8 % floor) so the field lives in the margins. Verified by eye on home, reader and study (desktop and phone). Files: `site.css`, `particles.js`. Risk: low.

## C-14 Search, export, extras
Identical Volume 1/2 chapter hits collapse into one result ("Also in …"); audio resume positions included in the Study-desk export/import; `404.html`; Open Graph tags and `assets/og-image.png` (rendered from the live hero); favicon 23 KB → 6.4 KB. Risk: low.

## C-15 Cleanup
Removed three empty placeholder files (references checked first), archived duplicate logs to `docs/archive/`, removed dead CSS and tokens. Rollback: restore from the original ZIP.

## C-16 Tests in the repo (`tests/`)
Portable Playwright scripts (functional ×67, responsive, axe, player-size, particle benchmark, Lighthouse) with a README. Not part of the site.

---

## Not done / not verifiable here
- **Real-device verification** (iOS Safari, Android Chrome, a GPU desktop): audio autoplay and particle frame rate. Highest priority.
- **Real YouTube:** whether the one mapped video allows embedding; its playlist id `PLc1KzrqfBoGs` looks truncated.
- **Contact line** in `privacy.html`; legal review.
- **Chapter discoverability for crawlers** (decision: not pursued).
