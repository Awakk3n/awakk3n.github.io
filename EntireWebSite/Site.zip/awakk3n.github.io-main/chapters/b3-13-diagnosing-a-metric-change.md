---
id: C13
title: Diagnosing a Metric Change
tier: 1
competencies: [analytics, problem-solving]
prerequisites: [C03, C05, C12]
defines_terms: [metric-diagnosis, mix-shift, baseline, seasonality, pull-forward, grain, sql]
uses_terms: [goodharts-law, metric, north-star-metric, input-metric, guardrail-metric, counter-metric, funnel, activation, retention, churn, cohort, proxy-metric, instrumentation, hypothesis, root-cause, symptom, mece, issue-tree, pareto-principle, sanity-check, estimation, p-value, confidence-interval, practical-significance, base-rate, simpsons-paradox, survivorship-bias, regression-to-the-mean, multiple-comparisons, effect-size, experiment, rollback, staged-rollout, feature-flag, cannibalization, user-segment, second-order-effect, reversible-decision]
frameworks: [FW-C13-01, FW-C13-02, FW-C13-03, FW-C13-04, FW-C13-05, FW-C13-06, FW-C13-07, FW-C13-08]
case_studies: [CS-C13-01 (Illustrative), CS-C13-02 (Verified)]
cross_refs_out: [C02, C03, C04, C05, C08, C12, C14, C17, C20, C21, C33, C34, C37]
cross_refs_pending: []
status: draft
---

# C13 — Diagnosing a Metric Change

## 1. What interviewers test

"Daily active users dropped 5% yesterday. What do you do?" is among the most common analytical questions in product loops, and it is the question candidates most often answer badly. The usual answer is a list: a bug, a competitor, seasonality, a bad release, maybe a holiday. The interviewer then asks, "How would you know which?" and the answer ends. They are not looking for the longest list of causes. They are looking for a sequence: what you would check first, why, what each check would show, and how you would get from a confusing number to a cause and a decision.

**Where it shows up.** `Inferred` from the round structures candidates commonly report: metric-drop and metric-rise questions appear in analytical or execution rounds at Google, Meta, Microsoft, Amazon, Apple, Netflix and Stripe, often in the second half of a loop `[unverified: candidate-reported]`. On the job it is the work of the PM on call for a metric: someone notices a line moving, and the PM has to decide whether it is real, what caused it, and what to do before the next meeting.

**What is scored.** Whether your answer is ordered, quantitative and decision-oriented `Inferred`. Interviewers listen for whether you first confirm the change is real, whether you check cheap and common causes before exotic ones, whether you use segments to locate the change, whether you state what each hypothesis predicts so that it can be tested, and whether you finish with a decision and a communication. A candidate who says "I'd segment by platform, then region" without saying what they expect to see, or what they would do if they saw it, has described a method and not a diagnosis.

Six observable behaviors:

1. You clarify the metric, the size, the timing and the baseline, and confirm the change is real before explaining it.
2. You work through causes in a stated order, cheapest and most common first.
3. You locate the change with segments and funnel steps, and quantify how much each explains.
4. Each hypothesis predicts something else you can check, and you rule causes in or out rather than collecting them.
5. You decide (fix, roll back, pause, monitor or accept) with the reversibility and cost of waiting in view.
6. You say what you would tell stakeholders and how you would stop it recurring.

**The failure this prevents.** Six patterns end diagnosis answers: a brainstorm with no order, treating the first plausible story as the answer, never checking whether the data is complete or the definition changed, slicing by everything until something looks odd, explaining the direction but not the size, and stopping at "found the cause" with no decision or communication.

## 2. The concept from first principles

### C13.1 What diagnosis is

**Metric diagnosis** is a structured investigation into why a metric changed, ending in a cause, a decision and a communication. It has three outputs, and an answer is incomplete without all three: *what happened* (the change, located), *why* (the cause, with evidence), and *what to do* (a decision and a message). Brainstorming possible causes is the start of the work and is usually the weakest part of it.

**The stance.** Treat the question as detective work with a budget: you have a limited time, many suspects and cheap tests. The skill is ordering the tests so that each one removes the most uncertainty for the least effort, and stopping when the evidence explains the change in timing, location and size.

**Three tests of an explanation.** A cause explains a change only if it matches on three things: *timing* (the change began when the cause did), *location* (it is concentrated in the segments the cause would touch) and *size* (the cause is big enough to produce the change). A candidate cause that matches on direction alone is a guess.

**When not to use the full sequence.** If the movement is inside the normal range of day-to-day variation (C12's noise band), the right response is to monitor, and a long investigation is itself a cost. If the change is the planned consequence of a decision (an integrity cleanup, a pricing change), the work is to check it was the size you expected, not to hunt for a cause. If the question is about a future change, you are in experiments (C14).

> **Counterexample.** Asked about a 5% drop in daily active users, a candidate says in the first two minutes: "It could be a bug, a competitor launch, seasonality, a bad release, a change in the algorithm, an outage, or user fatigue. I'd say it's probably a competitor." The interviewer asks how the candidate would tell a bug from a competitor. The candidate has no test, no order and no data in mind: the list has no way to arrive at an answer, and "probably a competitor" is the cause least likely to be true on a sudden drop and hardest to check. A candidate who instead says "First I'd confirm the drop is real and complete, then check whether anything shipped in the hour it started, then see which platform or country it sits in" has proposed three cheap tests that remove most suspects.

**Hidden risks.** Two. *Fixation:* the first explanation becomes the frame, and later evidence is bent to fit. Counter it by writing down what each hypothesis predicts and by seeking the observation that would refute your favorite. *False precision:* naming one cause for a change that has several. Real changes are often a mixture (a small release effect on top of a holiday on top of a mix shift), and the honest answer says how much each explains.

### C13.2 Answer architecture and time budget

Section 4 sets out the full sequence with a time budget: clarify and confirm, locate, hypothesize, test and rule out, decide, communicate and prevent. It adds the cause taxonomy and the decomposition tools in this chapter to the structuring habits of C03 and the statistical judgment of C12.

### C13.3 Step zero: clarify the metric, size and timing; confirm the change is real

Before explaining a change, make sure there is one. FW-C13-02 is a card of questions to ask in the first two minutes.

**The metric.** What exactly is measured, per what unit (users, accounts, sessions), over what window, and has its definition changed recently? A change in definition looks like a change in behavior.

**The size.** In absolute and relative terms. A 5% drop in 10,000,000 daily users is half a million people; the same percentage in a metric of 2,000 users could be a handful.

**The shape.** A step (one level to another, on a date), a slide (gradual decline), a spike (one-off) or an oscillation. A step points to an event (a release, an outage, a policy); a slide points to a mix or behavior change; a spike points to an event that passed or to abuse.

**The baseline.** A **baseline** is the value a metric would be expected to take without the event under investigation, estimated from recent history and the same period in earlier cycles. Compare the new value with the baseline, not with yesterday. Two corrections matter. **Seasonality** is a regular, calendar-linked pattern in a metric (day of week, holidays, school terms, weather) that recurs and should be removed before inferring cause: compare Tuesday with earlier Tuesdays, and a holiday week with last year's holiday week. And the noise band from C12: how big are normal swings? If daily orders usually move by about 2.5% either way, a 3% dip is unremarkable and a 6% one is not.

**The completeness of the data.** The most recent period is often incomplete. Events arrive late (a mobile app that uploads logs when the phone next connects, a pipeline that finishes hours after midnight), so a dashboard read in the morning can show yesterday or today as sharply down for no reason except lag. Compare partial days with the same hours on earlier days, or wait for the data to settle.

**A second source.** Does another measure agree? If daily active users fell and sessions per user, revenue and support tickets did not move, the fall may be in the measurement.

**Why it works.** Many "drops" are lag, definition changes or noise, and ruling them out in two minutes saves an investigation. **When not to belabor it.** If the interviewer says "assume the drop is real and the data is complete," accept it and move on, and say that you would have checked.

### C13.4 Taxonomy of causes: data and instrumentation, product change, external, mix shift, abuse, real change in behavior

A taxonomy turns "what could it be?" into a checklist that is [[mece]] enough to work through (C03). FW-C13-03 sets it out with the tell for each, the cheap check, and who usually owns the answer. Work through it in order, cheapest and most common first.

| Family | What it looks like | Cheap check | Usual owner |
|---|---|---|---|
| 1. Data and instrumentation | A step change with no matching change in related metrics; one platform or event affected; lag; a duplicated or dropped event; a changed definition | Compare with a second source; check late-arriving data; ask what changed in logging or the pipeline | Data engineering |
| 2. Product change | The change begins within hours of a release, an experiment, a configuration change, a campaign or a notification change; concentrated in the affected surface or version | Check the release log, flags and experiments; plot the metric by app version and by the hour of rollout | Product and engineering |
| 3. External | A pattern that matches a holiday, a season, the weather, a news event, a competitor action, an app-store or operating-system change, a partner outage | Compare with the same period last year; check status pages and news; look at whether similar products moved | PM, with marketing and partnerships |
| 4. Mix shift | The overall metric moves though behavior within groups does not; the share of a low-value group grew | Break down by segment and compare the mix before and after | PM and data science |
| 5. Abuse and fraud | An implausible spike, one source or one signature, traffic that does not behave like users, or a drop caused by cleaning it up | Look at the concentration (one IP range, one country, one device), the behavior after arrival (activation, retention) and the integrity team's actions | Trust and safety, security |
| 6. A real change in behavior | None of the above explains the size; changes are broad and gradual | The residual: confirm with qualitative evidence (interviews, tickets) | PM and research |

**Order and why.** Start with 1, because a measurement problem makes everything else wasted effort and is cheap to test. Then 2, because sudden changes more often follow something the company did than something users decided `Inferred`. Then 3, which is cheap to check against calendars and last year. Then 4 and 5, which need the segmentation of C13.5. Real behavior change, 6, is the explanation you reach by elimination and confirm with qualitative work, and it is the most expensive to act on, so it should be the last you claim.

**Combinations.** Changes often have more than one cause: for example, a holiday (3) and a release (2) together. The aim is to apportion the change among them, and the decomposition in C13.5 gives a way.

**Why it works.** The order matches the cost and the likelihood, so the first few checks remove most of the uncertainty. **When not to follow it rigidly.** If the first piece of evidence points strongly at one family (a release at the exact hour of the step), go there first and come back to the rest only if the size does not fit.

### C13.5 Segmentation: the cuts that matter

To locate a change, break the metric down and see where it sits. FW-C13-04 gives the cuts in a useful order: *time* (the exact hour or day it began), *platform, device and app version*, *geography*, *acquisition channel*, *user type* (new or returning, tenure), *plan or tier*, *surface or feature*, and *funnel step* (C13.6).

**Contribution analysis.** The change in a total is the sum of the changes in its parts. If daily sign-ups fell by 500 and the channels fell by 50, 10, 300 and 140, then the third explains 60% of the drop and the fourth 28%. Report absolute contributions and relative changes together: a channel that fell 20% but is a small share may matter less than one that fell 4% and is large (EX-C13-03 works an example). A drop concentrated in one segment, a pattern consistent with the [[pareto-principle]], is a strong lead; a drop spread evenly across segments points toward a cause that touches everyone (a measurement change, a global release, an external event).

**Rate effect and mix effect.** A metric that is an average or a rate across groups, such as an overall success rate, is a mix of group rates weighted by group shares: overall = Σ share × rate. Its change splits exactly into two pieces:

- the **rate effect**, Σ (old share) × (new rate − old rate): what happened within groups, at the old mix; and
- the **mix effect**, Σ (new share − old share) × (new rate): what happened because the composition changed, at the new rates.

A **mix shift** is a change in an overall metric caused by a change in the composition of users or traffic rather than a change in behavior within groups. It is the cause behind [[simpsons-paradox]] (C12.7). Take a payment success rate (invented). Before: cards were 80% of payments with a 97% success rate, wallets 20% with 92%, so overall 0.8 × 97 + 0.2 × 92 = 96.0%. After: cards 70% with 94%, wallets 30% with 92%, overall 0.7 × 94 + 0.3 × 92 = 93.4%.

The change is −2.6 points. Rate effect: 0.8 × (94 − 97) + 0.2 × (92 − 92) = −2.4. Mix effect: (0.7 − 0.8) × 94 + (0.3 − 0.2) × 92 = −9.4 + 9.2 = −0.2. Together, −2.6. So almost all of the fall is a real drop in the card success rate, and a little is the shift toward wallets. Had the card rate stayed at 97%, the mix effect alone would have been a small fall; had the shares stayed fixed, the rate effect would have been the whole story.

**Nested cuts.** After finding the segment, cut within it: web, then browser, then browser version. Stop when one cut explains most of the change (a rule of thumb: more than three quarters) and a specific, testable story is available.

**Caution about many cuts.** Slicing a metric 20 ways will always show an odd segment (C12.7). Cut in a planned order, expect some noise, require that a segment is large enough to matter and that its story matches the timing, and treat a surprise as a hypothesis to test, not a finding.

**Why it works.** Segmentation converts a vague drop into a locus with a size. **When not to use it.** When the data is too thin to cut (a metric with a few hundred events a day), cutting makes noise, and qualitative evidence is better.

### C13.6 Funnel decomposition and cohort comparison

When the metric is the end of a journey (orders, activations, sign-ups), find the step that changed. A [[funnel]] breaks the journey into steps with a conversion rate at each (C05, FW-C05-07). Compare step by step, before and after. Because the steps multiply, a fall at one step shows up at the end: if conversion at one step fell from 70% to 55%, the end metric falls by about 21% from that step alone (0.55 ÷ 0.70 = 0.786), other steps equal. The step with the largest relative fall is where to look, and what happens at that step (a form, an email, a payment) suggests causes.

Ask also *where the missing users went*: did they leave, or did they move to another path (a different surface, an unmeasured route)? A metric can fall because users shifted to something the metric does not count (a blind spot, Worked example 2 and IQ-C13-06).

**Cohorts.** Compare groups of users by when they arrived (C05, FW-C05-05). If new cohorts behave like old cohorts did at the same age, but there are fewer of them, the problem is acquisition. If recent cohorts are weaker at the same age, the problem is the quality of the users or the early experience. If old cohorts decay faster than before, something has changed for existing users. Each points to a different owner and fix.

**Why it works.** A funnel locates a change to a step and a cohort comparison separates new users from old, which narrows the causes sharply. **When not to use it.** When the metric has no steps (a count of daily visitors), use segments and time.

### C13.6a Getting the numbers yourself: SQL for segments, funnels and cohorts

A diagnosis runs on numbers, and the quickest way to trust a number is to be able to pull it and check it yourself. **SQL** (structured query language) is the language most analytics databases use to read, filter and combine tables of data. [[sql]] lets a product manager do four things in this chapter: confirm a count (C13.3), cut a metric by segment (C13.5), build a funnel or a cohort table (C13.6) and split a change into rate and mix (FW-C13-04). The loop reports gathered for C33 do not mention SQL rounds for associate product manager roles `Inferred`; ask the recruiter whether a data or SQL exercise is part of a loop (C33.12). The skill is still worth having, because a PM who can check a number is harder to mislead and because it makes diagnosis answers concrete. Reading a query, and the fan-out trap, are taught in C21.4 (FW-C21-04, Worked example 2); this section is about writing the queries a diagnosis needs and checking them.

**How far to go.** Enough to write and read queries with counts, joins and groups; not enough to design a data warehouse. The examples use SQLite, which ships with Python, on synthetic data (invented); the scripts are in Appendix B, and every output below was produced by running the query. Date and string functions differ between databases, so check your dialect before copying a query.

**Start from the grain.** The **grain** of a table is what one row represents: one row per user, per event, per order, per user per day. Most wrong numbers come from not knowing the grain of the tables you join, or of the result you want. In the practice data, `users` has one row per user (`user_id`, `signup_date`, `channel`) and `events` has one row per user per event (`user_id`, `event`, `event_date`). "How many users activated?" has a result grain of one user, so the query must count users, not event rows.

**Six patterns cover most PM questions.**

| Question | Pattern | The point |
|---|---|---|
| How many people did X? | `COUNT(DISTINCT user_id)` with a `WHERE` on the event | Count people, not rows |
| How many reach each funnel step? | Conditional distinct counts in one pass | One query, one population, comparable steps |
| What is the rate by segment? | `users LEFT JOIN events` with the event condition in the `ON` clause, then `GROUP BY` segment | Keep users who did not do X in the denominator |
| How do cohorts compare? | Group users by signup week and flag whether each returned in a window | Same age, same definition |
| How did this week compare with last? | One row per week from one query | The same definition every week |
| What caused the change? | Segment shares and rates by week, then the rate and mix split | Locates the cause (FW-C13-04) |

The first four, with their output on the practice data (5,000 users).

*A funnel in one pass:*

```sql
SELECT COUNT(DISTINCT CASE WHEN event='signup'    THEN user_id END) AS signed_up,
       COUNT(DISTINCT CASE WHEN event='activated' THEN user_id END) AS activated,
       COUNT(DISTINCT CASE WHEN event='purchased' THEN user_id END) AS purchased
FROM events;
```

Output: 5,000 signed up; 2,574 activated; 530 purchased.

*A rate by segment:*

```sql
SELECT u.channel,
       COUNT(DISTINCT u.user_id) AS signups,
       COUNT(DISTINCT a.user_id) AS activated,
       ROUND(100.0 * COUNT(DISTINCT a.user_id) / COUNT(DISTINCT u.user_id), 1) AS activation_pct
FROM users u
LEFT JOIN events a ON a.user_id = u.user_id AND a.event = 'activated'
GROUP BY u.channel;
```

Output: organic 2,248 signups, 1,208 activated, 53.7%; paid 1,745, 699, 40.1%; referral 1,007, 667, 66.2%.

*A cohort by signup week (a user counts as returned if the table has a `returned` event for them):*

```sql
SELECT strftime('%Y-%W', u.signup_date) AS signup_week,
       COUNT(DISTINCT u.user_id) AS signups,
       COUNT(DISTINCT r.user_id) AS returned,
       ROUND(100.0 * COUNT(DISTINCT r.user_id) / COUNT(DISTINCT u.user_id), 1) AS return_pct
FROM users u
LEFT JOIN events r ON r.user_id = u.user_id AND r.event = 'returned'
GROUP BY 1 ORDER BY 1;
```

Output: week 2027-01, 1,698 signups, 275 returned, 16.2%; week 2027-02, 1,620, 206, 12.7%; week 2027-03, 1,682, 264, 15.7%. The data were built so that return depends only on the channel, so the lower middle week is chance: a few points of swing at this size is possible, which is why the noise band comes before an explanation (C13.3, EX-C13-02).

**Four ways a query goes wrong.** Each of the first three was run on the practice data.

| Failure | What it looks like | Output | The fix |
|---|---|---|---|
| Fan-out (taught in C21.4) | `COUNT(*)` after joining `users` to `events` for the `signup` and `activated` events | 7,574 rows for 5,000 users | Count distinct users, or aggregate the many-side to the grain of the one-side before joining |
| An inner join that removes the denominator | `users JOIN events` on the `activated` event, grouped by channel | Each channel shows as many users as activated users (1,208 of 1,208 for organic): a 100% "rate" | `LEFT JOIN`, with the event condition in the `ON` clause |
| Definition drift | Two reports of "week-1 return" for the same users | 745 users counted as returned in days 7 to 13 after signup; 107 in days 1 to 7 | Write the numerator, denominator, window and population (FW-C05-01) and use one definition |
| A wrong population or window | A cohort that has not had the full window yet; test or bot accounts; a day boundary in the wrong time zone | Not shown | State the as-of date, filter known test accounts and fix the time zone before comparing |

**Check before you trust.** A query that ran is not a query that is right. FW-C21-04 gives six checks: grain, join behavior, filters, nulls, time zone, and the total against a number you already trust (the practice data has 5,000 users). For diagnosis add two more. Check that the parts add to the whole and that every rate is between 0 and 100 and every count no larger than its denominator (on the practice data, the channel counts must sum to 5,000). And for a number that will drive a decision, get it a second way, such as a spreadsheet on a sample or a second query written differently, and read ten rows by eye.

**Working with others.** Say the definition first (numerator, denominator, window, population), then the grain and the join, then write the query in steps. For anything that will drive a decision, ask the data scientist who owns the tables to review it, and say which tables and filters you used. Use only data you have been given access to, and follow the privacy rules of the data (C05.9).

**When not to write the query.** When a trusted dashboard already answers the question, use it, and use SQL to check it or to answer what it cannot. The query is a way to check and to ask better questions, not a replacement for the data team's judgment.

### C13.7 Forming, testing and ruling out hypotheses

A hypothesis ([[hypothesis]], C03) is only useful if it predicts something you can check. FW-C13-06 is a ledger: for each candidate cause, write *what else would be true if it were the cause*, the cheapest check, the result, and the status.

For example, take the hypothesis "the new release broke sign-up on one browser." If true, the drop should begin at the release time, be concentrated in that browser and version, and appear in error logs for the sign-up call, while other browsers are flat. Each of these is a separate check. If the drop began a day before the release, or is flat for that browser, the hypothesis is ruled out cheaply.

**Rules for the ledger.**

- *Prefer checks that can refute.* Look for the observation that would show your favorite is wrong.
- *Test timing, location and size* (C13.1).
- *Rule out cheaply and early.* Ten minutes on a hypothesis that could take a day to confirm is a good trade.
- *Allow partial causes.* Apportion the change: "the holiday explains about 3 of the 4 points; the release about 1."
- *Keep the leading hypothesis and the next one open.* Do not drop the second-best explanation until the first has explained timing, location and size.
- *Know when to stop.* Stop when a cause explains the change on all three tests and you have a decision to make; the remainder, if small and within noise, can be left.

**Why it works.** A ledger prevents fixation and makes the reasoning visible and reviewable. **When not to build a ledger.** For a simple case with one obvious cause, say the prediction and the check in a sentence.

### C13.8 Deciding and communicating: fix, roll back, monitor

Finding a cause is not the end. The decision depends on severity, reversibility and the cost of waiting. FW-C13-07 gives a matrix.

| | Easy to reverse | Hard to reverse |
|---|---|---|
| **High severity** (revenue, safety, trust) | Roll back or switch off the change now; investigate after | Stop further spread (pause a staged rollout), fix forward fast, communicate early |
| **Low severity** | Fix forward in the normal cycle, or monitor with a threshold | Monitor, fix in the next release, set expectations |

The options are: *roll back* (undo the change, C17), *fix forward* (ship a correction), *pause* (stop a staged rollout where it is, [[staged-rollout]]), *monitor* (watch against a threshold set now) and *accept* (the change was intended or is not worth acting on). For things that cannot be recalled, such as software already installed on devices or an email already sent, the lever is usually to stop further spread and to correct quickly; this is why risky changes go out in stages.

**Communicating.** Say what you know, what you do not, the size, the decision and when the next update comes. A status message has five lines (FW-C13-07): *what* (the metric and the size), *since when*, *what we know*, *what we are doing and who owns it*, *next update at*. In an interview, say who you would tell (the owner of the surface, leadership if the size warrants, support if users are affected) and in what order.

**Preventing.** A diagnosis ends with an improvement to detection: an alert on the metric by segment (for example, sign-ups by browser), a check on the release process, a guardrail metric, a runbook for the first fifteen minutes. Say one.

**Why it works.** The matrix ties the decision to risk and speed, and the message keeps stakeholders from guessing. **When not to over-engineer it.** For a small, reversible change, a sentence in the team channel is enough.

### C13.9 Metric rises: diagnosing good news

A metric that goes up deserves the same investigation, with more suspicion, because good news is easy to accept and costly to be wrong about. FW-C13-08 is the check.

**The same steps, plus three suspects.** Confirm that the rise is real and complete (a double-counted event or a changed definition can inflate a metric). Check abuse: a jump in sign-ups or traffic that does not behave like users (it does not activate, comes from one source) is probably not users (the Wikimedia case in section 10 began as an unexplained rise). Check **pull-forward**: demand or activity brought earlier by a promotion or deadline, which raises the metric now and lowers it later, leaving the total roughly unchanged. Take a baseline of 100 sales a week (invented). A promotion week reaches 140, and the next two weeks fall to 80 and 85. Over three weeks that is 305 against a baseline of 300: a rise of 40% followed by a hole, for a net gain of under 2%.

**Check the counter metrics.** If viewing hours rose, what happened to cancellations? If sign-ups rose, what share activated? A rise that comes with a worse counter metric (Worked example 3) may be a mix shift, with heavy users up and light users down.

**Hold the celebration.** Say you would confirm the rise before reporting it and would watch the following weeks for a reversal.

**Why it works.** Good news that is wrong is as costly as bad news that is wrong, and it is checked less often. **When not to dwell.** If a rise has a clear, verified cause (a launch you expected to move it by about that much), confirm the size and move on.

### C13.10 Worked diagnoses across product types

Section 5 gives seven diagnoses in seven settings: a search product (seasonality), a social product (a mix shift in a ratio), a streaming service (a rise with a worse counter metric), a marketplace (a supply-side funnel drop), a payments product (rate versus mix) a business-software product (a changed unit), and a fall in activation found with SQL on the practice data of Appendix B (a mix shift). Section 11 adds ten questions with model answers, including two on Apple devices and services, one each set on a Google, a Meta and a Netflix product, and three SQL questions (IQ-C13-08 to IQ-C13-10).

### C13.11 Timed drills

The practice protocol in section 13 sets timed drills: a two-minute step zero, a five-minute taxonomy walk-through, a decomposition by hand, and full 20 to 30 minute diagnoses. The SQL drills (C13.6a) are to count distinct users for a stated definition, write a funnel in one query and reconcile two definitions of one metric, each checked with FW-C21-04 and the two checks added in C13.6a.

## 3. Frameworks

Eight frameworks, set out below. The structure library (FW-C03-06), the root-cause toolkit (FW-C03-08), the cohort reading guide (FW-C05-05), the AARRR funnel (FW-C05-07), the trap detector (FW-C12-07) and the six-question statistics check (FW-C12-01) are reused, not repeated.

#### FW-C13-01 · The diagnosis spine · Original

**Core framework.** Learn this one first.

- **Inputs:** a metric that moved and 20 to 30 minutes.
- **Outputs:** an answer with seven visible steps: clarify, confirm, locate, hypothesize, test, decide, communicate.
- **Assumptions:** the interviewer will supply data on request and may change the facts.
- **Tradeoffs:** a fixed order makes the reasoning scorable and can feel scripted; adapt to the first evidence.
- **Failure modes:** a brainstorm instead of a sequence; skipping the confirmation; no decision; no communication.
- **Worked example:** the diagnoses in section 5 and the model answers in section 11.

Steps: **Clarify → Confirm real → Locate → Hypothesize → Test and rule out → Decide → Communicate and prevent.** The time budget is in section 4.

#### FW-C13-02 · The step-zero card · Original

- **Inputs:** a reported change in a metric.
- **Outputs:** answers to six questions and a verdict: real, not real, or unknown, with the next check.
- **Assumptions:** you can ask the interviewer or look at the data.
- **Tradeoffs:** two minutes of checking can delay the diagnosis and prevents a wasted investigation.
- **Failure modes:** accepting the number; treating yesterday's partial data as final; comparing with yesterday instead of with a baseline.
- **Worked example:** the incomplete-data check in EX-C13-01 and the noise-band check in EX-C13-02.

| # | Question | What it catches |
|---|---|---|
| 1 | What exactly is the metric, per what unit and window, and did the definition change? | Definition and unit changes |
| 2 | How big is the change, absolute and relative? | Trivial or huge changes |
| 3 | What is its shape: step, slide, spike or oscillation? | Event versus drift |
| 4 | What is the baseline (same weekday, last year) and the normal swing? | Seasonality and noise |
| 5 | Is the data complete and settled? | Lag and partial days |
| 6 | Does a second source agree? | Measurement errors |

#### FW-C13-03 · The cause taxonomy · Original

- **Inputs:** a confirmed change.
- **Outputs:** a ranked list of cause families to check in order, each with a tell, a cheap check and an owner.
- **Assumptions:** the families are [[mece]] enough for the case; a change can have several causes.
- **Tradeoffs:** a taxonomy ensures coverage and can feel mechanical; skip families the evidence has already ruled out.
- **Failure modes:** starting with the most interesting cause; naming only one family; never reaching "real behavior" by elimination.
- **Worked example:** the walk-through in Worked example 1 and the model answers in section 11.

Order: **(1) data and instrumentation, (2) product change, (3) external, (4) mix shift, (5) abuse, (6) a real change in behavior.** The table is in C13.4.

#### FW-C13-04 · The segmentation sweep · Original

**Core framework.** Learn this one first.

- **Inputs:** a confirmed change and the available dimensions.
- **Outputs:** a table of cuts in order with each segment's absolute contribution to the change and its relative change, and, for a rate, the rate and mix effects.
- **Assumptions:** the data can be cut; segments are large enough to be read.
- **Tradeoffs:** cuts locate causes and create noise if overdone.
- **Failure modes:** unordered slicing; reading only relative changes; ignoring mix.
- **Worked example:** the sign-up drop in CS-C13-01 and the payment success rate in Worked example 5.

Cuts in order: time, platform and version, geography, channel, user type, plan, surface, funnel step. For each segment: change in absolute terms, share of the total change, relative change. For a rate: **rate effect = Σ old share × (new rate − old rate); mix effect = Σ (new share − old share) × new rate.**

#### FW-C13-05 · The funnel and cohort decomposition · Original

- **Inputs:** a metric that ends a journey, with step counts before and after.
- **Outputs:** step conversion rates before and after, the step with the largest relative fall, the users lost at each step, and a cohort comparison.
- **Assumptions:** steps are defined consistently over the period.
- **Tradeoffs:** a funnel finds where, and needs other evidence for why.
- **Failure modes:** comparing counts instead of rates; ignoring users who moved to an unmeasured path; mixing cohorts of different ages.
- **Worked example:** the email-verification step in EX-C13-05 and the provider-response step in Worked example 4.

| Step | Before: count | Before: rate | After: count | After: rate | Change |
|---|---|---|---|---|---|

#### FW-C13-06 · The hypothesis ledger · Original

- **Inputs:** a located change and a list of candidate causes.
- **Outputs:** for each hypothesis, the other things that would be true if it were the cause, the cheapest check, the result and a status (open, partial, confirmed, ruled out), and an apportionment of the change.
- **Assumptions:** the checks can be run in the time available.
- **Tradeoffs:** the ledger slows the first minutes and prevents fixation.
- **Failure modes:** hypotheses that predict nothing; checks that cannot refute; dropping the second-best too early.
- **Worked example:** the browser hypothesis in CS-C13-01, and the ledger for the app-store downloads in IQ-C13-03.

| Hypothesis | If true, we would also see | Cheapest check | Result | Status |
|---|---|---|---|---|

Test each against timing, location and size.

#### FW-C13-07 · The decide-and-communicate template · Original

- **Inputs:** a diagnosed change, its severity, how reversible the remedy is, and the cost of waiting.
- **Outputs:** a decision (roll back, fix forward, pause, monitor, accept), a five-line status message, a prevention step.
- **Assumptions:** an owner exists for the surface and the decision.
- **Tradeoffs:** speed of action against certainty about the cause.
- **Failure modes:** waiting for certainty while harm continues; rolling back without knowing whether the change caused the fall; a message with no next-update time.
- **Worked example:** the rollback in CS-C13-01, the supplier-side decision in Worked example 4, and the update-battery decision in IQ-C13-05.

Status message: **What** (the metric and the size); **Since when**; **What we know and don't**; **What we're doing and who owns it**; **Next update at [time].**

#### FW-C13-08 · The good-news check · Original

- **Inputs:** a metric that rose.
- **Outputs:** the verdict (real, partly real, not real) after checks for a data error, abuse, pull-forward, mix and counter metrics.
- **Assumptions:** counter metrics and post-arrival behavior are available.
- **Tradeoffs:** skepticism delays celebration and protects credibility.
- **Failure modes:** announcing before checking; treating a spike as a trend; ignoring the counter metric.
- **Worked example:** the viewing-hours rise in Worked example 3 and the sign-up jump in IQ-C13-07.

| Check | Question |
|---|---|
| Data | Is the rise in the measurement (double counting, a definition change)? |
| Abuse | Do the new users behave like users (activate, return) or come from one source? |
| Pull-forward | Does the net over a longer window hold up? |
| Mix | Did the rise come from one segment while another fell? |
| Counter metric | What happened to the metric that should move the other way? |

## 4. Answer architecture

### The diagnosis answer, for a 30-minute round

| Step | Minutes | What to produce |
|---|---|---|
| Clarify and confirm | 4 | The step-zero card: metric, size, shape, baseline, completeness; a verdict on whether the change is real |
| Locate | 6 | Segment and funnel cuts in order; the share of the change each explains; the locus |
| Hypothesize | 5 | The taxonomy in order; two or three candidate causes with what each predicts |
| Test and rule out | 8 | The ledger: cheapest check first; timing, location and size tests; an apportionment if mixed |
| Decide | 4 | Fix, roll back, pause, monitor or accept, with severity and reversibility; the threshold |
| Communicate and prevent | 3 | The five-line status; one preventive step |

**Pacing rules.** If the interviewer gives data, use it and say what you would look at next. If not, state what you expect to see for each hypothesis, so the interviewer can tell you the result. If you run behind, keep the confirmation, the locus and the decision, and drop breadth in the taxonomy.

**How to say it.** State the order out loud: "I'll first confirm the change is real, then check for anything we shipped, then locate it by segment." State predictions, not only methods: "If it's the release, I'd expect the drop to start at that hour and sit in the new app version."

**How to close.** Two sentences: "The evidence points to [cause], which matches the timing, the segment and the size; I'd [decision], tell [stakeholders] now, and add [prevention]. I'd change my view if [observation]."

### Type: the metric dropped

Use the full spine. Spend the first third on confirming and locating.

### Type: the metric rose

Use the good-news check (FW-C13-08). Say you would not report it until verified.

### Type: is this a problem?

A movement that may be noise. Use the noise band and baseline from C12, say what threshold would make you investigate, and what you would monitor.

### Type: diagnose and decide

When a decision is required under uncertainty (a rollback, a pause), spend more time on severity, reversibility and the cost of waiting, and on what you would do with partial evidence.

### Type: two metrics disagree

State which is more reliable and why, check the definitions, and look for a mix or a blind spot (a surface that one metric counts and the other does not).

### Type: the short version (10 minutes)

Confirm, locate, name the most likely cause and its check, decide and say what you would tell people. Protect the decision.

### Common interviewer interventions, and what to do

| Interviewer says | What it means | What to do |
|---|---|---|
| "How do you know it's real?" | You skipped step zero | Check the definition, the baseline, completeness and a second source |
| "What would you look at first?" | They want an order | State the order and the reason (cheapest and most common first) |
| "What would you expect to see if that's the cause?" | Your hypothesis predicts nothing | State timing, location and size predictions |
| "The drop is spread evenly across segments." | Not a segment effect | Think measurement, a global release or an external event |
| "That explains half of it." | Mixed causes | Apportion the change and continue with the remainder |
| "Do you roll back?" | They want a decision | Use severity, reversibility and the cost of waiting |
| "What do you tell the CEO?" | They want the communication | Give the five-line status, with what you do not know |

## 5. Worked examples

All seven examples are `Illustrative`. Where a real company's product type is the setting (examples 1 to 3), nothing here is a claim about that company's metrics, systems or decisions, and every figure is an invented assumption. The arithmetic was computed. Each follows the spine in FW-C13-01 and is written as notes you could say aloud; a spoken answer is shorter.

### Worked example 1 — Search: queries fell 4% in one country (Illustrative)

*Setting: a search product of the kind Google operates. No fact about any real product is claimed.*

**The situation.** Weekly search queries in one country fell 4% week over week (invented): an index of 100 became 96.

**Step zero (FW-C13-02).** The metric is queries, per week. The week is complete. A second source, ad impressions, fell by about the same share (invented). The shape is a one-week dip. The normal week-to-week swing is about ±0.8 on the index (invented), so −4 is five times the usual variation: real, not noise.

**Locate (FW-C13-04).** By device: desktop fell from 30 to 26.4, which is −12%; mobile fell from 70 to 69.6, which is −0.6%. Desktop explains 3.6 of the 4.0 points, 90%. By day: weekdays fell, the weekend did not. By region: the fall is nationwide.

**Hypotheses in order (FW-C13-03).** Data: no change in logging or pipeline, and a second source agrees, so ruled out. Product change: no release touched desktop search that week. External: a weekday-only, desktop-heavy dip across a whole country is what a public-holiday week looks like, when offices and schools close. If true, last year's holiday week should show the same pattern. It did: desktop −11% and mobile −0.5%, which on the index is 30 × (−0.11) + 70 × (−0.005) = −3.3 − 0.35 = −3.65.

**Timing, location, size.** Timing: the dip began on the first holiday and ended with it. Location: desktop and weekdays, as expected. Size: expected −3.65 against observed −4.0; the unexplained 0.35 is well inside the normal ±0.8.

**Decision.** No action. I'd annotate the dashboard, tell the team the dip is a holiday effect of the expected size, and check next week for the rebound (if queries do not recover, the diagnosis is wrong and I'd reopen it). Prevention: add a holiday-adjusted baseline to the weekly view so the same alarm does not recur.

**What this shows.** Most of the work was confirming and comparing with the right baseline. One external cause explained timing, location and size, and the answer was to do nothing.

### Worked example 2 — Social: comments per post fell 12% (Illustrative)

*Setting: a social product of the kind Meta operates. No fact about any real product is claimed.*

**The situation.** Comments per post fell from 5.0 to 4.4, which is −12% (invented), in the week a new lightweight post type launched. The team asks if the new post type is hurting conversation.

**Step zero.** A ratio has two parts; look at each. Posts per day rose from 1,000,000 to 1,150,000 (+15%). Comments per day rose from 5,000,000 to 5,060,000 (+1.2%). The ratio fell because the denominator grew much faster than the numerator.

**Locate by post type.** Standard posts: 1,000,000 a day, 5.0 comments each, unchanged. New quick posts: 150,000 a day at 0.4 comments each. Total comments: 5,000,000 + 60,000 = 5,060,000. Check the ratio: 5,060,000 ÷ 1,150,000 = 4.4.

**Rate and mix.** The rate within standard posts did not change, so the rate effect is zero. The overall fall is a mix effect: the share of low-comment posts went from 0% to 13% of all posts, and the average fell by (0.13 × 0.4) + (0.87 × 5.0) − 5.0 = −0.6, which is the 5.0 to 4.4 move. This is a mix shift.

**What it does and does not show.** It does not show that conversation got worse: standard posts get exactly as many comments as before, and total comments rose. It does not yet show that the quick post is good. Further checks: whether quick posts replace standard posts for some people (look at users who used both: if their standard posts fell, there is cannibalization, [[cannibalization]]); comments per user, which does not depend on the number of posts; and whether people who see many quick posts comment less on everything.

**Decision.** Change the report, not the product: track comments per active user and comments per standard post, and report the new post type separately. I'd leave the new post type running with a counter metric for standard-post volume per creator. I'd tell the team that the metric flagged a change in the mix of content, not a loss of conversation. Prevention: define ratio metrics so that a new type of the denominator does not move them silently, and review metric definitions at launch.

**What this shows.** A ratio can fall with both parts rising. Splitting into numerator, denominator and type found a zero rate effect and a pure mix effect.

### Worked example 3 — Streaming: viewing hours rose while cancellations rose (Illustrative)

*Setting: a streaming service of the kind Netflix operates. No fact about any real product is claimed.*

**The situation.** After a change to how titles are recommended, average viewing hours per member per month rose 8% (invented). In the same month cancellations rose from 2.04% to 2.39% of members, a 17% relative increase. The team is split between celebrating and worrying.

**Step zero.** Both numbers are complete and defined as before. Two metrics moving in opposite directions is the signal to look for a mix: an average can rise while a large group declines.

**Segment by engagement (FW-C13-04).** Take heavy viewers, 30% of members, and light viewers, 70% of members.

| Segment | Share | Hours before | Hours after | Change | Cancel before | Cancel after |
|---|---|---|---|---|---|---|
| Heavy viewers | 30% | 20.0 | 23.4 | +17% | 0.5% | 0.5% |
| Light viewers | 70% | 4.0 | 3.55 | −11% | 2.7% | 3.2% |
| All members | 100% | 8.8 | 9.5 | +8% | 2.04% | 2.39% |

The average rose because heavy viewers watched more (0.3 × 3.4 = +1.02 hours) by more than light viewers watched less (0.7 × −0.45 = −0.32 hours), for a net +0.70 hours, +8%. Cancellations rose entirely among light viewers: 0.7 × (3.2 − 2.7) = +0.35 points of the total +0.35.

**Interpretation.** A hypothesis consistent with all three tests (timing: the same month as the change; location: light viewers; size: the cancellation increase is accounted for by their rate): the change tuned recommendations toward what heavy viewers already like, and light viewers, who need help finding something to watch, found less. Light viewers are the group most likely to cancel. I'd call this a hypothesis, since the data shows who changed, not why.

**Good-news check (FW-C13-08).** The rise in hours is real, and it is concentrated in people who were not at risk. The counter metric, cancellations, moved the wrong way. So I would not report a win.

**Decision.** Run the change as a controlled test if it was not already one (C14), with cancellations among light viewers as a guardrail. Meanwhile limit its exposure: roll it out to heavy viewers and hold it back for light ones, or revert for light viewers, depending on how reversible the change is. Report the two segments separately. Prevention: make cancellation and engagement of light viewers a standing guardrail on recommendation changes.

**What this shows.** An average rose and a counter metric worsened at the same time; the segment split revealed that they were two different groups.

### Worked example 4 — Marketplace: bookings fell 9% (Illustrative)

**The situation.** Weekly bookings in a home-services marketplace fell from 100,000 to 91,000 (invented), −9%, the week after the company raised the commission it takes from providers from 15% to 20%.

**Step zero.** The week is complete, the definition is unchanged, and the fall is far outside the normal swing of about ±2% (invented). A marketplace has two sides; the pricing change touched providers.

**Funnel (FW-C13-05).**

| Step | Before: count | Before: rate | After: count | After: rate |
|---|---|---|---|---|
| Searches | 1,000,000 | | 1,000,000 | |
| Requests sent | 200,000 | 20.0% of searches | 198,000 | 19.8% |
| Provider responds within 24 hours | 140,000 | 70.0% of requests | 112,000 | 56.6% |
| Booked | 100,000 | 71.4% of responses | 91,000 | 81.3% |

Demand is intact: searches are flat and requests fell by only 1%. The break is at provider responses, down 20% in count and from 70% to 56.6% of requests. Customers who got a response booked at a higher rate (71.4% to 81.3%), probably because the providers who still responded were the keener ones.

**Segment the supply side.** Among experienced providers, the share responding to requests fell from 72% to 55% (invented); among providers who joined in the last 60 days it was unchanged. The timing matches the pricing change: the response rate fell from the day the new commission started. Location: experienced providers, who have more alternatives and more to lose. Size: 17 points of response among the larger group accounts for the fall in responses.

**Hypothesis check.** Product change (the commission) fits timing, location and size. Other families: no logging change, no release on the customer side, no external event matched, and no mix shift (the demand mix is stable).

**The decision is not obviously a rollback.** Revenue: before, 100,000 bookings × $80 × 15% = $1,200,000 commission; after, 91,000 × $80 × 20% = $1,456,000, which is 21% higher. The company earns more from fewer bookings. The risk is second-order ([[second-order-effect]]): providers who stop responding may leave, customers wait longer, and the loss compounds. So the choice is between three options: roll back the commission, keep it, or change its design (for example, a lower rate for high-volume providers, or one that rises with the booking value).

**What I'd do.** Not roll back immediately: the revenue is up, and the change may be intended. But I'd stop treating it as settled: pause any further price changes, track the response rate and the number of active experienced providers weekly, and test a tiered commission on a share of providers (C14). I'd set a threshold in advance: if the response rate has not recovered, or if the active experienced providers fall by more than a set share (say 5%, invented), reduce the rate for them. I'd tell leadership: "Bookings are down 9% because experienced providers respond less since the commission rise; commission revenue is up 21%; the risk is supply attrition, and we're testing a tier."

**What this shows.** The funnel placed the break at one step on one side of the market; the decision depended on revenue, reversibility and a second-order effect, and not only on the cause.

### Worked example 5 — Payments: the success rate fell from 96.0% to 93.4% (Illustrative)

**The situation.** A payments product's success rate (the share of payment attempts that succeed) fell from 96.0% to 93.4% over two days (invented). The company processes cards and wallets. A new wallet integration launched last week.

**Step zero.** The definition is unchanged. The drop is a step, not a slide. The data is complete. The normal swing is about ±0.3 points, so −2.6 is far outside it.

**Rate effect and mix effect (FW-C13-04).**

| Method | Share before | Success before | Share after | Success after |
|---|---|---|---|---|
| Cards | 80% | 97% | 70% | 94% |
| Wallets | 20% | 92% | 30% | 92% |
| Overall | | 96.0% | | 93.4% |

The split (the calculation is in C13.5): rate effect −2.4, mix effect −0.2, total −2.6. So 92% of the fall (2.4 of 2.6) is a drop in the card success rate. The shift toward wallets, which succeed less often than cards, explains only 0.2 points.

**Locate within cards.** By issuing bank: one issuer accounts for 30% of card volume. If the other issuers are unchanged at 97%, then for the card rate to be 94%, this issuer's success rate is (94 − 0.7 × 97) ÷ 0.3 = 87%. Its success fell from 97% to 87%, ten points.

**Causes.** Data: a second source (the payment provider's own report) shows the same failures, so it is real. Product change: no release in the card path. External: a failure concentrated in one issuer with a matching error code (timeouts) points to that issuer's systems or the route to them. Abuse: no change in fraud-block rates.

**Decision.** The severity is high (payments are revenue and trust) and the remedy is reversible: route that issuer's transactions through a backup acquirer or retry on failure, if available, and contact the provider. Say to merchants: "A subset of card payments from one issuer are failing; we have rerouted; the success rate is recovering; next update in an hour." Prevention: alert on success rate by issuer, not only overall, since the overall rate hid a ten-point failure in a third of card volume.

**What this shows.** The decomposition showed at once that the fall was within cards and not the mix, and the nested cut found the issuer.

### Worked example 6 — Business software: weekly active accounts fell 6% (Illustrative)

**The situation.** A business-software product reported weekly active accounts falling from 5,000 to 4,700, −6% (invented), in one week. A renewal season is not due.

**Step zero.** The definition is unchanged on paper, but the unit is accounts. A data-cleanup project ran last week. Weekly active users, the same product measured per person, went from 41,000 to 41,100, up 0.2%. Accounts fell and people did not: the unit is the suspect.

**Locate.** The cleanup merged 480 duplicate accounts (created when customers signed up twice) into 240. Each merged account counts once. That removed 240 accounts from the count, with no change in how many people use the product. The remaining change: 300 − 240 = 60 accounts, or −1.2% (the unexplained part), within the normal week-to-week swing of about ±1.5% (invented).

**Taxonomy.** Data and instrumentation (family 1): a unit change from a merge. Product, external, mix, abuse: nothing indicates otherwise. Real behavior: people are flat.

**Decision.** There is no problem with customers. Restate the history on the new definition (backfill) so the trend is comparable, annotate the dashboard, and report both weekly active accounts and weekly active users, with a note on which answers which question: accounts for customer counts, users for adoption. Tell the sales and customer success teams who track account counts. Prevention: when a data project can change a metric's unit or count, announce it and plan the restatement beforehand.

**What this shows.** A 6% "drop" was a change of unit. Checking a second metric in two minutes avoided an investigation.

### Worked example 7 — Activation fell 6.5 points in three weeks: finding the mix shift with SQL (Illustrative)

*The data are synthetic and invented (invented); the outputs below were produced by running the queries on them.*

**The question.** Activation, the share of new users who activate, fell from about 54% to 47.5% across three weekly signup cohorts. What happened?

**The data.** A table `users(user_id, signup_date, channel, activated)` with three weekly cohorts of 2,000 signups each (Appendix B, script 2, seed 11). By construction, each channel has the same activation probability every week and only the channel mix changes, so the right answer is known.

**Step zero (C13.3).** Each cohort has 2,000 signups, so there is no data gap; the definition of `activated` is one column and has not changed.

**Query 1: the metric by week.**

```sql
SELECT CAST((julianday(signup_date) - julianday('2027-03-01')) / 7 AS INT) + 1 AS wk,
       COUNT(*) AS signups, SUM(activated) AS activated,
       ROUND(100.0 * SUM(activated) / COUNT(*), 2) AS activation_pct
FROM users GROUP BY wk ORDER BY wk;
```

Output: week 1, 2,000 signups, 1,079 activated, 53.95%; week 2, 2,000, 1,022, 51.10%; week 3, 2,000, 950, 47.50%. The fall is real: a 6.45-point drop.

**Query 2: share of signups and activation rate, by week and channel.**

```sql
WITH t AS (SELECT CAST((julianday(signup_date) - julianday('2027-03-01')) / 7 AS INT) + 1 AS wk,
                  channel, COUNT(*) AS n, SUM(activated) AS a
           FROM users GROUP BY wk, channel),
     w AS (SELECT wk, SUM(n) AS total FROM t GROUP BY wk)
SELECT t.wk, t.channel, t.n, ROUND(100.0 * t.n / w.total, 1) AS share_pct,
       ROUND(100.0 * t.a / t.n, 1) AS rate_pct
FROM t JOIN w USING (wk) ORDER BY t.wk, t.channel;
```

| Week | Channel | Signups | Share of signups | Activation rate |
|---|---|---|---|---|
| 1 | organic | 1,057 | 52.9% | 53.4% |
| 1 | paid | 400 | 20.0% | 38.0% |
| 1 | referral | 543 | 27.1% | 66.9% |
| 2 | organic | 890 | 44.5% | 52.2% |
| 2 | paid | 698 | 34.9% | 41.3% |
| 2 | referral | 412 | 20.6% | 65.3% |
| 3 | organic | 707 | 35.4% | 52.1% |
| 3 | paid | 986 | 49.3% | 39.4% |
| 3 | referral | 307 | 15.3% | 63.2% |

**Read it, and check it by hand.** Paid's share rose from 20.0% to 49.3% while organic and referral shrank; the rate inside each channel barely moved (organic 53.4% to 52.1%, paid 38.0% to 39.4%, referral 66.9% to 63.2%). Check the overall rate from the table (FW-C13-04, overall = Σ share × rate): week 1 is 0.529 × 53.4 + 0.200 × 38.0 + 0.2715 × 66.9, about 54.0; week 3 is 0.3535 × 52.1 + 0.493 × 39.4 + 0.1535 × 63.2, about 47.5. Both match Query 1.

**Query 3: split the change into a rate effect and a mix effect** (the convention of FW-C13-04: rate effect at the old shares, mix effect at the new rates).

```sql
WITH t AS (SELECT CAST((julianday(signup_date) - julianday('2027-03-01')) / 7 AS INT) + 1 AS wk,
                  channel, COUNT(*) AS n, SUM(activated) AS a
           FROM users GROUP BY wk, channel),
     w AS (SELECT wk, SUM(n) AS total FROM t GROUP BY wk),
     s AS (SELECT t.wk, t.channel, 1.0 * t.n / w.total AS share, 1.0 * t.a / t.n AS rate
           FROM t JOIN w USING (wk)),
     x AS (SELECT s1.channel, s1.share AS sh1, s1.rate AS r1, s3.share AS sh3, s3.rate AS r3
           FROM s s1 JOIN s s3 ON s1.channel = s3.channel AND s1.wk = 1 AND s3.wk = 3)
SELECT ROUND(100 * SUM(sh1 * (r3 - r1)), 2)  AS rate_effect_pp,
       ROUND(100 * SUM((sh3 - sh1) * r3), 2) AS mix_effect_pp,
       ROUND(100 * SUM(sh3 * r3) - 100 * SUM(sh1 * r1), 2) AS total_change_pp
FROM x;
```

Output: rate effect −1.41 points, mix effect −5.04 points, total −6.45 points; the two effects add to the total. Putting the week-3 channel rates at the week-1 mix gives 52.54%, against 53.95% in week 1 and 47.50% in week 3.

**Interpret.** 5.04 of the 6.45 points, about 78%, are mix: more users from the paid channel, where activation is lower. The −1.41 rate effect comes from within-channel differences of one to four points on 300 to 1,000 users per channel-week, which are inside sampling noise (C13.3), and in this dataset the generator holds each rate fixed. The right reading is "no evidence of a change within any channel."

**What to do.** This is not a product defect, so do not roll back. Ask whether the lower activation of paid users is acceptable given what they cost and what they are worth (C20.7); look at onboarding for the paid channel; report a mix-adjusted activation figure beside the headline so that the average does not mislead; and add channel mix to the dashboard as a guardrail (C13.8).

**What this shows.** Three queries turned "activation fell" into a located cause with numbers that could be checked by hand and a rule for reporting: the headline can fall with no change in how any channel behaves.

## 6. Baseline, Strong, Standout

**Prompt:** "Daily active users dropped 5% yesterday. How do you investigate?"

### Baseline answer

"I'd look at the data to see what's going on. It could be a bug, a competitor, a holiday or seasonality. I'd talk to engineering and marketing, and fix whatever we find."

*What is wrong:* a list of causes with no order, no tests and no definition of "real." Nothing says what would distinguish one cause from another, and there is no decision or communication.

### Strong answer

"First I'd confirm the drop is real: what the metric is, whether yesterday's data is complete, how it compares with the same weekday last week and with the normal range, and whether another source agrees. If daily swings are usually around 2%, then 5% is outside the noise.

"Then I'd locate it. I'd cut by platform and app version, country, new versus returning users and acquisition channel, and see where most of the drop sits. A drop concentrated in one platform and version suggests a release; a drop across everything suggests measurement or something external.

"I'd work through causes in order: data and logging, anything we shipped, external events like holidays or outages, a change in the mix of users, and abuse or bot cleanup. For each, I'd say what I'd expect: if it's a release, the drop should start at the release time and sit in the new version. If I find a cause that fits timing, location and size, I'd decide between a rollback and a fix, and I'd tell the owner of the surface and leadership what we know."

### Standout answer

Everything in the Strong answer, plus:

"I'd keep a ledger of hypotheses with predictions and the cheapest check for each, so that I rule things out and do not collect stories. I'd quantify as I go: if one platform explains 85% of the drop I'd go deep there, and if the cuts show an even spread I'd suspect a measurement or global cause.

"For a rate or an average I'd split the change into a rate effect and a mix effect, since a mix shift can produce a drop with no change in behavior. I'd also look at where missing users went: a metric can fall because people moved to a surface it does not count.

"On the decision: it depends on severity and reversibility. If the cause is a release and the drop is large, I'd roll back first and investigate after, since rolling back is cheap. If it's a pricing change that raised revenue, I'd not roll back automatically; I'd weigh revenue against second-order effects and set a threshold. I'd say in advance what would make me act.

"The message to stakeholders is five lines: what and how big, since when, what we know and don't, who owns the fix, and when the next update comes. And I'd add one preventive step, such as an alert on the metric by platform and version.

"What would change my mind: if the drop disappears when the latest data finishes arriving, then it was lag and not a decline."

### What moves an answer up a band

| From Baseline to Strong | From Strong to Standout |
|---|---|
| Confirms the change and compares with a baseline | Keeps a ledger with predictions and refuting checks, and quantifies each cut |
| Locates by segment before listing causes | Splits rate and mix, and asks where missing users went |
| Orders causes and says what each predicts | Ties the decision to severity, reversibility and second-order effects |
| Names a decision and who to tell | Gives the five-line message, a prevention step and what would change the view |

## 7. Company lens

All claims describe what companies say publicly or what candidates commonly report, not insider knowledge. Interview formats change `[as of 2026-10]`.

> **Company lens: Google [as of 2026-10].** Google's published book on site reliability engineering describes blameless postmortems and a structured approach to incidents `Public` `[V: Google SRE book, 2016, and sre.google]`. Candidates commonly report analytical questions on a metric movement at large scale `Inferred`. Practical consequence: state the order of your checks, give the cheapest first, and end with the prevention step; at scale a small percentage is a large number of people.

> **Company lens: Amazon [as of 2026-10].** Amazon's leadership principles include Dive Deep, which asks leaders to probe the data when anecdote and metric disagree `Public` `[V: Amazon's Leadership Principles]`, and the company is publicly associated with a written practice of correcting errors after an incident (not rechecked here) `Inferred`. Candidates commonly report follow-ups on whether a number could be wrong `Inferred`. Practical consequence: lead with whether the number is real, and describe the correction and the mechanism that prevents recurrence.

> **Company lens: Meta [as of 2026-10].** Meta has published postmortems of large outages `Public` `[V: Meta engineering post of 5 October 2021]`, and candidates commonly report metric-drop prompts about engagement, paired with questions on tradeoffs between engagement and wellbeing `Inferred`. Practical consequence: when a metric falls, ask whether it is a measurement artifact, a mix shift or a deliberate decision, and weigh a fall in engagement against what the change was meant to do.

> **Company lens: Microsoft [as of 2026-10].** Microsoft publishes post-incident reviews for major cloud outages `Public` `[V: Azure status history publishes post incident reviews]`, and its enterprise products carry customers who depend on current behavior `Inferred`. Practical consequence: separate customer-impacting regressions from internal metric noise, and say how you would communicate to customers during the diagnosis.

> **Company lens: Apple [as of 2026-10].** Apple ships software updates to a very large installed base of devices `Public` `[V: Apple Q1 fiscal 2026 results, 29 January 2026: more than 2.5 billion active devices; yearly major software releases in September after June WWDC]`, and third-party guides report that diagnosis prompts at Apple concern behavior after an update, where a change is hard to undo once installed `Inferred`. Practical consequence: weigh the irreversibility of an update, name the lever (pause the rollout, ship a fix, set expectations) and separate transient effects from persistent ones.

> **Company lens: Netflix [as of 2026-10].** Netflix publishes technical posts on experimentation and on resilience testing `Public` `[V: Netflix Tech Blog posts on experimentation and resilience testing]`, and candidates commonly report data-informed questions on viewing and retention `Inferred`. Practical consequence: when engagement rises, look at who it rose for and check a retention counter metric before calling it a win.

> **Company lens: Stripe [as of 2026-10].** Payments metrics such as success rates depend on card networks, issuers and partners, and Stripe is widely reported to publish a public status page for its services, which was not opened here `Inferred`; candidates report questions on authorization and failure rates `Inferred`. Practical consequence: break a success rate down by method, issuer and error code before concluding the product is at fault.

## 8. Common mistakes

| # | Mistake | How to detect it | Fix |
|---|---|---|---|
| 1 | Brainstorming causes with no order | A list of eight causes in two minutes | State an order, cheapest and most common first |
| 2 | Skipping "is it real?" | You explain a change before checking the data | Check definition, baseline, completeness and a second source |
| 3 | Comparing with yesterday | The baseline is one day | Use the same weekday and the same period last year, and the noise band |
| 4 | Trusting partial data | A morning dashboard shows a sharp fall | Compare the same hours on earlier days or wait for the data to settle |
| 5 | Naming a cause that predicts nothing | "Probably a competitor" | State what you would see if it were true; check it |
| 6 | Slicing by everything | Many cuts, one odd segment | Cut in a planned order; require timing and size to fit |
| 7 | Reading only relative changes | A segment that fell 20% is a tiny share | Report absolute contributions with relative changes |
| 8 | Missing a mix shift | An average moved with no behavior change | Split rate and mix effects |
| 9 | Stopping at the cause | No decision or message | Decide, with severity and reversibility, and write the five lines |
| 10 | Celebrating a rise | You announce good news at once | Run the good-news check and watch the next weeks |

## 9. Mental models applied

Four models, each tied to a decision in this chapter. [[pareto-principle]] comes from C03 and [[reversible-decision]] from C02.

**Boring causes first** (`MM-boring-first`). When something suddenly changes, the explanation is more often mundane (a logging change, a release, a holiday, a partner outage) than interesting (a shift in user psychology, a competitor's clever move) `Inferred`. Check the boring causes first because they are cheap to test and common, and because an exciting story is a poor reason to skip them.

**The vital few** (`MM-vital-few`, see [[pareto-principle]], C03). A few segments usually explain most of a change. Find them with contribution analysis and go deep there; an even spread across segments is itself a clue, pointing at a cause that touches everyone.

**Fixation** (`MM-fixation`). The first plausible explanation becomes the frame, and later evidence is read through it. A detective who decides early on the butler looks for butler-shaped facts. The defense is a ledger that records predictions in advance, and the habit of looking for the observation that would show your favorite is wrong.

**Blast radius and reversibility** (`MM-blast-radius`, see [[reversible-decision]], C02). How much damage a wrong action does, and how easily it can be undone, should set how fast and how boldly you act. When a change is easy to reverse, act first and investigate after; when it is hard to undo (installed software, an email already sent), contain the spread first. The same logic is why risky changes ship in stages.

## Engineering, design and data-science perspectives

- **Engineering.** Engineers know what shipped, when, and to whom. Ask for the release log, the flag changes, the experiments running and any recent change to logging or the pipeline in the first five minutes, and ask whether the change can be switched off. Bring them in as partners at the start; the fastest diagnoses are joint.
- **Design and research.** Numbers say where; people say why. Watch recorded sessions or run a few quick interviews with users in the affected segment, read support tickets and app-store reviews from the period, and look at the screen where the funnel breaks. A form that confuses people is visible in minutes of watching.
- **Data science.** Ask the data scientist for the baseline, the noise band, the breakdown by the main segments and the definition history. Share your ledger so they can suggest the checks that would refute your leading hypothesis, and ask what the data cannot show. They can also set up the alert that prevents the next surprise.
- **Support, operations and trust and safety.** Support sees a problem first, in tickets and chats, often before a dashboard moves; trust and safety knows about abuse and cleanups that change counts. Ask both early: "What are you hearing?" and "Did we change anything about bots or spam?"

## Checklist: before you declare a cause

1. Did I confirm the change is real: definition, baseline, completeness, second source?
2. Did I check the cheap, common families first: data, then our own changes, then external?
3. Did I locate the change with segments and funnel steps, and quantify the share each explains?
4. Does the cause match on timing, location and size?
5. Did I separate rate and mix effects for any average or rate?
6. Did I look for a second cause for the part that is unexplained?
7. Did I choose fix, roll back, pause, monitor or accept, with severity and reversibility in view?
8. Do I have a five-line message and one preventive step?

## 10. Case studies

#### CS-C13-01 · The sign-up drop that was one browser · Illustrative · Beginner

*Fictional composite. Every number is invented (invented).*

**Situation.** A consumer app normally receives about 10,000 sign-ups a day. At 9:00 on a Wednesday the dashboard shows 8,000 for Tuesday, a drop of 20%. A new version of the sign-up form was released on Tuesday at 08:10. The growth lead asks the PM what happened.

**Constraints.** No weekday events, no marketing changes, and a team that can roll back the release in under an hour. Sign-ups are the product's main entry point, so every hour matters.

**Data.** The normal day-to-day swing is about ±600 sign-ups, so −2,000 is far outside it. The data is complete for the day, and the app-store consoles show the same pattern. Sign-ups by platform and, within web, by browser:

| Segment | Normal day | Tuesday | Change | Share of the change |
|---|---|---|---|---|
| iOS app | 3,500 | 3,480 | −20 | 1% |
| Android app | 2,500 | 2,490 | −10 | 0.5% |
| Web, Browser S | 2,400 | 440 | −1,960 | 98% |
| Web, other browsers (Chrome-type) | 1,100 | 1,095 | −5 | 0.25% |
| Web, rest | 500 | 495 | −5 | 0.25% |
| Total | 10,000 | 8,000 | −2,000 | 100% |

By the hour, Browser S sign-ups fell at 08:10 and stayed low; the other segments did not move. The error log for the sign-up call shows a script error only for older versions of Browser S, beginning at 08:10.

**Problem definition.** As an observable problem: "Since the release at 08:10, users on older versions of one browser cannot complete sign-up."

**Analysis.** Step zero rules out noise, incomplete data and a measurement problem: two sources agree and the size is far outside the swing. The segmentation sweep (FW-C13-04) finds that one browser explains 98% of the change, a clear vital-few pattern ([[pareto-principle]]). The ledger (FW-C13-06): *a release broke sign-up on that browser* predicts that the drop starts at 08:10 (yes), is concentrated in that browser (yes, 98%), and appears in the error logs (yes). The size fits: the browser provided 24% of normal sign-ups, and it lost 82% of its sign-ups for the day, which is 1,960 of 2,400. Competing hypotheses fail: a holiday or competitor would not hit one browser at one minute past a release, and a logging error would not show script errors for users.

**Options.**

| Option | Optimizes | Costs |
|---|---|---|
| A. Roll back the sign-up form release | Speed of recovery | Loses whatever the release added; the cause is already known |
| B. Hotfix the form for the older browsers | Keeps the release | Takes longer; risk of another mistake |
| C. Wait and monitor | Certainty | Continues the loss: about 2,400 × 0.8 ≈ 1,900 sign-ups a day |

**Tradeoffs.** A is reversible and fastest. B is better if the fix is small and the release valuable, but it is slower. C costs about 80 sign-ups an hour on average (1,900 a day) and has no value, since the cause is clear.

**Decision.** Roll back now (A), then hotfix and re-release with the browser tested. Message (FW-C13-07): "Sign-ups fell 20% on Tuesday because the form release at 08:10 broke sign-up on older versions of one browser, about 1,960 sign-ups lost. Rolling back now. Owner: web engineering. Next update at 11:00." Prevention: an alert on sign-up conversion by browser and version, and a browser test matrix in the release checklist.

**Outcome.** In this fictional scenario the rollback finished at 09:40, Browser S sign-ups returned to about 2,350 a day by Thursday, and the total loss was about 2,000 sign-ups from Tuesday plus about 600 from Wednesday morning (invented). The hotfix shipped the following week with the browser added to the test matrix.

**Alternative outcomes.** If the segments had all fallen evenly, the cause would have been measurement or a global event and the team would have checked logging and external factors. If the browser had explained only half the drop, the other half would need its own investigation, and the PM would have apportioned the change. If a rollback had been impossible (a database change shipped with the form), the team would have moved to the hotfix and told users on the affected browser to use another until it landed. The lesson is the order: confirm, locate, test the hypothesis against timing, location and size, then decide.

#### CS-C13-02 · Wikimedia, 2025: a traffic spike that was bots, and the decline behind it · Verified · Advanced

*Sources (types): the blog post "New User Trends on Wikipedia" by Marshall Miller of the Wikimedia Foundation, published on the Foundation's Diff blog on 17 October 2025, read in full (primary, the organization's own account); and TechCrunch's report of it (18 October 2025). Wikimedia's attribution of the decline to generative AI features and social video is the organization's own interpretation, reported as such. The analysis is the author's. Re-read in October 2026.*

**Situation.** The Wikimedia Foundation classifies traffic to Wikipedia as human or bot. Around May 2025 it noticed unusually high amounts of apparently human traffic, mostly from Brazil `[V: Foundation post, 17 October 2025]`. Its engineers and analysts investigated and found bots built to evade detection. The Foundation updated its bot-detection systems and re-applied the new logic to traffic from March through August 2025. After the revision, the Foundation reported declines in human pageviews "over the past few months" of roughly 8% compared with the same months in 2024, and said it believes the declines reflect the impact of generative AI and social media on how people seek information `[V: Foundation post]`.

**Constraints.** Classification of traffic depends on detection rules, which change over time, and the Foundation said that revising its data this way means it has to be interpreted with care, because its bot detection applies different rules at different points in time. Bots designed to look human are hard to separate from people by definition. The organization depends on human readers, since fewer visits mean fewer volunteers and donors, as the Foundation's post says. It cannot observe why a person did not visit.

**Data.** As reported: an unexpected rise in apparently human traffic in May and June 2025, concentrated by country; a finding, on inspection, that the traffic did not behave like people; a revised classification applied back to March; a resulting decline in human pageviews of roughly 8% compared with the same months in 2024, described as "over the past few months" (the post does not name the months) `[V: Foundation post]`. The Foundation also said that in April 2025 it had described how bots and crawlers overburden its infrastructure `[V: Foundation post]`. Other estimates of the decline from outside sources differ and measure different things, so they are not used here.

**Problem definition.** *The author's reading.* A number that looked like good news (more human traffic) did not behave like human traffic. The question became twofold: how many people actually read the site, and how has that changed? As an observable problem: "The count of human pageviews was inflated by traffic that was not human, so the headline trend was wrong."

**Analysis.** *The author's analysis.* Read through this chapter's frameworks, the sequence is a textbook diagnosis of a rise (FW-C13-08). The team noticed an anomaly and its location (a country) before accepting it, which is the segmentation habit. It checked behavior after arrival, since traffic that does not behave like users is a sign of abuse (family 5). It treated the classification itself as a possible cause, family 1 (instrumentation), by revising the detection rules and re-applying them to past data, which restated the baseline. Only then did a trend appear: a fall of about 8% in human pageviews. So the good news was false, and the underlying trend was a decline.

The explanation for the decline is a separate step. The Foundation attributes it to generative AI features in search and chatbots and to social platforms, which supply information without sending readers to the site `[V: Foundation post]`. That is a reasonable hypothesis consistent with the timing and with other publishers' reports, and the data used here do not establish it. The case is useful for a PM because it shows both stages: first make the number trustworthy, then diagnose it, and be explicit about which parts are measured and which are inferred. The caveat the Foundation itself gave, that the revised data must be interpreted with care because detection rules differ over time, is part of a good communication.

**Options.** *The author's reconstruction of choices an analytics team could have faced; not a record of the Foundation's deliberations.*

| Option | Optimizes | Costs |
|---|---|---|
| A. Report the high May and June traffic as growth | A better-looking trend | A false number; a decision based on it; lost credibility when discovered |
| B. Investigate, revise detection, restate the series and publish with the caveat | A trustworthy picture and a basis for strategy | A less welcome message; a break in comparability |
| C. Investigate and keep the finding internal | Control of the message | The Foundation's partners and community make decisions with the old figures |

**Tradeoffs.** B costs a bad headline and a series that cannot be compared exactly with earlier ones, and gives a number that can be acted on. A is the easiest and the most damaging. C avoids embarrassment and leaves outsiders working from the wrong data.

**Decision.** As documented, the Foundation updated its detection, reclassified the past months, and published the finding, with a caution that the revised data must be interpreted with care and a plan that includes enforcing policies on third-party use, developing an attribution framework, and two new readers teams `[V: Foundation post]`.

**Outcome.** Reported: the 8% decline in human pageviews and the Foundation's work on attribution and reader growth. What the decline will do to editing and donations, and how much of it AI features explain, is not established in the sources used here.

**Alternative outcomes.** *Inference.* Had the team accepted the spike, the decline would have been hidden for longer and any decision about reader growth would have rested on inflated data. Had the revised detection been too aggressive, real people could have been classified as bots and the decline overstated, so the error can run in both directions; validating the classifier on a known sample is the check. A reader should also see the wider lesson for any PM: when a metric rises for no reason you can name, treat it as a diagnosis, and be ready for the corrected number to be worse than the first.

## 11. Interview questions and model answers

Ten questions: three Beginner, three Intermediate, four Hard. Model answers are `Illustrative`; every figure is an assumption, and the arithmetic was computed. Each is written against the six behaviors in section 1 and uses the spine in FW-C13-01. Where a real company's product is the setting, the answer reasons from public information and user behavior and states no internal fact. The answers are fuller than a first pass in a real round; a spoken version keeps the same order with fewer words.

#### IQ-C13-01 · Beginner · analytics · AN

**Prompt.** Weekly sign-ups fell 3% this week. Is it a problem?

**Rubric.**
- **Baseline:** "Yes, any drop is a problem, so I'd investigate," or "no, 3% is small."
- **Strong:** Compares the change with the normal variation and a baseline before deciding, and says what would trigger a deeper look.
- **Standout:** Computes a noise band from history, notes the limits of a short history and of watching many metrics, proposes a cheap first check, and sets a monitoring rule.

**Model answer.** I'd answer "is it a problem?" with "compared with what?" Three questions first: how much do weekly sign-ups normally move, is this week's data complete, and is it an unusual week (a holiday)?

Suppose the last eight weeks were 10,100, 9,900, 10,200, 10,000, 9,800, 10,100, 10,050 and 9,950. The mean is about 10,010 and the standard deviation about 130, which is about 1.3% of the mean. This week's 9,700 is 3.1% below the mean and about 2.5 standard deviations below it. That is unusual but not overwhelming: with only eight weeks of history my estimate of the normal swing is itself uncertain, and a team that watches dozens of metrics every week will see a 2.5-sigma move by chance from time to time (C12).

So I would not open a full investigation, and I would not ignore it. A cheap first check, ten minutes: is the data complete, was it a holiday week, and do the segments (platform, channel, country) show one place where it fell? If one segment explains most of the drop, I'd look deeper there. If the drop is spread evenly and there is no cause, I'd set a rule and watch: if next week is also below 9,850 (about the mean minus one and a quarter standard deviations), or if the drop persists for two weeks, I'd investigate fully.

The decision I'd state: "It is slightly outside the normal range; I'd check segments and the calendar now, and escalate if it persists." What would change my mind: a concentrated segment drop, or a related metric (activation, revenue) moving too.

**Follow-ups.**

- **Q.** What if the next two weeks also come in about 3% below the average? **A.** "Then it is no longer noise. One week at 9,700 is about 2.4 standard deviations below the 10,010 mean, unusual but possible; three weeks in a row near 3% below is very unlikely by chance, so it is a trend, and I would open a full diagnosis: segment by channel, country and device, and check for a change in acquisition or tracking. My monitoring rule would flag one week outside two standard deviations for a quick look and three consecutive weeks below one standard deviation for a full investigation."
- **Q.** How do you avoid chasing noise when you watch many metrics? **A.** "By accounting for how many alarms chance produces. With 40 metrics each checked weekly against a two-standard-deviation band, about 4.6% of checks fire by chance, so I would expect nearly two false alerts every week. I would set wider thresholds for metrics that matter less, require a second signal before escalating (for example a funnel metric and a revenue metric both moving), and keep a short list of metrics tied to decisions. The goal is a monitoring process that people trust because it rarely cries wolf."

#### IQ-C13-02 · Beginner · analytics · AN · Google

**Prompt.** Average watch time per user on a large video platform fell 3% over two weeks. What do you do?

**Rubric.**
- **Baseline:** "Content must have gotten worse," or "run an experiment."
- **Strong:** Confirms the change, segments by user type, and checks for a mix shift.
- **Standout:** Splits rate and mix with numbers, notes that a growing share of new users lowers an average without any change in behavior, and says what to track instead.

**Model answer.** I know the product only from public information and use. First step zero: the metric is average minutes per user, the window is two weeks, the data is complete and a second metric, sessions, agrees. A 3% move over two weeks is a slide, not a step, which points away from a release or an outage and toward a change in who is using the product or how.

*Segment by tenure.* An average over users is a mix of new and established viewers. Suppose established users watch 90 minutes in the period and new users 40, and new users were 10% of the base and are now 15% (a marketing push or a launch in a new country).

- Before: 0.90 × 90 + 0.10 × 40 = 81 + 4 = 85 minutes.
- After: 0.85 × 90 + 0.15 × 40 = 76.5 + 6 = 82.5 minutes, which is −2.9%.

If established users still watch 90 and new users still watch 40, the rate effect is zero and the mix effect is (0.85 − 0.90) × 90 + (0.15 − 0.10) × 40 = −4.5 + 2.0 = −2.5, which is the whole drop. A fall in the average with no change in anyone's behavior.

*Confirm.* I'd check that established users' watch time is flat, and that the new users' watch time is in line with earlier cohorts at the same age (C05's cohort reading). I'd also check the other mix candidates: device (more phone, less TV), country, and content type.

*Decision.* If the mix explains it, nothing is broken: more new users is growth, and new users' watch time grows with tenure. I'd change how the metric is reported (by cohort and tenure), and I'd say to stakeholders: "The average fell because new users are a larger share; established users are unchanged." I'd keep a watch on new-user watch time by age as an input to activation (C05). What would change my mind: if established users' watch time fell, the drop would be a real change in behavior and I'd look at content, recommendations and releases.

*Company note.* Google is the setting only: `Inferred` from candidate reports that analytical prompts at Google concern its own products at scale `[unverified: candidate-reported]`. No Google data or product behavior is claimed.

**Follow-ups.**

- **Q.** How would you show that the mix of new and established users explains the fall? **A.** "With a split by tenure. Suppose new users are 20% of daily users and watch 20 minutes a day, and established users watch 50. The average is 0.2 × 20 + 0.8 × 50 = 44 minutes. If new users rise to 25% of users with no change in either group's behavior, the average becomes 0.25 × 20 + 0.75 × 50 = 42.5 minutes, a fall of about 3.4% with no change in anyone's habits. If watch time is flat within each tenure group, the fall is a mix effect, and it may even be good news, since it reflects growth."
- **Q.** What would you track instead of the overall average? **A.** "Watch time by tenure cohort (new, one to three months, established), the median and a share-above-threshold such as the share of users watching at least 30 minutes a day, and retention curves by sign-up cohort. These separate behavior change from mix change. I would also report the average with a tenure-adjusted version that holds the user mix fixed, so that leadership can see both what the average is and what the like-for-like change is."

#### IQ-C13-03 · Intermediate · analytics · AN · Apple

**Prompt.** Daily app downloads on an app store fell 8% week over week (invented). Diagnose.

**Rubric.**
- **Baseline:** "Maybe fewer people want apps, or there is a competitor."
- **Strong:** Confirms the change, segments by region, device and release, and checks the calendar and store features.
- **Standout:** Quantifies contributions, nests cuts to a specific country, builds a ledger with predictions, apportions the change and decides with owners named.

**Model answer.** I know the product only from public information and use. Step zero: downloads per day, averaged over the week, from 1,000,000 to 920,000. I'd check that the week is complete, the definition (does it count re-downloads and updates?) is unchanged, and the normal week-to-week swing, which I'd expect to be a couple of percent. A second source, such as developer-reported installs, should agree.

*Locate by region (FW-C13-04).* Suppose: North America 300,000 to 295,000; Europe 250,000 to 247,000; Asia-Pacific 350,000 to 278,000; other 100,000 to 100,000. That is −5,000, −3,000, −72,000 and 0, a total of −80,000. Asia-Pacific explains 72,000 of 80,000, 90%.

*Nest.* Within Asia-Pacific, one country goes from 150,000 to 85,000, down 65,000: 81% of the whole drop (65 of 80), while the other countries in the region fell 7,000.

*Ledger (FW-C13-06).*

| Hypothesis | If true, we would also see | Cheapest check | Status |
|---|---|---|---|
| Data or pipeline lag in that country | Other metrics from the country (sessions, purchases) look normal; the fall disappears when data settles | Second source and later data | Check first |
| A feature placement or promotion in that store ended | A fall concentrated in a few titles that had been featured, starting on a known date | The editorial calendar; downloads by title | Likely |
| A holiday or seasonal pattern | The same fall in that country in the same week last year; across all apps | Last year's week; downloads of other categories | Check |
| A release or policy change in the country | A fall at a specific time, perhaps after a store or system change | Release and policy log | Check |
| A network or payment disruption | Failures in related flows, status reports, a fall in all downloads | Status pages and error logs | Check |
| Bot or incentivized downloads removed | A fall concentrated in a few apps with unusual earlier spikes | Fraud team's actions | Check |

*Timing, location and size.* A candidate cause has to explain a 65,000 fall in one country starting on a date. A ended feature placement, a holiday or a disruption could each do it; the checks separate them in an hour.

*Decision.* If it is a calendar or featured-slot effect, no action beyond an annotation and a watch for the rebound. If it is a disruption, escalate to the owner and communicate to developers. If it is data, fix the pipeline and restate. I'd tell the store's business owner and the regional lead what we know, the size, and the next update. Prevention: alert on downloads by country, not only the global total. What would change my mind: if the fall were spread across all regions, I'd look at measurement or a global change instead.

*Company note.* Apple is the setting only: `Inferred` from third-party reports that analytical prompts at Apple include diagnosing movements in services metrics `[unverified: candidate-reported]`. No Apple data or system behavior is claimed.

**Follow-ups.**

- **Q.** How do you nest the cuts to find where the drop comes from? **A.** "I go from the largest slice downward: region, then country, then source (search, browse, ads, referrals), then device. Suppose the drop is 80,000 downloads a day and one country with 25% of volume fell 20%, which is 50,000, or 62% of the drop. Within that country, if search-driven downloads fell and browse stayed flat, that points to a ranking or search change, not a demand change. At each level I compute each slice's contribution to the total drop, so that I look first where most of it is, and I write a ledger of hypotheses with the prediction each makes, such as an outage showing an hourly dip and a campaign ending showing a drop in the ads source only."
- **Q.** Who owns the decision and what do you do first? **A.** "I would name owners: the store-ranking team for search and browse changes, marketing for campaign sources, and the platform team for outages. The first action is to confirm the pattern against a second data source, then ask the owner of the most likely cause for a yes or no within 24 hours. Meanwhile I would set an interim monitor on daily downloads for the affected country, tell leadership what we know and do not know, and agree a time for the next update. A diagnosis without owners and dates tends to stall."

#### IQ-C13-04 · Intermediate · analytics · AN · Netflix

**Prompt.** After a marketing campaign, sign-ups rose 25%, but 30-day retention of new members fell from 70% to 60%. Is the campaign working?

**Rubric.**
- **Baseline:** "Sign-ups rose, so yes," or "retention fell, so no."
- **Strong:** Separates the campaign cohort from the others, computes the retention of the incremental members, and compares with cost.
- **Standout:** Shows the arithmetic, treats the drop as a mix shift and not a change in the product, looks at a longer horizon, and sets a decision rule on cost per retained member.

**Model answer.** This is a mix question. The headline retention fell, but I don't yet know whether the product got worse or the campaign brought in a different kind of member. I know the product only from public information.

*The arithmetic.* Before the campaign: 100,000 sign-ups at 70% retained, so 70,000 retained at 30 days. After: 125,000 sign-ups at 60% retained, so 75,000. Suppose the 100,000 baseline sign-ups still retain at 70%. Then the 25,000 incremental sign-ups account for 75,000 − 70,000 = 5,000 retained, which is a retention of 5,000 ÷ 25,000 = 20%. The overall rate fell from 70% to 60% only because a large group retaining at 20% joined a group retaining at 70%. The rate effect on the baseline group is zero; it is a mix effect.

*What this says about the campaign.* It added 5,000 retained members, a 7% increase over 70,000, and its members are far less likely to stay. Whether that is a success depends on the cost. If the campaign cost $750,000 (invented), it cost $30 per sign-up and $150 per member retained at 30 days (750,000 ÷ 5,000). I would ask what a retained member is worth over their life. If it is above $150 in margin, the campaign pays; if it is below, it does not.

*What else I'd check.* The campaign cohort by channel, country and plan, since part may be good and part poor. A longer horizon: some members come late, and 30-day retention may understate it, so I'd look at 90-day retention for the earlier cohorts. Abuse: free-trial sign-ups that never intended to stay. And the baseline group's retention, to confirm it did not change.

*Decision.* Don't judge by retention alone. Judge by cost per retained member against value, and optimize targeting: shift spend to the channels where the incremental members retain better. I'd report retention for the baseline and campaign cohorts separately, so the average does not hide either. What would change my mind: if the baseline group's retention had also dropped, the problem would be the product or its early experience, not the mix.

*Company note.* Netflix is the setting only: `Inferred` from candidate reports of data-informed prompts on sign-ups and retention `[unverified: candidate-reported]`. No Netflix data or practice is claimed.

**Follow-ups.**

- **Q.** How do you tell whether the product got worse or the mix changed? **A.** "Split the retained members by origin. Before: 100,000 sign-ups at 70% gives 70,000 retained. After: 125,000 at an overall 60% gives 75,000 retained. If the original 100,000 still retain at 70%, the extra 25,000 sign-ups produced only 5,000 retained members, a retention of 20%. So the product did not worsen for the baseline audience; the campaign brought a very different audience. I would confirm by splitting retention by channel and by sign-up source, and compare the campaign cohort's behavior in the first week with the baseline's."
- **Q.** What decision rule would you use? **A.** "Cost per incrementally retained member against its value. Suppose the campaign cost $250,000 and produced 5,000 incremental retained members: $50 per retained member. If a retained member is worth about $120 of contribution over a year, the campaign pays back at a ratio of 2.4 to 1, which may be acceptable; if the value is $40, it is not. I would also check 90-day retention of the campaign cohort, since 30-day retention can mislead, and consider onboarding changes aimed at that audience before deciding to repeat or stop the campaign."

#### IQ-C13-05 · Hard · analytics · AN · Apple

**Prompt.** Battery-life complaints rose after a system software update. Diagnose and decide.

**Rubric.**
- **Baseline:** "Roll back the update," or "it's probably perception."
- **Strong:** Separates complaints from measured drain, controls for who updates early, checks segments such as device age, and weighs reversibility.
- **Standout:** Distinguishes transient from persistent effects, targets the response by device group, states a decision rule with thresholds, and sets out the communication.

**Model answer.** I know the situation only in general terms and nothing here describes any real product. The key facts first, with assumptions: the update was released four days ago to 40% of eligible devices through a staged rollout; complaints are support contacts and feedback that mention battery.

*Is it real?* Complaints are a self-selected and lagging signal. People pay more attention to battery right after an update, and people who update early differ from those who wait. I'd compare complaints per 10,000 devices: updated 12, not updated 4 (invented). For the previous release's first four days, updated devices had 8 and not-updated 4, so there is a baseline gap of 4 from early adoption and attention. This release's excess over that is (12 − 4) − (8 − 4) = 4 complaints per 10,000 devices. It is a real but smaller signal than the raw ratio of 3 to 1.

*Measure drain, not only complaints.* From device telemetry (with the privacy limits in force), compare battery use in standard conditions between updated devices and a matched control with the same model, age and usage. Suppose the first 48 hours show drain +9% against control and by day four +2% (invented). A fast decay suggests a transient effect, for example background work after an update, which is a hypothesis to test and not a claim about any specific cause.

*Segment.* By device model and battery health: suppose newer devices show +1% at day four and older devices with worn batteries +6% (invented). So the effect persists for one group.

*Taxonomy.* Data: telemetry coverage and complaint counting. Product change: the update itself (and any app update shipped that week). External: a popular third-party app misbehaving after the change. Mix: older devices updating later. Abuse: not relevant. The evidence points at a transient effect for most and a persistent one for older devices.

*Decide (FW-C13-07).* Severity is moderate unless there are heat or safety signals, which would mean pause immediately. Reversibility is low: an installed update cannot easily be undone, and 60% of devices have not yet received it. So the lever is the rollout. My decision rule: if any device group shows persistent excess drain above +5% at day seven, or any thermal or safety signal appears, pause the rollout for that group. By that rule: pause the rollout for older devices, continue for newer ones, and ship a point release that addresses the persistent drain. Meanwhile set expectations for everyone updating: "battery may drain faster for a day or two after updating."

*Communicate.* Five lines for support and leadership: what (battery complaints up, excess 4 per 10,000 devices over baseline), since when (the update's release), what we know (transient for most, persistent on older devices), what we're doing (paused for older devices, point release in progress, owner named), next update in 24 hours. Prevention: add a device-age cut and a drain guardrail to the staged rollout so a pause is triggered automatically. What would change my mind: if telemetry showed drain at day four equal to control in all groups, I'd continue everywhere and treat the complaints as attention.

*Company note.* Apple is the setting only: `Inferred` from third-party reports that diagnosis prompts at Apple involve behavior after updates and the limits on reversing them `[unverified: candidate-reported]`. No claim is made about any real update, telemetry or process.

**Follow-ups.**

- **Q.** How do you tell transient from persistent battery effects? **A.** "Use the staged rollout as a natural comparison. Compare battery telemetry for updated devices with not-yet-updated devices of the same models, by days since update. After an update, devices often run background work such as re-indexing for a day or two, which raises drain temporarily. If the difference disappears by day three, it is transient; if drain is still elevated at day seven, it is persistent. I would split by device model and age, since older batteries show effects first, and check whether complaints track the telemetry."
- **Q.** What would your decision rule and communication be? **A.** "A rule written in advance: pause the rollout if updated devices show more than 10% greater battery drain than the holdout at day five in any device group, or if complaints per 1,000 updates exceed a threshold. If the effect is limited to certain models, fix and re-release for those groups first. Communication: a short, honest note saying that some devices may use more battery for a few days after updating, what to expect, and what to do, with a promised follow-up date. I would track complaints per 1,000 updates and the share of devices back to baseline by day seven."

#### IQ-C13-06 · Hard · analytics · AN · Meta

**Prompt.** After a new "share to story" button launched, daily feed posts per user fell 6%. What do you do?

**Rubric.**
- **Baseline:** "The button is hurting feed posting, so remove it."
- **Strong:** Asks where the posting went, compares total creation, and redefines the metric.
- **Standout:** Computes the net, considers the effect on feed supply for viewers, notes the incentive created by owning a metric for one surface, and sets a guardrail.

**Model answer.** I know the product only from public information. Step zero: the metric counts posts to one surface, the feed. A fall in a surface metric after launching a feature on another surface is a signal to ask where the missing activity went (C13.6). Suppose feed posts per user fell from 1.00 to 0.94 a day, while story shares per user rose from 0.10 to 0.17.

*Total creation.* Before: 1.00 + 0.10 = 1.10 pieces of content per user. After: 0.94 + 0.17 = 1.11. Net: about +1%. People did not stop sharing; some of it moved from the feed to stories. The metric's blind spot made a flat total look like a 6% decline.

*What it does not settle.* Whether the move is good. Questions: did the same people shift (cannibalization), or did one group post less to the feed while another started posting to stories (users who both create and view)? Does the viewer's side change: fewer feed posts means less for viewers to see, so I'd check feed consumption and time spent, and whether stories offset it. Is story content as valuable to creators and viewers as feed content (a story disappears, a feed post persists)? And does any group, such as creators who rely on feed reach, lose?

*The incentive problem.* If a team is measured on feed posts per user, it may resist features that move posting elsewhere even when the company gains. This is [[goodharts-law]] (C05) in organizational form. The fix is to measure the outcome, total content creation and the health of both supply and consumption, and not the surface.

*Decision.* Don't remove the button. Redefine the creation metric as total creation across surfaces, keep feed posts per user as a diagnostic, and add guardrails: feed consumption per viewer and the share of creators whose total creation falls. Tell the owners of both surfaces what the data says. What would change my mind: if total creation had fallen, or if feed viewers' time spent fell without a matching rise in stories, the move would be a loss, and I'd revisit the design (for example, how the button is placed).

*Company note.* Meta is the setting only: `Inferred` from candidate reports that prompts at Meta can involve how a metric hides a shift between surfaces and how to weigh it `[unverified: candidate-reported]`. No Meta data or product behavior is claimed.

**Follow-ups.**

- **Q.** How do you compute the net effect and what do you conclude? **A.** "By adding both surfaces. Before: 1.00 feed posts plus 0.10 story shares is 1.10 pieces of content per user per day. After: 0.94 plus 0.17 is 1.11, a rise of under 1%. So total creation is flat and the feed metric fell because creation moved to stories. The real question is the viewers: a feed with 6% fewer posts may give viewers less to see, so I would check viewer sessions, time and satisfaction, and whether story views make up for it. The launch might be neutral or good, and a surface metric alone made it look bad."
- **Q.** What guardrail would you set to avoid the incentive problem? **A.** "Own a metric that spans surfaces: total content created per user and viewer satisfaction, so that a team is not rewarded for moving activity between surfaces. Add a guardrail that feed supply per viewer does not fall by more than 3% unless story consumption rises enough to offset it. Align the owners of the two surfaces on shared metrics and review them together. Otherwise each team protects its own number, and the product pays for the competition."

#### IQ-C13-07 · Hard · analytics · AN

**Prompt.** Overnight, daily sign-ups jumped 40%. How do you respond?

**Rubric.**
- **Baseline:** "Great news; let's find out what we did right and do more of it."
- **Strong:** Treats the rise with suspicion, checks the data and the source, and looks at what the new sign-ups do afterward.
- **Standout:** Uses post-arrival behavior to test whether they are real people, computes the implied activation, acts on the source, and protects metrics and costs.

**Model answer.** I'd treat it as a diagnosis, with more suspicion than for a drop, because good news is accepted too easily (FW-C13-08). Step zero: a jump of this size and speed with no launch or campaign planned is unusual. Check that the data is complete and not double counted, and that the definition did not change.

*Locate.* Normal is 10,000 a day, today is 14,000, so 4,000 extra. By channel, country and device: suppose nearly all of the extra comes from one country and one referral source, with a narrow range of email domains and device types. A concentration like that is a sign of non-human traffic.

*Test with behavior after arrival.* Real people activate and return. Suppose 45% of normal sign-ups activate within a day, which on 10,000 is 4,500. Today, 4,508 activated. So the 4,000 extra sign-ups produced only 8 activations, 0.2%. The extra sign-ups did nothing, which is what bots or fake accounts do. (Activation is a [[proxy-metric]] for a real user, C05.)

*Taxonomy.* Abuse (family 5) fits timing, location and size. Data error is ruled out by the second source. A product or external cause would show real activation.

*Decide.* Severity: moderate to high. Fake accounts cost money (verification messages, storage, support), distort every metric and can harm real users if they are used for spam. Reversibility: easy for sign-up controls. Actions: block or rate-limit the source and add friction for the pattern (a challenge for sign-ups from it), remove the fake accounts from the metrics (restate the day with a note on the definition), and tell the integrity team and the owners of the dashboards. I would not report the 40% as growth.

*Communicate.* "Sign-ups rose 40% yesterday. About 4,000 came from one source and did not activate: 8 activations against about 1,800 expected from that many real sign-ups. We believe they are fake. We are blocking the source and restating the metric. Owner: integrity. Next update at 14:00."

*Prevent.* Monitor sign-ups by source with an activation check, and alert when a source's volume jumps while its activation is near zero. What would change my mind: if the extra sign-ups activated at a normal rate, they are real, and I'd find out what we did (a mention, a campaign) and whether it will last or is a one-day spike that pulls sign-ups forward.

**Follow-ups.**

- **Q.** How do you test whether the extra sign-ups are real people? **A.** "By what they do after arriving. Normal sign-ups activate within 24 hours at about 55%; if the 4,000 extra activate at 2%, only about 80 of them are real users, and the implied activation of the whole day collapses. I would also look at email domains and patterns, device and IP clustering, sign-up timing in bursts, and whether they come through one channel. Real users show varied behavior; a bot wave shows the same steps in the same seconds. Good news gets accepted too easily, so I would be more suspicious of a jump than of a drop."
- **Q.** What do you do about the source, and how do you protect metrics and costs? **A.** "Block or rate-limit the source with trust and safety, and exclude the flagged accounts from reporting so that the sign-up and activation metrics are not polluted, keeping them in a separate bucket for investigation. If we pay for the traffic by sign-up, stop payment and dispute the invoice. Fix the weak point that let the wave in (a missing verification step) and add an alert for sign-up bursts by source. I would tell finance and marketing what happened and what the corrected numbers are, so that no one celebrates a number that is not real."

#### IQ-C13-08 · Beginner · analytics · AN

**Prompt.** How would you count daily active users from an events table, and what can go wrong with the obvious query?

**Rubric.**
- **Baseline:** "Count the rows per day."
- **Strong:** Counts distinct users per day and says how "active" is defined.
- **Standout:** States the definition (which events, which time zone), the grain, the distinct count, and the checks (total against a known number, bots and test accounts, definition drift), and gives the query.

**Model answer.** *Definition first.* "Active" must be written down: which events count (any event, or a meaningful one), in which time zone the day is cut, and which accounts are excluded (test accounts, known bots). Without that, two people produce two numbers.

*Grain.* The events table has one row per user per event, so one user can have many rows in a day. The result I want has one row per day with one number: people, not events.

```sql
SELECT event_date, COUNT(DISTINCT user_id) AS active_users
FROM events
WHERE event IN ('signup', 'activated')   -- whichever events define "active"
GROUP BY event_date
ORDER BY event_date;
```

*What goes wrong.* Counting rows (`COUNT(*)`) overstates users: on the practice data, 4 January has 268 rows for those two events and 241 different users. Other failures: a day boundary in the wrong time zone, which shifts activity between days; test and bot accounts that inflate the count; and a definition that changes between reports.

*Check.* Compare the total with a known number (the practice data has 5,000 users, so no day can have more than 5,000 active users), check the number is plausible against last week's, and read a few rows. If the number will drive a decision, get it a second way, and run the six checks of FW-C21-04 with the two added in C13.6a.

*Signals.* The definition stated first; grain; the distinct count; the failure modes; checks.

**Follow-ups.**

- **Q.** What if the table has several rows per user per day and you also need weekly active users? **A.** "I'd count distinct users over the week's date range, not add the seven daily numbers, because the same person is active on several days and a sum would count them several times. Weekly active users is its own distinct count over its own window, and I'd write the window and the time zone down."
- **Q.** How would you tell whether a spike in the daily number is real? **A.** "I'd check the pipeline first: did the row count of the table jump, did a logging change or a new platform start emitting events, are the extra users new accounts or one device? Then I'd compare with the noise band for that day of the week (C13.3). A spike driven by a few thousand test or bot accounts would be a data issue, and I'd confirm by excluding them and recomputing."

#### IQ-C13-09 · Intermediate · analytics · AN

**Prompt.** Two dashboards show different week-1 retention for the same signup cohort. How do you find out why?

**Rubric.**
- **Baseline:** "One of them is wrong; I'd ask the data team."
- **Strong:** Lists the likely causes: definition, population, window and joins.
- **Standout:** Writes both definitions in the same four parts, reproduces both numbers with one query side by side, finds the first place they diverge, and ends with one documented definition and an owner.

**Model answer.** *Treat it as a definition problem until shown otherwise.* I'd write each dashboard's metric in four parts (FW-C05-01): the numerator (who counts as retained), the denominator (which users are in the cohort), the window (which days after signup) and the population (filters, such as activated users only or excluding test accounts). Differences show up in these four places, and also in the time zone and in the as-of date.

*Reproduce both with one query.* On the practice data, the same 5,000 users give different answers depending on the window: 745 users returned in days 7 to 13 after signup, and 107 returned in days 1 to 7.

```sql
SELECT COUNT(DISTINCT CASE WHEN CAST(julianday(r.event_date) - julianday(u.signup_date) AS INT) BETWEEN 1 AND 7
                           THEN u.user_id END) AS returned_days_1_to_7,
       COUNT(DISTINCT CASE WHEN CAST(julianday(r.event_date) - julianday(u.signup_date) AS INT) BETWEEN 7 AND 13
                           THEN u.user_id END) AS returned_days_7_to_13
FROM users u
JOIN events r ON r.user_id = u.user_id AND r.event = 'returned';
```

Output: 107 and 745. Note that day 7 sits in both windows, so even the boundary needs a rule.

*Other causes to check.* A join that multiplies rows (fan-out, C21.4: 7,574 rows for 5,000 users on the practice data); an inner join that drops users who did nothing; a cohort that has not had its full window yet; a time-zone difference at the day boundary; one dashboard counting from a different table.

*Close it.* Agree one written definition with its owner, say which dashboard now follows it, and note the change date so that trend lines are not compared across the break.

*Signals.* Four-part definitions; one reproducing query; the first point of divergence; documented ownership.

**Follow-ups.**

- **Q.** Which of the two numbers is right? **A.** "Neither, until we agree what week-1 retention means for this decision. A window of days 1 to 7 measures early return and one of days 7 to 13 measures return in the second week; they answer different questions. I'd choose by the question, for example whether users come back after the first week, then name the definition in the dashboard title so the number cannot be misread."
- **Q.** What if the two dashboards disagree only slightly? **A.** "Then I'd look for the smaller causes: a time-zone cut, a filter for test accounts, a population of activated users versus all signups, or rounding. A small gap with a clear cause is still worth closing, because it will grow when the data changes. I'd also check whether the gap is within the noise of a sample, if one of them is built on a sample."

#### IQ-C13-10 · Hard · analytics · AN

**Prompt.** Describe, in SQL or in words, how you would compute week-1 retention by signup week and channel, and say what could mislead you when you read it.

**Rubric.**
- **Baseline:** "Group users by week and channel and count who came back."
- **Strong:** Gives the right grain and joins, and notes small cohorts.
- **Standout:** Builds a per-user flag first, groups after, defines the window, handles incomplete cohorts, reads rates with sample sizes and noise, and names the mix and survivorship traps.

**Model answer.** *Per-user flag first, group after.* I'd build one row per user with a retention flag, then aggregate. That fixes the grain and avoids fan-out from the events table.

```sql
WITH base AS (
  SELECT u.user_id,
         strftime('%Y-%W', u.signup_date) AS signup_week,
         u.channel,
         MAX(CASE WHEN e.event = 'returned'
                   AND CAST(julianday(e.event_date) - julianday(u.signup_date) AS INT) BETWEEN 7 AND 13
                  THEN 1 ELSE 0 END) AS returned
  FROM users u
  LEFT JOIN events e ON e.user_id = u.user_id
  GROUP BY u.user_id)
SELECT signup_week, channel, COUNT(*) AS signups, SUM(returned) AS returned,
       ROUND(100.0 * SUM(returned) / COUNT(*), 1) AS return_pct
FROM base GROUP BY signup_week, channel ORDER BY signup_week, channel;
```

On the practice data the output is, for signup weeks 2027-01, 2027-02 and 2027-03: organic 18.0%, 14.0% and 16.5% (771, 713 and 764 signups); paid 9.3%, 6.9% and 9.0% (592, 567 and 586); referral 24.2%, 19.7% and 25.6% (335, 340 and 332).

*What could mislead.* (1) *Incomplete cohorts:* the latest week may not have had the full window yet, so its rate is understated; I'd state the as-of date and drop cohorts that are not complete. (2) *Small cells and noise:* a channel-week with 335 users has a wide margin (several points), and the middle week here is lower in all three channels even though the data were built with the same return probability each week; I'd check the noise band before explaining a difference (C13.3). (3) *Mix:* an overall retention number blends channels, so a rise in paid signups lowers it with no change inside any channel (Worked example 7); report by channel. (4) *Survivorship:* if I restrict to users who activated, I answer a different question; I'd say which population I mean. (5) *Definition drift:* the window and the event must match the dashboard's definition. (6) *Many comparisons:* nine cells will show a few differences by chance.

*Check.* The cells' signups should add to 5,000, the rates should lie between 0 and 100, and a second method (a pivot table on a sample) should agree on at least one cell (the checks of FW-C21-04 and C13.6a).

*Signals.* Per-user flag then group; the window; incomplete cohorts; noise; mix; survivorship; checks.

**Follow-ups.**

- **Q.** How would you handle the most recent signup week? **A.** "I'd set an as-of date and include a cohort only if every user in it has had the full window, so the last incomplete week is left out or shown separately and marked as partial. Otherwise it will look like a drop in retention when it is only a shorter observation period. I'd also show the count of users who have completed the window so the reader sees how much of the cohort is in."
- **Q.** Paid retention looks lower than organic in every week. Is that a finding? **A.** "It is a consistent difference, with n in the hundreds for each cell, so it is more than one noisy week. Before calling it a finding I'd check that the definition and population are the same across channels, whether paid users differ in how they were acquired (for example, they were incentivized), and what the difference costs: lower retention is acceptable if the acquisition cost is low enough (C20.7). I'd report the rate with its sample size and a range."

## 12. Exercises

Ten exercises. Each has a model solution and an alternative. Figures are assumptions unless marked, and the arithmetic was computed.

#### EX-C13-01 · Is the data complete?

**Problem.** At 9:00 on Tuesday the dashboard shows 3,000 orders so far today, against 5,000 at 9:00 last Tuesday: −40%. Events reach the dashboard with a delay of up to 90 minutes. At 7:30 last Tuesday the dashboard had shown 3,100 orders. What do you conclude?

**Context.** You are asked whether to page the on-call team.

**Data.** As above.

**Constraints.** Three minutes.

**Expected approach.** The step-zero card (FW-C13-02): compare like with like on completeness.

**Solution.** With a 90-minute delay, the 9:00 dashboard contains events only up to about 7:30. The like-for-like comparison is today's 3,000 against 3,100 at 7:30 last Tuesday: −3.2%, which is within normal variation. The −40% compares different amounts of data. Do not page; check again at 11:00 when the data has settled, and say that you would.

**Alternative solution.** Compare today's complete 7:30 count from the raw event stream, if available, with last Tuesday's.

**Tradeoffs.** Waiting costs time if something is truly wrong; a second quick source (payment success, support contacts) can check it meanwhile.

#### EX-C13-02 · The noise band

**Problem.** Daily orders (thousands) for eight comparable days: 10.2, 9.8, 10.1, 10.4, 9.9, 10.0, 10.3, 9.7. Today is 9.5. Compute the mean and the standard deviation, and say whether today is unusual.

**Context.** A team lead asks whether to investigate.

**Data.** As above.

**Constraints.** Four minutes.

**Expected approach.** The noise band (C12.3, C13.3).

**Solution.** The mean is 10.05 and the standard deviation is about 0.245, or 2.4% of the mean. Today's 9.5 is 0.55 below the mean, which is 5.5% and about 2.25 standard deviations. It is unusual but with eight days of history it is borderline: about one day in forty falls this far below by chance. A reasonable response is a ten-minute check of segments and the calendar, not a full investigation, and a rule to escalate if tomorrow is also low.

**Alternative solution.** Use the same weekday for the baseline if orders vary by weekday, which may make the band tighter and today more unusual.

**Tradeoffs.** A short history gives an uncertain band; watching many metrics yields occasional false alarms.

#### EX-C13-03 · Contributions to a drop

**Problem.** Sign-ups by channel, before and after: paid search 3,000 to 2,950; social 2,000 to 1,990; referral 1,500 to 1,200; organic 3,500 to 3,360. Compute each channel's absolute contribution to the change, its share of the drop and its relative change. Which do you investigate first?

**Context.** Total sign-ups fell from 10,000 to 9,500.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** Contribution analysis (C13.5, FW-C13-04).

**Solution.** Contributions: paid −50 (10% of the drop), social −10 (2%), referral −300 (60%), organic −140 (28%); total −500. Relative changes: paid −1.7%, social −0.5%, referral −20%, organic −4%. Referral explains the most and fell the most in relative terms: investigate first. Organic is the second: 28% of the drop with a small relative fall, because it is a large channel; it may be a seasonal or search-ranking effect, and should not be skipped.

**Alternative solution.** Check whether referral and organic share a cause (for example, a change to a sharing feature that also affects organic discovery).

**Tradeoffs.** Reading only relative changes would send you to referral and miss that organic is nearly a third of the drop.

#### EX-C13-04 · Rate effect and mix effect

**Problem.** Activation rate by acquisition channel: before, channel A is 60% of sign-ups at a 50% activation rate and channel B is 40% at 30%; after, A is 40% at 49% and B is 60% at 31%. Compute the overall rates, the change, the rate effect and the mix effect.

**Context.** Leadership asks why activation fell.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** FW-C13-04.

**Solution.** Before: 0.6 × 50 + 0.4 × 30 = 42.0%. After: 0.4 × 49 + 0.6 × 31 = 38.2%. Change: −3.8 points. Rate effect (old shares, rate changes): 0.6 × (49 − 50) + 0.4 × (31 − 30) = −0.6 + 0.4 = −0.2. Mix effect (share changes at the new rates): (0.4 − 0.6) × 49 + (0.6 − 0.4) × 31 = −9.8 + 6.2 = −3.6. Total −3.8. Within each channel activation barely moved; the fall is a mix shift toward the lower-activating channel B. The question becomes whether the growth in B is wanted and whether B's activation can be improved.

**Alternative solution.** Report activation by channel and a mix-adjusted overall figure (at the old mix: 0.6 × 49 + 0.4 × 31 = 41.8%).

**Tradeoffs.** A mix shift can be good (more users in a harder channel); judge it by cost and lifetime value, not by the average.

#### EX-C13-05 · Find the funnel step

**Problem.** A sign-up funnel: 100,000 visits; 30,000 start sign-up (30%); 18,000 complete the form (60% of starts); 12,600 verify email (70% of completes); 7,560 take a first action (60% of verified). After a change: 100,000; 30,000; 18,000; 9,900 verify (55%); 5,940 first action (60%). Which step changed, how many users were lost there, and what is the effect on the end metric? What would you check?

**Context.** First actions fell from 7,560 to 5,940.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** The funnel decomposition (FW-C13-05).

**Solution.** The email verification step fell from 70% to 55%; other rates are unchanged. Users lost there: 12,600 − 9,900 = 2,700. They would have taken a first action at 60%, so the end metric lost 2,700 × 0.6 = 1,620, matching 7,560 − 5,940. The relative effect is 0.55 ÷ 0.70 = 0.786, a 21% fall at the end. What I'd check: whether the verification email is delivered (spam folder, a changed sender or template), how long it takes to arrive, whether the link works on mobile, and whether the verification step itself changed.

**Alternative solution.** Compare by email provider: if the fall is concentrated in one provider's users, it points to deliverability.

**Tradeoffs.** Fixing deliverability is fast; changing the step design is slower and may be less necessary.

#### EX-C13-06 · A hypothesis ledger

**Problem.** Orders fell 20% starting at 15:00 on Tuesday, across all platforms. No release shipped that day. Build a ledger for four hypotheses: (a) a payment provider incident, (b) a release or configuration change, (c) a holiday or external event, (d) a data pipeline or definition change. For each, give a prediction, the cheapest check and what it would rule out.

**Context.** You have ten minutes before a leadership update.

**Data.** None.

**Constraints.** Seven minutes.

**Expected approach.** FW-C13-06; test timing, location and size.

**Solution.** (a) Payment incident: payment success rate falls at 15:00, orders fall with it, error codes from the provider rise, the provider's status page shows an incident; check payment success by method and the provider's status. Rules out if the success rate is flat. (b) Release or configuration: a change logged near 15:00 (a flag, a config, a campaign); check the change log and flags; rules out if nothing changed. (c) External: the fall matches a regional event or outage, and other companies' services show similar patterns; check the calendar and status pages; rules out if the pattern is not across the market. (d) Data: other metrics do not fall (payments received, support contacts), and the dashboard disagrees with the source of truth; check a second source; rules out if the money did not move. Order: (d), then (b), then (a), then (c).

**Alternative solution.** Start with (a) if a payment alert fired at 15:00, since the first strong evidence sets the order.

**Tradeoffs.** A fixed order is efficient on average; one strong early signal should override it.

#### EX-C13-07 · Fix, roll back, pause or monitor?

**Problem.** Choose and justify an action: (a) a checkout bug affects 5% of users, and a fix will be ready in two hours; (b) a metric is 1.5% below normal, inside the usual swing; (c) a software update, already installed on 40% of devices, shows a persistent fault on one model.

**Context.** Use severity, reversibility and the cost of waiting.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** The matrix in C13.8 and FW-C13-07.

**Solution.** (a) High severity (revenue) and easy to reverse: roll back the release that introduced the bug if that is faster than two hours; otherwise switch off the affected path with a flag, then fix; the cost of waiting is 2 hours of failed checkouts for 5% of users. (b) Low severity and noise: monitor with a threshold (investigate if it persists for two days or exceeds the noise band). (c) High severity for those users and hard to reverse: pause the rollout for that model, fix forward quickly, communicate to affected users, and do not try to recall what is installed.

**Alternative solution.** In (a), if the rollback would also remove an important unrelated fix, use the flag.

**Tradeoffs.** Rolling back is cheap when it is possible; a rollback that is itself risky (a data migration) changes the answer.

#### EX-C13-08 · Pull-forward

**Problem.** Weekly sales are normally 100 (index). A promotion week reaches 125. The next two weeks are 80 and 90. What is the net effect over three weeks, and how do you report it?

**Context.** The marketing team wants to report a 25% lift.

**Data.** As above.

**Constraints.** Four minutes.

**Expected approach.** The good-news check (FW-C13-08).

**Solution.** Over three weeks sales total 125 + 80 + 90 = 295 against a baseline of 300: a net change of −5, or −1.7%. The promotion moved demand forward and did not create it; the weeks after fell below baseline by 30. Report the three-week (or longer) net with the weekly pattern, and if the promotion had a cost, report the net after the cost. The right comparison is with a holdout group that did not get the promotion, if possible.

**Alternative solution.** If some promoted customers are new and stay, the after-weeks may recover; extend the window to six weeks before judging.

**Tradeoffs.** A longer window delays the answer and gives a truer one.

#### EX-C13-09 · The five-line message

**Problem.** Write the status message: sign-ups fell 20% on Tuesday; the cause is a form release at 08:10 that broke sign-up on older versions of one browser; about 1,960 sign-ups were lost; the release is being rolled back, finishing at about 09:40; web engineering owns the fix.

**Context.** The message goes to leadership and support at 09:10.

**Data.** As above.

**Constraints.** Five lines.

**Expected approach.** The template in FW-C13-07.

**Solution.** *What:* Sign-ups fell 20% on Tuesday (8,000 against about 10,000); one browser accounts for 98% of the drop. *Since when:* 08:10 Tuesday, when the new sign-up form was released. *What we know and don't:* The form breaks sign-up on older versions of that browser, about 1,960 sign-ups lost; we do not yet know whether any users who hit the error will return. *What we're doing and who owns it:* Rolling back the form release now, owner web engineering, completion expected around 09:40; support can tell affected users to use another browser. *Next update:* 11:00, with recovery numbers.

**Alternative solution.** Add one line on prevention (an alert on sign-up conversion by browser) in the follow-up message.

**Tradeoffs.** A longer message adds detail and delays the key facts; lead with what and the action.

#### EX-C13-10 · A timed full diagnosis

**Problem.** Give a 20 to 25 minute answer: "Active paying subscribers fell 2% month over month. Why, and what do you do?"

**Context.** Self-scored; record yourself.

**Data.** None. Ask for what you need and say what you would expect.

**Constraints.** Use the 30-minute budget in section 4, compressed.

**Expected approach.** The full spine (FW-C13-01), scored against the six behaviors in section 1.

**Solution.** An outline of a strong answer. Step zero: active subscribers is a stock, so decompose it into flows: gross additions, cancellations, reactivations and involuntary churn (failed payments). Confirm the definition, the window (month length, billing dates), and completeness. Locate: which flow moved? Gross additions down (acquisition), cancellations up (retention), payment failures up (billing).

Then segment the flow that moved by plan, channel, cohort and country. Taxonomy: data (a billing system change that miscounts), product (a price change, a removed feature, a billing flow change), external (seasonality such as a holiday month, competitor), mix (more annual plans changing the timing of cancellations), abuse (fraudulent trials ending). Test each against timing, location and size. Decide according to which flow: if payment failures, fix the billing retry logic (reversible and urgent); if a price change, consider a rollback or grandfathering; if seasonality, monitor. Communicate in five lines and add an alert on each flow.

**Alternative solution.** Start with the flows from a subscription model and ask which of gross adds or churn moved, which narrows the search before any hypotheses.

**Tradeoffs.** A stock metric moves slowly and hides which flow changed; decomposing into flows is the first move.

#### EX-C13-11 · The 100% activation rate

**Problem.** A report shows activation of 100% in every acquisition channel, which nobody believes. The query joins `users` to `events` with `JOIN events a ON a.user_id = u.user_id AND a.event = 'activated'` and groups by channel. Find the error, give the right query and say how you would have caught it.

**Context.** A funnel by segment in a diagnosis (C13.5, C13.6).

**Data.** The practice dataset (Appendix B, script 1; invented). The query as written returns, for organic, paid and referral, 1,208 users with 1,208 activated, 699 with 699, and 667 with 667.

**Constraints.** Six minutes.

**Expected approach.** FW-C21-04 and C13.6a.

**Solution.** The inner `JOIN` keeps only users who have an `activated` event, so every user in the result has activated by construction and the users who did not activate, the rest of the denominator, are gone. The rate is activated users divided by activated users. The right query keeps all users with a `LEFT JOIN` and puts the event condition in the `ON` clause: `FROM users u LEFT JOIN events a ON a.user_id = u.user_id AND a.event = 'activated' GROUP BY u.channel`, counting `DISTINCT u.user_id` for signups and `DISTINCT a.user_id` for activated. On the practice data it returns organic 2,248 signups and 1,208 activated (53.7%), paid 1,745 and 699 (40.1%), referral 1,007 and 667 (66.2%). The check that catches it is the total against a known number: the wrong result's users sum to 2,574 (1,208 + 699 + 667), but the table has 5,000 users; the right result's signups sum to 5,000.

**Alternative solution.** Compute a per-user flag first (`MAX(CASE WHEN event = 'activated' THEN 1 ELSE 0 END)` grouped by user) and then average the flag by channel; the denominator is every user by construction.

**Tradeoffs.** A `LEFT JOIN` with a condition in the `ON` clause is easy to get wrong (moving the condition to `WHERE` turns it back into an inner join); the per-user flag is longer and harder to misread.

#### EX-C13-12 · Write the funnel query

**Problem.** The `events` table (`user_id`, `event`, `event_date`) has three events: `visit`, `add_to_cart` and `purchase`. Write one query that returns the number of distinct users at each step, then compute the step-to-step and overall conversion. Some users have several `add_to_cart` rows.

**Context.** A funnel question in a diagnosis (C13.6).

**Data.** Run on a test table built to these numbers (invented; Appendix B, script 3): 10,000 users visited, 2,400 added to cart, 600 purchased; 300 of the users who added to cart did so on two different days.

**Constraints.** Eight minutes.

**Expected approach.** The funnel pattern in C13.6a, FW-C13-05 and FW-C21-04.

**Solution.**

```sql
SELECT COUNT(DISTINCT CASE WHEN event='visit'       THEN user_id END) AS visited,
       COUNT(DISTINCT CASE WHEN event='add_to_cart' THEN user_id END) AS added,
       COUNT(DISTINCT CASE WHEN event='purchase'    THEN user_id END) AS purchased
FROM events;
```

Output on the test table: 10,000; 2,400; 600. Conversion: visit to cart 2,400 ÷ 10,000 = 24%; cart to purchase 600 ÷ 2,400 = 25%; overall 600 ÷ 10,000 = 6%. The repeated rows matter: counting `add_to_cart` rows instead of users gives 2,700 (2,400 users plus 300 repeat rows), which would show a cart rate of 27% and a cart-to-purchase rate of 22%. The distinct count answers "how many people", which is the funnel's question. This funnel assumes the steps are nested (every purchaser also visited); check that the counts of later steps do not exceed earlier ones.

**Alternative solution.** Build a per-user table with one flag per step and count the flags; it makes the nesting check explicit (`purchase = 1 AND visit = 0` should return no rows).

**Tradeoffs.** A funnel over all time mixes users at different stages; for a diagnosis, restrict to a signup or visit window and state it.

#### EX-C13-13 · Two dashboards, one cohort

**Problem.** Dashboard A reports 107 users returned in week 1 and dashboard B reports 745, for the same 5,000 signups. List the four questions you would ask, write one query that shows both numbers side by side, and say what you would do next.

**Context.** The scenario in IQ-C13-09, on the practice data.

**Data.** The practice dataset from Appendix B, script 1 (invented). Dashboard A uses days 1 to 7 after signup; dashboard B uses days 7 to 13.

**Constraints.** Eight minutes.

**Expected approach.** FW-C05-01 and FW-C21-04.

**Solution.** *Four questions:* what counts as retained (the numerator), who is in the cohort (the denominator), which days after signup (the window, and whether day 7 is included), and which filters apply (the population, time zone and as-of date). *One query:*

```sql
SELECT COUNT(DISTINCT CASE WHEN CAST(julianday(r.event_date) - julianday(u.signup_date) AS INT) BETWEEN 1 AND 7
                           THEN u.user_id END) AS returned_days_1_to_7,
       COUNT(DISTINCT CASE WHEN CAST(julianday(r.event_date) - julianday(u.signup_date) AS INT) BETWEEN 7 AND 13
                           THEN u.user_id END) AS returned_days_7_to_13
FROM users u
JOIN events r ON r.user_id = u.user_id AND r.event = 'returned';
```

Output: 107 and 745. The windows differ, and day 7 appears in both. *Next:* choose the definition by the question the metric answers, write it as numerator, denominator, window and population, assign an owner, change the other dashboard to match (or rename it) and record the date of the change so that trends are not compared across it.

**Alternative solution.** Report both windows on one dashboard with clear names ("returned in days 1 to 7" and "returned in days 7 to 13") if both answer real questions.

**Tradeoffs.** One definition is simpler to read; two named definitions preserve information when they answer different questions.

## 13. Practice protocol

**Timed drills (three a week for four weeks).**

- *Week 1: step zero and the noise band.* Use IQ-C13-01, EX-C13-01 and EX-C13-02. Run the six questions in two minutes and say a verdict. Compute a mean and standard deviation by hand.
- *Week 2: locate.* Use IQ-C13-02, IQ-C13-03, EX-C13-03, EX-C13-04 and EX-C13-05. Do contribution, rate-and-mix and funnel arithmetic by hand, and say aloud where the change sits and why. For the SQL checks (C13.6a) add IQ-C13-08, EX-C13-11 and EX-C13-12.
- *Week 3: hypotheses and decisions.* Use IQ-C13-04, IQ-C13-05, IQ-C13-06, EX-C13-06, EX-C13-07 and EX-C13-09. Build a ledger with predictions, choose an action by severity and reversibility, and write the five-line message. For the SQL checks add IQ-C13-09, IQ-C13-10 and EX-C13-13 (run the queries on the Appendix B data).
- *Week 4: full diagnoses.* Use IQ-C13-07 and EX-C13-10, plus two prompts you have not seen. Run two 25-minute answers and one 10-minute short version, with a partner who uses the interventions in section 4 and changes the facts partway.

**With a partner.** Ask your partner to hold the data and reveal it only when you ask a specific question, and to give a surprising result at the second or third check. Practice updating the ledger aloud when the evidence changes.

**Keep a diagnosis log.** For each drill, record the order of your checks and which one found the answer. Over eight drills, see whether you check measurement first and whether your cuts are in a planned order.

**Feedback checklist (yes, partly, no).**

1. Did I confirm the change was real before explaining it?
2. Did I compare with a baseline and the normal swing, not only yesterday?
3. Did I check the cheap and common families first, in a stated order?
4. Did I locate the change with segments and funnel steps, and quantify the shares?
5. Did my hypotheses predict something I could check, and did I rule some out?
6. Did the cause match on timing, location and size?
7. Did I split rate and mix effects for an average or a rate?
8. Did I decide with severity, reversibility and the cost of waiting in view?
9. Did I give a five-line message and one preventive step?
10. Did I finish with the two-sentence close from section 4?

**Answer journal.** For each drill record the date, the prompt, the cause found, the check that found it, your score out of ten and the step you rushed. After eight drills, look for the step you skip most (usually the confirmation or the communication) and drill it alone for a week.

## 14. Implementation playbook

Apply the chapter on real work over the next three weeks. Each deliverable doubles as an interview story.

**Days 1 to 3.** For the main metric you own, write down its definition, its normal day-to-day swing, its weekday and seasonal pattern, and how long its data takes to settle. Share it with your manager and the data team. This is your step-zero card.

**Week 1.** Look at the last real change in that metric (a dip or a rise). Without looking at what was concluded at the time, run the spine on it. Compare with what the team found, and note which checks would have been faster.

**Week 1.** Ask engineering for the release log, flag changes and running experiments for the last month, and overlay them on your metric. Mark where changes line up with movements.

**Week 2.** Build a segmentation sweep for your metric: the table of cuts in order with contributions (FW-C13-04). Make it reusable, so the next time the metric moves it takes ten minutes. Ask the data team to automate it if it is valuable.

**Week 2.** Set one alert that would have caught a past problem sooner: the metric by platform or by country, or a funnel step. Write the threshold and who gets paged.

**Week 3.** Write a runbook of one page: the first fifteen minutes when the metric moves (the step-zero questions, the taxonomy order, who to ask, the five-line message template). Test it on a drill with a teammate.

**Deliverables that become stories:** the retrospective diagnosis (a time you reasoned your way to a cause in order), the segmentation sweep and alert (a time you shortened the next diagnosis), and the runbook (a time you made a team faster). Keep the numbers real, and keep what you did separate from what the team did.

## 15. Key takeaways and further reading

### Key takeaways

1. Confirm the change is real before explaining it: check the definition, the baseline and normal swing, whether the data is complete, and a second source.
2. Work through causes in a stated order, cheapest and most common first: data and instrumentation, our own changes, external events, mix shift, abuse, and a real change in behavior by elimination.
3. Locate the change with segments and funnel steps, quantify each one's share, and split an average or rate into a rate effect and a mix effect.
4. Make each hypothesis predict something you can check, and accept a cause only if it explains timing, location and size.
5. Decide by severity, reversibility and the cost of waiting, send a five-line message with a next-update time, and treat a rise with the same suspicion as a drop.

### Further reading

- Betsy Beyer, Chris Jones, Jennifer Petoff and Niall Richard Murphy (eds.), *Site Reliability Engineering* (2016), including the chapters on incident response and postmortem culture. Public practice for diagnosing and learning from failures `[V: Beyer, Jones, Petoff and Murphy, Site Reliability Engineering, O'Reilly, 2016]`.
- Ron Kohavi, Diane Tang and Ya Xu, *Trustworthy Online Controlled Experiments* (2020). Includes Twyman's law and the checks that catch bad data.
- Sidney Dekker, *The Field Guide to Understanding 'Human Error'* (2006). On investigating without blame `[V: 2nd edition, Ashgate, 2006, ISBN 9780754648260; revises The Field Guide to Human Error Investigations (2002)]`.
- Alistair Croll and Benjamin Yoskovitz, *Lean Analytics* (2013). Choosing and reading metrics at each stage `[V: O'Reilly, 2013, ISBN 9781449335670]`.
- Donella H. Meadows, *Thinking in Systems* (2008). Feedback and delays, which explain many surprising metric movements.
- Marshall Miller, "New User Trends on Wikipedia," Wikimedia Foundation Diff blog, 17 October 2025 (diff.wikimedia.org/2025/10/17/new-user-trends-on-wikipedia/). The primary source for CS-C13-02.
