---
id: C12
title: Statistics for PMs
tier: 1
competencies: [analytics, problem-solving]
prerequisites: [C05]
defines_terms: [statistical-power, p-value, confidence-interval, practical-significance, base-rate, simpsons-paradox, percentile, effect-size, standard-error, regression-to-the-mean, multiple-comparisons, survivorship-bias]
uses_terms: [metric, hypothesis, estimation, sanity-check, order-of-magnitude, sensitivity-analysis, cohort, conversion-rate, funnel, retention, churn, guardrail-metric, counter-metric, proxy-metric, goodharts-law, tradeoff, say-do-gap, experiment, randomization, causal-effect, confounder, minimum-detectable-effect, mix-shift, metric-diagnosis, latency]
frameworks: [FW-C12-01, FW-C12-02, FW-C12-03, FW-C12-04, FW-C12-05, FW-C12-06, FW-C12-07, FW-C12-08]
case_studies: [CS-C12-01 (Illustrative), CS-C12-02 (Verified)]
cross_refs_out: [C02, C03, C04, C05, C08, C13, C14, C15, C17, C21, C23, C25]
cross_refs_pending: []
status: draft
---

# C12 — Statistics for PMs

## 1. What interviewers test

Few product interviews ask a statistics question by name. Statistics arrives inside other questions: "The test shows conversion up 2% with p = 0.04; do you ship?", "Average session time rose but the median fell; why?", "How many users would you need to detect a one-point lift?", "Our fraud model flags a transaction; how worried should we be?", "Overall conversion fell, but it rose in every segment." The interviewer is not checking that you can run a test by hand. They are checking whether you have the judgment to read numbers without being fooled, and the habit of asking the questions a careful analyst would ask.

**Where it shows up.** `Inferred` from the round structures candidates commonly report: analytical, metrics and experiment questions at Google, Meta, Netflix, Amazon, Microsoft and Apple, with experiment-heavy companies asking about sample size, significance and interpretation more often `[unverified: candidate-reported]`. On the job it is the difference between a PM who ships a noise result, or kills a real one, and one who can say how sure the team is and what would change the decision.

**What is scored.** Judgment, not computation. Interviewers listen for whether you ask how many users and how noisy the data is, whether you separate "statistically detectable" from "worth doing," whether you apply a base rate before trusting an alert, whether you know the standard traps, and whether you can state uncertainty plainly to a non-specialist. They do not expect you to remember formulas, and an invented formula is worse than a rough rule you state honestly.

Six observable behaviors:

1. You state what is being compared, per what unit and over what window, before reading the result.
2. You ask for sample size and uncertainty, not only a point estimate.
3. You choose a summary (mean, median, percentile) that fits the shape of the data and the decision.
4. You read the p-value, the interval and the effect size together, and decide on practical significance.
5. You apply the base rate before trusting a flag, a test or a correlation.
6. You name the trap that could be at work (a mix shift, survivorship, regression to the mean, many comparisons) and the check for it.

**The failure this prevents.** Six patterns end analytical answers: "p below 0.05, so ship"; "no significant difference, so no effect"; an average presented without spread or size; a flag treated as a verdict because the detector is "95% accurate"; a trend taken at face value when the mix of users changed; and a segment found by slicing 20 ways and reported as a discovery.

## 2. The concept from first principles

### C12.1 Why PMs need statistics, and how far to go

Data tells you what happened to the people you measured. Statistics tells you how much that can be trusted as a statement about everyone else, and about next week. A PM needs enough to do five things: ask the right questions of an analysis, catch the common misreadings, communicate uncertainty without hiding it, size an experiment roughly, and know when to bring in a data scientist.

| Know cold | Know roughly | Delegate |
|---|---|---|
| What a mean, median and percentile say; why spread matters | How to size a sample with a rule of thumb | Choice of test, variance reduction, sequential methods |
| What an interval and a p-value mean and do not mean | What power is and why small tests miss real effects | Multiple-testing corrections, Bayesian methods |
| Base rates and natural frequencies | When a result might be a mix shift or regression to the mean | Causal inference beyond randomized tests |
| The traps and the checks | How to read a chart for what it hides | Modeling |

**The stance.** Treat every number as an estimate with a range. Ask "compared with what, how many, how noisy, and does the size matter?" before asking "is it significant?"

**When not to use the full checklist.** If the decision is cheap and reversible (a copy change that can be undone in an hour), a quick read of the direction is enough, and the cost of a careful analysis exceeds the cost of being wrong (C02's reversible-decision logic). If the data is a handful of observations, do not compute an interval; treat it as an anecdote and look for more. If the question is why a metric changed, you are diagnosing, and C13 gives the structure; this chapter supplies the tools you reach for inside it.

### C12.2 Distributions, means, medians, percentiles: why averages mislead

A **percentile** is the value below which a given share of observations fall: the 95th percentile is the value that 95% of observations do not exceed. The median is the 50th percentile. Which summary to report depends on the shape of the data and what the decision is about.

**Skew.** Many product metrics are not bell-shaped. Session length, time to complete a task, order value, revenue per user and file size have a long right tail: most observations are small and a few are very large. In such data the mean is pulled up by the tail, and the median describes the typical case.

Take ten users' session lengths in minutes: nine of 2 and one of 92. The mean is (9 × 2 + 92) ÷ 10 = 11 minutes. The median is 2 minutes. Reporting "the average session is 11 minutes" describes no one: nine of ten people spent 2.

**Which to use (FW-C12-02).**

| Question | Summary | Why |
|---|---|---|
| What happens to a typical user? | Median | Not moved by a few extreme values |
| What is the total effect (revenue, hours)? | Mean | Totals are sums, and the tail is part of the total |
| What is the worst experience most people have? | A high percentile (90th, 95th, 99th) | Guarantees and complaints come from the tail |
| What share cross a line? | A proportion | "The share of loads under 2 seconds" is easier to act on than an average |

Latency is the standard case ([[latency]], C21). A page that loads in 1.2 seconds for most people and 12 seconds for one in twenty has a fine average and an unhappy 5%. Teams therefore track percentiles. In a list of 20 load times in seconds, 1.1, 1.2, 1.2, 1.3, 1.3, 1.4, 1.5, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.3, 2.6, 3.0, 3.8, 6.5 and 12.0, the mean is 2.59 seconds, the median is 1.75 seconds, the 90th percentile (the 18th value in order) is 3.8 seconds and the 95th (the 19th) is 6.5 seconds. One number cannot carry all of that.

**Averages of averages.** Averaging group averages gives wrong answers when groups differ in size. If a segment of 1,000 users converts at 10% and a segment of 9,000 at 2%, the overall rate is (100 + 180) ÷ 10,000 = 2.8%, not (10 + 2) ÷ 2 = 6%. Weight by size, or use the totals. The same trap sits behind Simpson's paradox (C12.7).

**Why it works.** The right summary matches the question, so the reader sees what the decision depends on. **When not to belabor it.** For roughly symmetric data (heights, many survey scores), mean and median agree, and either is fine.

### C12.3 Variance, sampling, confidence intervals

**Sampling.** You almost never measure everyone. You measure a sample and want to say something about the population (all users, next month's users). Two things can go wrong, and they are different. *Noise* (random variation) shrinks as the sample grows. *Bias* (a sample that is systematically unlike the population, such as only users who opened an email, or only users who stayed) does not shrink with size: a million biased observations are a precise answer to the wrong question.

**The standard error.** The **standard error** is the standard deviation of an estimate across repeated samples, which tells you how much the estimate would move if you drew the sample again. For a proportion p measured on n independent users, it is √(p(1 − p) ÷ n). It shrinks with the square root of n: to halve the uncertainty you need four times the data.

**The confidence interval.** A **confidence interval** is a range of values consistent with the data at a stated confidence level, produced by a procedure that captures the true value at that rate over repeated samples. A 95% interval is about the estimate plus and minus 1.96 standard errors.

Take 10,000 users, of whom 4.0% convert. The standard error is √(0.04 × 0.96 ÷ 10,000) = 0.196 percentage points. The 95% interval is 4.0% ± 0.38 points, from about 3.6% to 4.4%.

**How to read it.** The careful statement: "if we repeated this procedure many times, 95% of the intervals it produced would contain the true value." The plain version for a colleague: "the data are consistent with a true rate anywhere from about 3.6% to 4.4%; values outside that range are unlikely given what we saw." Do not say "there is a 95% chance the true value is in this range" as if it were a statement about one fixed interval; the true value is fixed and the interval is what varies. In practice, the plain reading is close enough for most decisions, and what matters is that you state a range, not one number.

**A rule of thumb.** For a proportion near 50% measured on n users, the 95% margin of error is about 1 ÷ √n: ±10 points on 100 users, ±3 points on 1,000, ±1 point on 10,000. For smaller proportions the margin is smaller in absolute terms and larger in relative terms: ±0.4 points on a 4% rate with 10,000 users is ±10% of the rate itself.

**Independence.** The formula assumes each observation is independent. If you measure 100,000 page views from 5,000 users, the unit is the user, not the view: the same user's views are related, so the effective sample is closer to 5,000. Analyze at the level at which people were assigned or act (C14 for experiments).

**Why it works.** An interval turns "4.0%" into "somewhere around 3.6% to 4.4%," which is how the number should be used. **When not to compute it.** When the data are a census (every transaction of a small, fixed set) there is no sampling noise to describe, and when the sample is clearly biased, the interval is not the problem.

### C12.4 Hypothesis tests, p-values and power: what they do and do not say

A test starts with a default claim, the *null hypothesis* (the new design has no effect), and asks whether the data are surprising enough under that claim to doubt it. The **p-value** is the probability of seeing a result at least this extreme if there were no true effect. A small p-value says the data would be unusual if nothing were going on.

**What a p-value is not.** It is not the probability that the null hypothesis is true. It is not the probability that the result is "due to chance." It does not measure the size or importance of the effect. And "p = 0.04" does not mean the effect is real with 96% probability. A threshold, usually 5%, is a convention for controlling how often you call noise a signal; it is a decision rule and does not mark the edge of truth.

**Two ways to be wrong.**

| | Real effect exists | No real effect |
|---|---|---|
| Test says "significant" | Correct | False positive (type I): you ship noise |
| Test says "not significant" | Miss (type II): you discard a real effect | Correct |

**Power.** **Statistical power** is the probability that a test detects an effect of a given size when that effect really exists. It depends on the size of the effect, the noise and the sample. Low power is common and costly: a real improvement is missed most of the time, and a "significant" result from a low-powered test tends to overstate the effect.

Take a baseline conversion of 10% and a true lift to 10.5% (half a point). With 20,000 users in each arm, the observed difference would on average be 0.5 points, but the standard error of the difference is about 0.30 points, so the result is typically *not* significant: a test run at this size has only about 38% power, meaning it would miss this real effect 62% of the time, and a typical result like "10.0% against 10.5%" gives p ≈ 0.10, with an interval for the difference from about −0.1 to +1.1 points. With 57,600 users in each arm, power is about 80%, and the same observed gap gives p ≈ 0.005.

**Sample size, roughly.** For 80% power at the usual 5% significance level, the number of users needed in each arm is about **16 × p(1 − p) ÷ δ²**, where p is the control group's rate (the *baseline* in the sense C13 defines: what you would expect without the change) and δ is the smallest difference you want to detect (FW-C12-05). For p = 10% and δ = 0.5 points, that is 16 × 0.09 ÷ 0.005² = 57,600 per arm (an exact calculation gives about 57,800). The rule is not exact and is close enough to decide whether a test is feasible.

**Decide the plan first.** The significance level, the sample size and the duration should be set before the test starts. Looking repeatedly and stopping when the result crosses the threshold inflates false positives well above 5%; C14 treats this, and the other design traps, in full. State, in an interview, that you would fix these in advance.

> **Counterexample.** A team reports that variant B beats variant A: conversion 5.10% against 5.00%, p = 0.04, and plans to ship. Asked about size, the candidate who built the report says "400,000 users per arm," and asked about the interval, there is none. The interval for the difference runs from about +0.004 to +0.196 points, so the data are consistent with a true gain anywhere from nothing worth measuring to about four percent in relative terms. The result is statistically detectable and only barely, and the decision depends on what 0.1 points is worth against the cost of the change. "p below 0.05, ship" is a rule that ignores both the width of the range and the cost.

**Why it works.** Reading significance together with an interval and an effect size makes the decision about value, not about a threshold. **When not to run a formal test.** When the effect would be obvious or the decision is reversible and cheap, direction and a glance at the interval are enough; and when the sample cannot reach a useful power, say so and decide on judgment and a staged rollout (C17 and C14).

### C12.5 Effect size and practical significance

An **effect size** is the size of a difference or relationship, stated in units that can be compared with a decision threshold (absolute points, relative percent, or standardized units). **Practical significance** is whether an effect is large enough to matter for the decision, regardless of whether it is statistically significant.

**Absolute and relative.** A move from 5.0% to 5.1% is +0.1 points absolute and +2% relative. Both are true, and they feel different. Report both, and attach the absolute change to the number of people: 0.1 points of 10,000,000 monthly visitors is 10,000 more conversions a month.

**Statistical and practical significance differ.** With enough users, any tiny difference becomes detectable. With 10,000,000 users in each arm, a 0.02-point lift can be "significant" and worth little. With 2,000 users, a large improvement can be invisible. So ask two separate questions: *Can we tell the effect from zero?* (statistical) and *Is the effect big enough that we would act on it?* (practical).

**The decision threshold.** Before the test, write the smallest effect that would change the decision, given the cost of building, maintaining and the risk of the change. This is the *minimum detectable effect* in design terms (the term is owned by C14), and it should come from the decision, not from what the sample can detect. A common error is to choose the effect size to make the test affordable and then call whatever comes out a finding.

**Reading the interval against the threshold.** Compare the whole interval with the threshold:

- Interval entirely above the threshold: the effect is big enough; ship.
- Interval entirely below the threshold (including a narrow range around zero): not big enough; the change does not pay, whether or not it is "significant."
- Interval straddling the threshold: you do not yet know; more data or a judgment under uncertainty.

**Why it works.** It converts statistical output into the language of the decision. **When not to use it.** When the metric is a guardrail you only need to protect (C05), the question is whether the interval rules out harm beyond a tolerance, not whether the effect is large.

### C12.6 Base rates and conditional probability

A **base rate** is how common something is in the population before any new evidence is considered. Ignoring it is one of the most common reasoning errors, and it appears whenever a detector, a model or a test is described by its accuracy.

**Natural frequencies.** The reliable way to reason is to turn probabilities into counts of people (FW-C12-06). Take a fraud detector that catches 90% of fraudulent transactions and wrongly flags 5% of legitimate ones, applied where 1% of transactions are fraudulent. Imagine 10,000 transactions.

- 100 are fraudulent; the detector flags 90 of them.
- 9,900 are legitimate; the detector flags 5% of them, which is 495.
- Total flagged: 90 + 495 = 585. Of these, 90 are fraud.

So when a transaction is flagged, the chance it is fraud is 90 ÷ 585, about 15%. The detector "is 90% accurate" in one sense and a flag is wrong 85% of the time. The base rate (1%) is why. If the false-flag rate fell to 1%, legitimate flags would be 99, and the chance a flag is fraud would rise to 90 ÷ 189, about 48%.

**Why it matters for product.** The same arithmetic governs spam filters, moderation queues, churn-risk alerts, security warnings and "users who do X retain better." A churn model that catches 70% of churners and wrongly flags 10% of stayers, applied where 5% churn in a month, produces flags that are right about 27% of the time (35 of 130 in a group of 1,000). Whether that is useful depends on what a flag triggers: a free email is cheap and a phone call is not.

**Conditional probability** is the probability of one thing given another, and it is not symmetric: the share of fraud cases that are flagged (90%) is not the share of flags that are fraud (15%). Interviewers like to see you separate the two.

**Why it works.** Counts are easier to hold than percentages, and they expose the large group of legitimate cases that dominate the flags. **When not to use it.** When the base rate is near 50% the effect is small, and when the cost of a miss is so high that you accept many false alarms, the base rate shapes the process but not the decision.

### C12.7 Traps: Simpson's paradox, survivorship bias, regression to the mean, multiple comparisons

Four traps produce most of the confident wrong conclusions. FW-C12-07 pairs each with how to spot it and what to check.

**Simpson's paradox.** **Simpson's paradox** is a pattern in which a trend appears in every subgroup but reverses or disappears when the groups are combined. It happens when the mix of subgroups differs between the things compared. Take a redesign (invented). Before: desktop had 6,000 visits and 600 conversions (10%), and mobile had 4,000 visits and 120 conversions (3%): overall 720 of 10,000, or 7.2%. After: desktop had 2,000 visits and 220 conversions (11%), and mobile had 8,000 visits and 288 conversions (3.6%): overall 508 of 10,000, or 5.08%.

Conversion rose on desktop (10% to 11%) and on mobile (3% to 3.6%), and fell overall (7.2% to 5.08%). The cause is a shift in the mix: mobile went from 40% to 80% of visits, and mobile converts less. Neither "the redesign hurt" nor "the redesign helped" is the whole truth. The check is to break any change in a rate down by the main segments and ask whether the mix changed (C13 calls this a mix shift). The Berkeley admissions case in section 10 is the classic real example.

**Survivorship bias.** **Survivorship bias** is drawing conclusions from the items that remain after a selection process while ignoring those removed by it. "Users who stay a year love the product" tells you about the people who stayed. A retention chart that includes only active users hides everyone who left. Reviews, case studies and best-practice stories have the same flaw. The check is to ask what was removed and whether the removed look different.

**Regression to the mean.** **Regression to the mean** is the tendency for unusually high or low measurements to be followed by measurements closer to the average, because part of the extreme was chance. Take 100 pages whose true conversion is the same 5% (invented), each measured on 200 visitors. The measured rate varies by chance by about 1.5 points either way. The 10 worst pages show about 2.3% on average. Change nothing, and next week they average about 5%: a rise of more than 100% in relative terms that looks like the effect of a fix. If a team "fixes the worst pages" and sees them improve, some or all of the gain may be this. The check is a control group chosen the same way, or a random assignment of the fix.

**Multiple comparisons.** **Multiple comparisons** is the inflation of false-positive chances when many tests or segments are examined and the most striking result is reported. At a 5% threshold, one test has a 5% chance of a false positive when nothing is going on. Slice a result 20 ways and the chance of at least one "significant" segment is 1 − 0.95²⁰, about 64%. Five slices give 23%, ten give 40%. The check is to count how many comparisons were made, to state the hypothesis before looking, and to treat a surprising segment as a hypothesis for a new test, not as a finding. A crude correction divides the threshold by the number of comparisons (20 comparisons: 0.05 ÷ 20 = 0.0025).

**Twyman's law.** A useful heuristic ties these together: a number that looks too interesting or too good is more likely a mistake than a discovery. Look for the error (a logging change, a duplicate, a changed definition) before building a story.

**Why it works.** A short list of traps and checks catches most bad conclusions. **When not to over-apply it.** Not every pattern is a trap, and naming Simpson's paradox for a simple rise is noise; use it when a mix actually changed.

### C12.8 Reading charts and tables critically

Most numbers reach a PM as a chart or a table. FW-C12-08 is a checklist to read them.

- **Axes.** Does the vertical axis start at zero? A truncated axis makes a small change look large. Are two lines on different scales (dual axes)? The apparent correlation can be arranged by choosing the scales.
- **Denominator and unit.** Is it a count or a rate? A count of events rises when users grow. A rate per user or per visit may not.
- **Sample size.** Is *n* shown? A rate from 12 users is not comparable to a rate from 12,000.
- **Uncertainty.** Are there intervals or bands? A line moving 0.2 points with a margin of ±0.5 shows nothing.
- **Time window.** Does the window include a holiday, a launch or a logging change? Does a cumulative chart hide a recent slowdown because earlier growth dominates the total?
- **Segment mix.** Did the composition of users change over the period (C12.7)?
- **Survivorship.** Does a cohort chart include only users who remained?
- **Definition.** Did the definition of the metric change? Sudden breaks often come from the measurement and not the users.

**Why it works.** The checklist asks what the chart omits, which is where misreadings live. **When not to run it all.** Pick the two most likely problems for the chart in front of you.

### C12.9 Back-of-envelope statistics without a calculator

In an interview you usually cannot compute. Rules you can hold in your head, and say aloud as approximations (C04's estimation habits apply):

- **Margin of error.** For a proportion near 50%, the 95% margin is about 1 ÷ √n. For a smaller proportion p, about 2 × √(p(1 − p) ÷ n).
- **Four times the data, half the uncertainty.** Precision grows with the square root of the sample size.
- **The rule of 16.** Users per arm for 80% power at 5% significance: about 16 × p(1 − p) ÷ δ².
- **Duration.** Users per arm divided by the daily eligible users per arm gives days. Round up to whole weeks so each weekday appears equally.
- **Counts.** For a count of events, the noise is about the square root of the count: 400 events give ±20 (5%), and 25 events give ±5 (20%).
- **The rule of three.** If an event occurs zero times in n independent trials, the 95% upper bound on its rate is about 3 ÷ n: no failures in 1,000 launches is consistent with a failure rate up to about 0.3%.
- **Order of magnitude first.** If the effect you need is far smaller than the noise, you will not see it with the traffic you have.

**Why it works.** Approximations let you judge feasibility in the room, and stating them as approximations is credible. **When not to use them.** When the stakes are high and the data is small or odd, call a data scientist.

### C12.10 Where the rest is

Section 5 gives four worked examples: reading a test result, sizing a test, a base-rate decision and a Simpson's paradox diagnosis. Section 11 adds seven questions with model answers. C14 covers the design of experiments and the traps specific to them, C13 uses these tools to diagnose a metric change, and C23 and C25 use base rates and error counts for models and evaluations.

## 3. Frameworks

Eight frameworks, set out below. The metric definition card (FW-C05-01), the cohort reading guide (FW-C05-05), the estimation protocol (FW-C04-01) and the range method (FW-C04-06) are reused, not repeated.

#### FW-C12-01 · The six-question statistics check · Original

**Core framework.** Learn this one first.

- **Inputs:** a claim supported by numbers: a metric that moved, a test result or a chart.
- **Outputs:** answers to six questions, a verdict (trust, trust with limits, do not trust yet) and the next check.
- **Assumptions:** the data can be inspected or the questions put to the analyst.
- **Tradeoffs:** thoroughness slows the response; the questions take a minute and prevent costly errors.
- **Failure modes:** asking only "is it significant?"; skipping the unit; treating the checklist as a script.
- **Worked example:** the test read-out in Worked example 1 and IQ-C12-03.

| # | Question | What it catches |
|---|---|---|
| 1 | What exactly is compared, per what unit, over what window? | Wrong denominator; views counted as users |
| 2 | How many, and how noisy? | Tiny samples; missing intervals |
| 3 | Compared with what? | Biased comparison; no control |
| 4 | Could the mix or selection explain it? | Simpson's paradox; survivorship; regression to the mean |
| 5 | How many things were looked at? | Many comparisons; peeking |
| 6 | Is the effect big enough to matter? | Detectable but trivial effects |

#### FW-C12-02 · The summary selector · Original

- **Inputs:** a metric, its distribution (if known) and the decision.
- **Outputs:** a choice of mean, median, a percentile or a proportion, with the reason, and the second number to show beside it.
- **Assumptions:** you can guess the shape (skewed or not) from what the metric measures.
- **Tradeoffs:** one number is easy to communicate and hides shape; two numbers say more and take longer.
- **Failure modes:** reporting the mean of a skewed metric as "typical"; using the median for a total; reporting only an average latency.
- **Worked example:** the session-length case in C12.2 and IQ-C12-01.

| Question | Use |
|---|---|
| Typical user | Median |
| Total (revenue, hours) | Mean (or the sum) |
| Worst common experience | 90th, 95th or 99th percentile |
| Share meeting a bar | Proportion |

Always show a measure of spread or the size of the group next to the headline.

#### FW-C12-03 · The interval reading card · Original

- **Inputs:** an estimate and its interval (or the data to compute one).
- **Outputs:** a one-sentence plain-language statement, a comparison with the decision threshold, and a note on what would narrow it.
- **Assumptions:** observations are independent at the unit analyzed; the sample is not badly biased.
- **Tradeoffs:** an interval conveys uncertainty and can look like indecision to a hurried audience.
- **Failure modes:** reporting a point estimate alone; reading the interval as the range of individual outcomes; treating overlapping intervals as proof of no difference.
- **Worked example:** the 4.0% conversion interval in C12.3, and IQ-C12-02.

Template: "We measured [X] on [n] [units]. The best estimate is [value]; the data are consistent with anything from [low] to [high]. The smallest value that would change our decision is [threshold], so [the interval is above, below, or straddles it]. To narrow it we would need [about four times the data for half the width]."

#### FW-C12-04 · The significance triage · Original

- **Inputs:** a test result with a p-value, an interval for the effect and a decision threshold set in advance.
- **Outputs:** a classification into one of four outcomes and the action for each.
- **Assumptions:** the test was designed and run as planned (no peeking, no sample-ratio problem; C14).
- **Tradeoffs:** four boxes simplify a continuous picture; the intervals should still be read.
- **Failure modes:** shipping "significant but tiny"; discarding "not significant and imprecise"; skipping the threshold.
- **Worked example:** the four results in EX-C12-05, and IQ-C12-03.

| Outcome | What it looks like | Action |
|---|---|---|
| Significant and big | Interval entirely above the threshold | Ship; check guardrails |
| Significant but small | Detectable, but the interval is mostly or wholly below the threshold | Usually do not ship unless the change is nearly free; consider the cost |
| Not significant and precise | The interval is narrow around zero, below the threshold | Conclude no worthwhile effect; stop |
| Not significant and imprecise | The interval is wide and includes both zero and the threshold | You do not know; get more data, or decide on judgment and a staged rollout |

#### FW-C12-05 · The rule-of-16 sample-size sketch · Original

- **Inputs:** a baseline rate, the smallest effect worth detecting, and daily eligible traffic.
- **Outputs:** users per arm, test duration in whole weeks, and options if the test is too long.
- **Assumptions:** a two-arm test on a proportion, 80% power, 5% two-sided significance, independent users (C14 for others).
- **Tradeoffs:** the rule is within a few percent of exact for common cases and is not a substitute for a proper power analysis on important tests.
- **Failure modes:** choosing the effect to fit the sample; forgetting that traffic is split between arms; ignoring weekly cycles.
- **Worked example:** the 10% to 10.5% example in C12.4 and IQ-C12-04.

Steps: (1) write the baseline p and the smallest worthwhile effect δ; (2) n per arm ≈ 16 × p(1 − p) ÷ δ²; (3) divide by the daily eligible users per arm for days; round up to whole weeks; (4) if too long, raise the minimum effect, reduce noise (a more sensitive metric, a narrower population), accept lower power and a staged rollout, or choose a different test.

#### FW-C12-06 · The natural-frequencies table · Established

- **Origin:** Gerd Gigerenzer and Ulrich Hoffrage, "How to Improve Bayesian Reasoning Without Instruction: Frequency Formats," *Psychological Review* (1995) `[V: Psychological Review 102(4), 1995, pages 684 to 704]`.
- **Inputs:** a base rate, the detector's hit rate and its false-alarm rate.
- **Outputs:** a table of counts for a group of 1,000 or 10,000, and the share of flags that are true.
- **Assumptions:** the rates are known or can be assumed; the group is representative.
- **Tradeoffs:** counts make the answer intuitive and hide uncertainty in the rates.
- **Failure modes:** using too small a group, so the counts are fractions; confusing the hit rate with the share of flags that are true; ignoring the cost of each kind of error.
- **Worked example:** the fraud detector in C12.6, and IQ-C12-05.

| Group of 10,000 | Flagged | Not flagged | Total |
|---|---|---|---|
| Fraud (1%) | 90 | 10 | 100 |
| Legitimate (99%) | 495 | 9,405 | 9,900 |
| All | 585 | 9,415 | 10,000 |

Share of flags that are fraud: 90 ÷ 585 ≈ 15%.

#### FW-C12-07 · The trap detector · Original

**Core framework.** Learn this one first.

- **Inputs:** a surprising or convenient pattern.
- **Outputs:** the trap most likely at work, the check to run, and the claim you can still make.
- **Assumptions:** the data can be split by the suspected factor.
- **Tradeoffs:** checking costs time; skipping it costs credibility.
- **Failure modes:** naming a trap by reflex; running checks that cannot discriminate; stopping at the first trap found.
- **Worked example:** the redesign in C12.7, and IQ-C12-06.

| Trap | The tell | The check |
|---|---|---|
| Simpson's paradox (mix shift) | A rate falls overall while rising in groups; the mix of users changed | Break down by the main segments and compare the mix |
| Survivorship bias | Only those who remained are in the data | Ask who was removed and whether they differ |
| Regression to the mean | A group selected for an extreme value "improves" or "declines" | Compare with a control selected the same way |
| Many comparisons | A striking segment among many sliced | Count the comparisons; set the hypothesis first; retest |
| Too good to be true | An implausibly large move | Look for a logging, definition or duplication error |

#### FW-C12-08 · The chart reading checklist · Original

- **Inputs:** a chart or table.
- **Outputs:** the two or three most likely problems and one question to put to the author.
- **Assumptions:** you can ask for the underlying data or a definition.
- **Tradeoffs:** skepticism slows a meeting; blind trust speeds it and risks a wrong decision.
- **Failure modes:** a scan that finds nothing because it was not specific; hostility toward the analyst; checking every item every time.
- **Worked example:** the dashboard in EX-C12-10.

Check: **axes** (zero baseline, dual scales), **denominator** (count or rate), **n**, **uncertainty**, **window** (holidays, launches, cumulative effects), **mix**, **survivorship**, **definition changes**.

## 4. Answer architecture

### The data-interpretation answer, for a 10 to 15 minute segment

Statistics questions are usually part of a longer round, so the time budget is for the segment.

| Step | Minutes (of 15) | What to produce |
|---|---|---|
| Restate and fix the comparison | 2 | What is compared, per what unit, over what window; the decision at stake |
| Size and noise | 3 | How many; the interval or a rough one; what the summary hides |
| Validity | 3 | The trap most likely at work and the check; what else could explain it |
| Importance | 3 | The effect against the decision threshold; the cost of being wrong |
| Decision and next step | 3 | Ship, hold, or get more data, with the rule and what would change it |
| Slack | 1 | |

**Pacing rules.** If the interviewer gives numbers, compute roughly and say the assumptions. If they do not, ask for the sample size and the spread, and if they cannot supply them say what you would need. If you do not know a method, say what you would ask the data scientist and why, which is judgment and not a gap.

**How to say it.** Lead with the decision-relevant statement: "The result is consistent with anything from no effect to about a four percent lift, so I would not call it a win yet." Then give the reason in one sentence and the next step.

**How to close.** Two sentences: "I'd [ship / hold / extend] because [the interval against the threshold, the base rate or the check]. I'd change my mind if [a specific result]."

### Type: explain a concept to a non-specialist

Give a plain definition, one example with numbers, and one thing it does not mean. Avoid jargon; use counts. Offer the careful version only if asked.

### Type: interpret a test result

Use the six-question check (FW-C12-01) and the triage (FW-C12-04). Ask for the interval and the pre-set threshold.

### Type: size a test

Use the rule of 16 (FW-C12-05), say it is a sketch, convert to weeks, and list options if the test is too long.

### Type: spot the flaw

Name the likely trap from the table (FW-C12-07), say how you would check it, and say what you can still conclude.

### Type: the short version (5 minutes)

Name the unit, the missing interval or sample size, one trap and a decision. Protect the decision.

### Common interviewer interventions, and what to do

| Interviewer says | What it means | What to do |
|---|---|---|
| "What does the p-value tell you?" | They are testing the definition | Say what it is and one thing it is not |
| "Is that big enough to matter?" | You stopped at significance | Compare the interval with the decision threshold |
| "How many users would you need?" | They want a sketch | Use the rule of 16 and say it is approximate |
| "Why might the average be misleading?" | Skew or mix | Describe the shape and name the better summary |
| "The detector is 95% accurate. Is that good?" | Base rate | Build the counts table |
| "What if you looked at segments?" | Many comparisons | Count the comparisons and say you would retest |
| "What would you do if the test is underpowered?" | A decision under uncertainty | Raise the minimum effect, narrow the metric, or use a staged rollout, and say the risk |

## 5. Worked examples

All four examples are `Illustrative`: the products are fictional and every figure is an invented assumption. The arithmetic was computed, not estimated by eye, and the rounding is stated. Each is written as notes you could say aloud; a spoken answer is shorter.

### Worked example 1 — Reading a test result: significant, and not worth shipping (Illustrative)

**The situation.** A shop tests a redesigned promotion banner (invented). Control: 3.00% of visitors buy. Variant: 3.12%. There were 250,000 visitors in each arm. The engineer says, "It's significant, p = 0.014. Ship it."

**Step 1: fix the comparison (FW-C12-01).** Per visitor, over the test window, each visitor in one arm only. The absolute lift is +0.12 points; the relative lift is +4%. I'd confirm that visitors were randomly assigned and that the arms are the same size, and that the test ran for whole weeks.

**Step 2: size and noise.** With 250,000 per arm, the standard error of the difference is about 0.049 points. The 95% interval for the lift is about +0.02 to +0.22 points. The data are consistent with a true gain from almost nothing to about two tenths of a point.

**Step 3: the threshold.** Before judging, I'd ask what the change must earn. Assume 6,000,000 visitors a month, a contribution of $10 per extra purchase, and a cost to build and keep the feature of $1,800,000 a year (invented: a team of three and its upkeep). Break-even is $1,800,000 ÷ 12 ÷ $10 = 15,000 extra purchases a month, which is 15,000 ÷ 6,000,000 = 0.25 points. That is the smallest effect worth acting on.

**Step 4: read the interval against the threshold (FW-C12-03, FW-C12-04).** The best estimate, +0.12 points, is worth 6,000,000 × 0.0012 × $10 × 12 = $864,000 a year. The top of the interval, +0.22 points, is worth about $1,584,000 a year. Even the optimistic end is below $1,800,000. The whole interval lies below the threshold. This is "significant but small": the effect is probably real and not worth its cost.

**Step 5: the decision.** "I would not ship it as built. The result is statistically detectable and its whole range is below what we need to earn back the cost. I'd either drop it or look for a cheaper way to deliver the same message. If the feature cost almost nothing to keep, the answer would flip, since a real positive effect would be free money. What would change my mind: a cost estimate far below $1.8 million, or a follow-up test on a stronger variant."

**What this shows.** The p-value answered "can we tell it from zero?" and the decision needed "is it big enough?" The two came apart because the sample was large.

### Worked example 2 — Sizing a test: how long will it take? (Illustrative)

**The situation.** A product team wants to test an onboarding change meant to raise activation from 20% (invented). About 1,500 new users arrive a day, half per arm: 750 per arm per day. How long must the test run?

**The rule (FW-C12-05).** Users per arm ≈ 16 × p(1 − p) ÷ δ², where p = 0.20, so p(1 − p) = 0.16.

| Smallest lift worth detecting (δ) | Users per arm (rule) | Exact (for reference) | Days at 750 per arm | Whole weeks |
|---|---|---|---|---|
| 3 points | 2,844 | about 2,940 | 3.8 | 1 |
| 2 points | 6,400 | about 6,510 | 8.5 | 2 |
| 1 point | 25,600 | about 25,580 | 34.1 | 5 |
| 0.5 points | 102,400 | about 101,400 | 136.5 | 20 |

Two lessons. Halving the effect you want to detect quadruples the sample, so the cost of precision rises fast. And the rule is within a few percent of the exact value here, close enough to decide feasibility.

**What the team should do.** The smallest worthwhile lift should come from the decision, not from the calendar. Suppose the change would justify its cost at +2 points: the test needs two weeks, which is fine. If it only paid at +1 point, five weeks is a long time for a change this size, and I'd ask what else could be done.

**If the test is too long.** Options in order of preference: raise the minimum effect if the decision allows it (a change that matters only at +0.5 points may not be worth testing); reduce noise by measuring a metric closer to the change (for example, completing the first step rather than activation); narrow the population to people the change is meant for; accept lower power and release in stages with a guardrail (C17); or decide on judgment and say so. I would not choose a larger effect size merely to make the test fit and then report whatever comes out.

**Whole weeks.** Round up to full weeks so that each day of the week appears equally in both arms, since behavior differs on weekends.

### Worked example 3 — Base rates: should every flag be reviewed? (Illustrative)

**The situation.** A platform's classifier flags posts that may break its rules (invented). About 0.5% of posts violate the rules. The classifier catches 80% of violating posts and wrongly flags 2% of acceptable ones. The platform sees 100,000 posts a day, and reviewers can handle 1,000 flags a day. The team asks whether to remove flagged posts automatically.

**Natural frequencies (FW-C12-06).** Take 100,000 posts.

| Group of 100,000 posts | Flagged | Not flagged | Total |
|---|---|---|---|
| Violating (0.5%) | 400 | 100 | 500 |
| Acceptable (99.5%) | 1,990 | 97,510 | 99,500 |
| All | 2,390 | 97,610 | 100,000 |

When a post is flagged, the chance it violates the rules is 400 ÷ 2,390, about 17%. Five of six flags are wrong. Removing every flagged post automatically would take down 1,990 acceptable posts for every 400 violating ones. The classifier's "80% catch rate" and the share of flags that are right are different numbers.

**The tradeoff.** Tighten the classifier so it catches 60% and wrongly flags 0.5%. Of 100,000 posts: 300 violating posts are flagged, and 497.5 acceptable ones, so 797.5 flags in total, of which 300 ÷ 797.5, about 38%, are right. The daily queue shrinks from 2,390 flags, more than twice the reviewers' capacity, to about 800, which fits. The cost is that 200 violating posts go unflagged instead of 100.

**The decision.** I would not remove posts automatically at the first setting. A tiered process fits the numbers: automatic action only for flags where the classifier is very confident and the harm is severe (where the share of correct flags is high), human review for the middle, and no action for low scores, with an appeal route for removed posts. The right threshold depends on the cost of each error: a wrongly removed post harms a person's trust, and a missed violation harms others. State both costs, set the threshold with the policy team, and measure reviewer-confirmed precision weekly. A change in the base rate (a wave of abuse) changes the precision without the classifier changing, so the numbers must be recomputed when the mix of posts changes.

**What this shows.** Flags are mostly false alarms when the thing is rare, even for a good detector. Counts make that visible.

### Worked example 4 — Simpson's paradox: resolution rate fell while it rose everywhere (Illustrative)

**The situation.** A support team reports that the share of tickets resolved on first contact fell from 82% to 75% after it added chat support (invented). Leadership asks if chat made support worse.

**The data.**

| | Before: tickets | Before: resolved | Before rate | After: tickets | After: resolved | After rate |
|---|---|---|---|---|---|---|
| Email | 8,000 | 6,800 | 85% | 2,000 | 1,740 | 87% |
| Chat | 2,000 | 1,400 | 70% | 8,000 | 5,760 | 72% |
| All | 10,000 | 8,200 | 82% | 10,000 | 7,500 | 75% |

**Read it (FW-C12-07).** Resolution improved in both channels: email from 85% to 87%, chat from 70% to 72%. It fell overall because the mix changed: chat went from 20% to 80% of tickets, and chat resolves fewer tickets on first contact than email does. This is Simpson's paradox, and a mix shift (C13).

**A like-for-like comparison.** Hold the mix at its old level (80% email, 20% chat) and apply the new rates: 0.8 × 87% + 0.2 × 72% = 69.6% + 14.4% = 84.0%. Against 82% before, that is a 2-point improvement at constant mix.

**What I would say.** "The headline fell because customers moved to chat, which resolves fewer tickets on first contact. Within each channel resolution improved. Whether the move to chat is good depends on things the resolution rate does not show: the cost per ticket, customer satisfaction, and whether the lower chat rate is acceptable or can be raised. I would report resolution by channel and mix-adjusted, and set a target for chat separately."

**What to check next.** Whether chat tickets are harder or only different (the type of problem differs by channel); whether customers who would have emailed now chat and whether any customers were lost; and whether the definition of "resolved on first contact" is the same in both channels, since a metric that means different things in two channels invites a false story.

**What this shows.** A rate is an average over a mix, and a change in the mix can move the average against the trend in every part.

## 6. Baseline, Strong, Standout

**Prompt:** "The team says users who use our new 'saved searches' feature retain 30% better than users who don't. Should we invest in pushing more people to use it?"

### Baseline answer

"Thirty percent is a big difference, so yes. I'd promote the feature on the home screen and in onboarding so more people use it."

*What is wrong:* a correlation is treated as an effect. There is no question about who uses the feature, how many were measured, or how the comparison was made. The answer ignores the possibility that engaged users are the ones who find and use features.

### Strong answer

"I'd first ask how the comparison was made and how many users are in each group. Users who choose a feature are usually the more engaged ones, so a retention gap may reflect who they are and not what the feature does. That is selection. I'd want to know whether the groups differ before the feature, for example in their activity in the weeks before.

"I'd also check how much data sits behind 30%: if it is 200 users in each group the interval is wide. And I'd ask what 30% means: relative retention (say 50% against 65%) or something else.

"To learn whether the feature causes better retention I'd run an experiment: randomly show the feature prominently to half of eligible users and compare retention. If the promoted group retains better, promoting it is worth doing, and the size of the gap tells us how much."

### Standout answer

Everything in the Strong answer, plus:

"There is a second bias that is easy to miss: users have to stay long enough to find and use a feature. Someone who left on day two never had the chance to use saved searches, so the 'non-users' include everyone who churned early, and the 'users' are survivors. That alone can produce a retention gap with no effect from the feature, and it is why I'd define users by behavior in a fixed early window and measure retention after it.

"I'd also say how much of the gap I believe. If the engaged-user effect is large, perhaps most of the 30% is selection. I would not credit the feature with more than a fraction of it in a sizing, and I'd say which fraction and why (the sizing ladder in C08, and C14 on how to test it).

"The decision rule before the test: promote the feature widely only if the randomized gain, in the interval, exceeds what promotion costs us in screen space and attention, and check a guardrail, since a prominent feature can distract from the core task. If a randomized test is not possible, I'd compare users with similar activity before the feature appeared and treat the result as weaker evidence.

"What would change my mind: a randomized gain near zero, in which case saved searches is a feature that engaged people like, and the way to improve retention is somewhere else."

### What moves an answer up a band

| From Baseline to Strong | From Strong to Standout |
|---|---|
| Asks how the groups were formed and how many users there are | Names survivorship in the definition of "users" and fixes the window |
| Separates correlation from effect and proposes a randomized test | Says how much of the gap to credit, and defines a decision rule before the test |
| Asks what the 30% means | Adds a guardrail and an alternative if randomization is impossible |

## 7. Company lens

All claims describe what companies say publicly or what candidates commonly report, not insider knowledge. Interview formats change `[as of 2026-10]`.

> **Company lens: Google [as of 2026-10].** Google engineers have published papers on running many overlapping online experiments at scale `Public` `[V: Tang, Agarwal, O'Brien and Meyer, KDD 2010]`. Candidates commonly report analytical questions that ask how you would interpret a metric movement or an experiment `Inferred`. Practical consequence: lead with the unit and the size of the sample, and say what interval you would want.

> **Company lens: Amazon [as of 2026-10].** Amazon's leadership principles include Are Right, A Lot, which asks leaders to seek diverse perspectives and work to disconfirm their beliefs, and Dive Deep, which asks leaders to be skeptical when metrics and anecdote differ `Public` `[V: Amazon's Leadership Principles, as cited by several summaries]`. Candidates commonly report follow-ups that ask whether a number could be wrong `Inferred`. Practical consequence: when a metric and a story disagree, say which you would check first and how.

> **Company lens: Meta [as of 2026-10].** Meta has published about its experimentation and measurement practices `Public` `[V: Bakshy, Eckles and Bernstein, Designing and Deploying Online Field Experiments, WWW 2014 (PlanOut, Facebook); Eckles, Karrer and Ugander, 2017, on interference]`, and candidates commonly report analytical rounds with metric and experiment questions `Inferred`. Practical consequence: expect to be asked about guardrails and counter metrics together with significance, and be ready to say what a small positive result on a very large base is worth.

> **Company lens: Microsoft [as of 2026-10].** Researchers who built Microsoft's experimentation platform have written widely about online controlled experiments, including how often surprising results turn out to be errors `Public` `[V: Kohavi and Thomke, HBR 2017, and the Bing headline case]`. Practical consequence: cite the instinct to distrust results that look too good, and name the checks (sample ratio, logging, definitions) before celebrating.

> **Company lens: Apple [as of 2026-10].** Apple has described using differential privacy to learn about usage while limiting what it can learn about individuals `Public` `[V: Apple Machine Learning Journal, Learning with Privacy at Scale (2017); Apple privacy control page]`. Third-party guides report that analytical prompts at Apple may involve products where data is limited by design `Inferred`. Practical consequence: when measurement is deliberately coarse, say how that adds noise or bias, and how you would decide with less data.

> **Company lens: Netflix [as of 2026-10].** Netflix publishes technical posts about its approach to experimentation `Public` `[V: Netflix Tech Blog posts on experimentation and resilience testing]`, and candidates commonly report data-informed questions on viewing behavior and tests `Inferred`. Practical consequence: separate a change in what people watch from a change in how much they watch, and mention that effects can fade after novelty.

> **Company lens: Stripe [as of 2026-10].** Stripe offers a machine-learning fraud product for its users `Public` `[V: Stripe pricing page and product descriptions (Radar machine learning)]`, and fraud and risk are natural settings for base-rate questions `Inferred`. Practical consequence: when asked about a detector, build the counts table for a rare event and separate the cost of a missed fraud from the cost of blocking a good customer.

## 8. Common mistakes

| # | Mistake | How to detect it | Fix |
|---|---|---|---|
| 1 | "p below 0.05, so ship" | The decision cites only significance | Read the interval against a pre-set threshold |
| 2 | "Not significant, so no effect" | A small test is called a failure | Look at the interval and the power; say "unclear" if wide |
| 3 | Reporting a mean for skewed data | "The average session is 11 minutes" | Report the median and a percentile, or the share above a bar |
| 4 | No sample size or interval | A single number | Ask for n and a range, or state that it is missing |
| 5 | Treating p as the probability the null is true | "96% chance the effect is real" | Define p correctly and give the interval |
| 6 | Ignoring the base rate | "The detector is 95% accurate" | Build the counts table |
| 7 | Averaging averages | An overall rate from group rates without weights | Use totals or weight by size |
| 8 | Missing a mix shift | A rate fell while its parts rose | Break down by the main segments and compare mixes |
| 9 | Slicing until something is significant | A striking segment among many | Count comparisons; retest; state the hypothesis first |
| 10 | Choosing the effect size to fit the sample | The "minimum effect" equals what the traffic allows | Set it from the decision and the cost |

## 9. Mental models applied

Four models, each tied to a decision in this chapter.

**The law of small numbers** (`MM-small-numbers`). Small samples vary more than people expect, and extreme results are more likely to come from small groups. The best-performing and the worst-performing cities, schools and pages tend to be the smallest, because small groups swing. When you see an extreme result, ask how many observations are behind it before looking for a cause.

**The garden of forking paths** (`MM-forking-paths`). Every choice made after seeing the data (which segment, which window, which metric, which outliers to drop) is another comparison, even when no one counted it. A result found after many unrecorded choices is weaker than its p-value says. The defense is to fix the plan in advance, to count the choices, and to retest a surprising result.

**Absence of evidence is not evidence of absence** (`MM-absence`). A test that finds no significant effect with few users has shown that it could not tell, not that nothing is there. Whether "no effect" is a fair conclusion depends on whether the interval is narrow around zero. When it is wide, say "we don't know yet."

**Start from the base rate** (`MM-base-rate`, see [[base-rate]]). Before weighing new evidence, ask how common the thing is. A positive result for something rare is mostly false alarms, and a strong-looking correlation among a few is weak. Start with the prior, update with the evidence, and expect the update to be smaller than it feels.

## Engineering, design and data-science perspectives

- **Engineering.** Statistics are only as good as the logging. Check that events are recorded once, that user and device identifiers are stable, and that assignment to experiment arms is random and recorded. A bug that duplicates events or drops them for one platform produces significant results that are wrong. Ask engineers what changed in logging whenever a metric moves suddenly.
- **Design and research.** A statistic describes how many; it does not say why. A small usability study can explain a result that a large test only detects, and a large test can show how common a problem found in a small study is. Use both, and do not let a significant number end a conversation about whether people understood the design.
- **Data science.** Bring the data scientist the decision, not only the data: what you would do under each result and the smallest effect that matters. Agree the sample size, duration and success rule before the test, and ask them to say what the analysis cannot show. Ask about intervals every time, and ask what would make them distrust the result.

## Checklist: before you trust a number

1. Do I know exactly what is compared, per what unit, over what window?
2. Do I know how many observations there are and how noisy the result is?
3. Is the summary (mean, median, percentile) right for the shape of the data?
4. Have I read the interval against a threshold set from the decision?
5. Did I apply the base rate to any flag, alert or correlation?
6. Could the mix, selection or survival explain the pattern?
7. How many things were looked at before this one was reported?
8. What would change my mind, and what is the cheapest check?

## 10. Case studies

#### CS-C12-01 · The winning variant that did nothing · Illustrative · Beginner

*Fictional composite. Every number is invented (invented).*

**Situation.** A meal-kit app tests 12 new homepage variants against the current page. The goal is to raise the share of visitors who start an order. The team picks the best variant, which shows a clear win, ships it, and reports the gain to leadership. Two months later, the share of visitors who start an order is unchanged.

**Constraints.** A small team, traffic that allowed 5,000 visitors per variant in the test period, and pressure to show a result before the quarter closed.

**Data.** Baseline: 8.0% of visitors start an order. The best variant showed 9.2% among 5,000 visitors against 8.0% among 5,000 for the control, a lift of 1.2 points, with p = 0.032. Eleven other variants showed differences from −1.0 to +0.9 points, none significant. After launch, the metric stayed near 8.0%. A retest of the winning variant against the control with 25,000 visitors in each arm showed 8.0% and 8.1%, with p = 0.68 and an interval for the difference of −0.4 to +0.6 points.

**Problem definition.** The question was why a significant win vanished on launch. As an observable problem: "A result chosen as the best of twelve comparisons was reported as if it were the only one."

**Analysis.** With 12 comparisons and no real differences, the chance that at least one variant crosses the 5% threshold is 1 − 0.95¹² = 46%, nearly a coin flip. The best of 12 noisy results is likely to be a lucky one: with 5,000 visitors per arm, the standard error of a difference is about 0.54 points, and the expected best of 12 chance results is about 1.6 standard errors above zero, around +0.9 points, so a +1.2 point "winner" is exactly what noise produces. This is the multiple-comparisons trap (C12.7) together with a "winner's curse": a result picked because it was the largest overstates the true effect. The retest, with five times the data, returned the likely truth: no worthwhile difference, and an interval that includes zero. The test was also low-powered: with 5,000 per arm, only a lift of about 1.5 points or more could be detected reliably (the rule of 16 turned around gives √(16 × 0.08 × 0.92 ÷ 5,000) ≈ 1.5 points for 80% power at an 8% base), so only large effects, or lucky ones, showed up.

**Options.**

| Option | Optimizes | Costs |
|---|---|---|
| A. Ship the winner and report the gain | Speed, and a good story | A decision based on noise; credibility when the gain does not appear |
| B. Retest the winner against the control with a larger sample before shipping | A reliable answer | One more test and a delay |
| C. Run fewer variants with more traffic each | Power and fewer comparisons | Less breadth |
| D. Use a correction for 12 comparisons (threshold 0.05 ÷ 12 = 0.0042) | Fewer false wins | The winner's p = 0.032 would not pass |

**Tradeoffs.** B costs a few weeks and protects the decision. D would have prevented the false win without a retest, at the risk of missing a real small one. A is fastest and wrong.

**Decision.** The team applies B to any winner chosen from many variants, limits future tests to four variants, and sets the threshold for a "win" in advance. The primary metric stays the share of visitors who start an order, with a guardrail on orders completed.

**Outcome.** In this fictional scenario the retest showed no difference, the team reported the correction to leadership with the interval, and it moved to a smaller number of better-grounded ideas. The next test, with four variants and 20,000 visitors each, found one variant at +1.4 points with an interval of about +0.85 to +1.95, which replicated in a confirmation run.

**Alternative outcomes.** If the retest had confirmed a lift, shipping would have been justified, and the lesson would have been the cost of waiting for the check. If the retest had been underpowered, the team would have said "unclear" and decided on judgment and a staged rollout. The lesson is the method: count the comparisons, expect the best of many to be partly luck, and confirm a selected winner before acting.

#### CS-C12-02 · Berkeley, 1973: the admissions data and Simpson's paradox · Verified · Advanced

*Sources (types): the original analysis, P. J. Bickel, E. A. Hammel and J. W. O'Connell, "Sex Bias in Graduate Admissions: Data from Berkeley," in the journal* Science *(7 February 1975), a peer-reviewed primary source; the standard dataset for the six largest departments as documented in the R datasets package and reproduced in textbooks and papers; and a news interview with the first author for background. The paper's abstract and the documentation of the standard dataset (R's UCBAdmissions, 4,526 applications to the six largest departments), which quotes it, were read; the department-level counts below are those of the standard dataset and sum to its totals, but the paper's own table was not opened. The analysis is the author's. Re-read in October 2026.*

**Situation.** In the fall of 1973 the University of California, Berkeley received about 15,000 graduate applications, of which 12,763 were complete enough for a decision, across about 101 departments and interdepartmental majors; in the data analyzed there were 8,442 male and 4,321 female applicants `[V: dataset documentation quoting Bickel et al., 1975]`, of whom about 44% of the men and about 35% of the women were admitted (the figures reported in the paper and in later summaries). University officials feared the gap indicated bias against women: the associate dean of the graduate division worried that the university might be sued, though Bickel has said it never was, and he was asked to analyze the data `[V: Journal of Statistical Distributions and Applications, 2017; Wall Street Journal interview with Bickel as quoted by a statistician]`. The authors examined the data by department.

**Constraints.** Admissions were decided by each department separately, not centrally, so any bias would have to be found in a department's decisions. The data covered applicants and outcomes, not the reasons for applying to one department or another. The widely used dataset covers the six largest departments only.

**Data.** For the six largest departments (the standard dataset): men, 2,691 applicants and 1,198 admitted (44.5%); women, 1,835 applicants and 557 admitted (30.4%).

| Department | Men: applicants | Men: admitted | Women: applicants | Women: admitted |
|---|---|---|---|---|
| A | 825 | 62% | 108 | 82% |
| B | 560 | 63% | 25 | 68% |
| C | 325 | 37% | 593 | 34% |
| D | 417 | 33% | 375 | 35% |
| E | 191 | 28% | 393 | 24% |
| F | 373 | 6% | 341 | 7% |

Women had the higher admission rate in four of the six departments (A, B, D and F), and men in two (C and E), by small margins.

**Problem definition.** *The author's reading.* The apparent problem was a 14-point gap in the overall admission rate. The question for an analyst is whether that gap reflects different treatment in the decisions or a difference in where the two groups applied.

**Analysis.** *The author's analysis.* The overall figures hide the mix. Departments A and B admitted about 62% to 63% of men and 68% to 82% of women, which makes them the easiest to enter, and 51.5% of male applicants (825 + 560 of 2,691) applied there against 7.2% of female applicants (108 + 25 of 1,835). Most women applied to departments with low rates for everyone, such as C, D, E and F, where 6% to 37% of applicants of both sexes were admitted. So the aggregate gap comes mainly from a difference in application patterns. Standardizing for the mix makes this concrete: if women had applied to departments in the same proportions as men, their expected admission rate (using their own department rates) would be about 51.6%, higher than the men's 44.5%. If men had applied in women's proportions, their expected rate would be about 30.2%, close to the women's actual 30.4%. The paper's reported conclusion, in its own summary, was that properly pooled data show a small but statistically significant bias in favor of women, and that the aggregate pattern was clear but misleading.

This is Simpson's paradox in its classic form: the aggregate favors men while most departments favor women, because the groups are distributed differently across departments that differ in difficulty (C12.7). It also shows the limits of the lesson. The department-level data say that admissions decisions were not the source of the aggregate gap. They do not say that nothing unfair happened earlier: the authors wrote that women were channeled by socialization and education toward more crowded, less well funded fields of study, before their applications reached Berkeley `[V: Bickel et al., 1975, p. 403, as quoted]`, and the statistician William Kruskal argued that observational data alone could not rule out discrimination `[V: secondary summary]`; why women applied to the more competitive fields lies outside what this data can address. A mix explains a number; it does not settle whether the mix is fair.

**Options.** *The author's reconstruction of choices the university and analysts could have faced; not a record of their deliberations.*

| Option | Optimizes | Costs |
|---|---|---|
| A. Act on the aggregate (press departments to raise female admissions) | A quick response to the gap | Intervening where the data show no bias; potential harm to decisions that were fair |
| B. Analyze by department, where decisions were made | The right unit of analysis | Time, and a less dramatic story |
| C. Ignore the gap | None | Leaves a possible problem unexamined |

**Tradeoffs.** B takes longer and responds to the question that can be answered. A responds to the headline and risks acting on a mix effect. C avoids work and risks a real problem.

**Decision.** As documented, university officials asked a statistician to analyze the data, and the analysis was done at the level of departments and published in Science on 7 February 1975, concluding that the aggregate pattern was "clear but misleading" and that, properly pooled, there was a small but statistically significant bias in favor of women `[V: Bickel et al., Science 187, 398 to 404, abstract]`.

**Outcome.** Reported: the study concluded that the aggregate pattern reflected where women applied and that departmental decisions showed few significant departures and a small bias toward women when pooled correctly. The case became a standard teaching example of Simpson's paradox. Whether any specific policy changed as a result is not established in the sources used here.

**Alternative outcomes.** *Inference.* Had the analysis been done only on the aggregate, a policy aimed at departments could have been unjustified. Had the department-level data shown consistent disadvantage to women, the aggregate gap would have been explained differently and the response would have been to examine those decisions. The method to carry away: when a rate differs between two groups, break it down by the factor that decides the outcome and compare the mix. For a PM this is the check before any story about a metric: did the rates change within the groups, or did the groups change?

## 11. Interview questions and model answers

Seven questions: two Beginner, two Intermediate, three Hard. Model answers are `Illustrative`; every figure is an assumption, and the arithmetic was computed. Each is written against the six behaviors in section 1. None is tied to a company: statistics questions appear at all of them, and the company lenses in section 7 describe how the emphasis differs. The answers are fuller than a first pass in a real round; a spoken version keeps the same order with fewer words.

#### IQ-C12-01 · Beginner · analytics · AN

**Prompt.** Average session length rose 10%, but the median fell. What might be going on?

**Rubric.**
- **Baseline:** "The data must be wrong," or "users are engaging more."
- **Strong:** Explains that a mean can rise while the median falls when the distribution is skewed, and says what to check.
- **Standout:** Gives a small numeric example, names several causes (a few very long sessions, a logging or definition change, a shift in the user mix), says which summary answers which decision, and proposes the first check.

**Model answer.** Both can be true, and the gap between them is the clue. The mean is pulled by the tail, and the median describes the typical session, so the typical session got shorter while a few long ones got longer.

A small example makes it concrete. Ten sessions before: nine of 3 minutes and one of 13. The mean is (27 + 13) ÷ 10 = 4.0 minutes and the median is 3. After: nine of 2.5 minutes and one of 21.5. The mean is (22.5 + 21.5) ÷ 10 = 4.4 minutes, up 10%, and the median is 2.5, down. The typical person spent less time, and one heavy session grew.

*What could cause it.* A few sessions got very long: a tab left open, a bot, a video that plays unattended, or a heavy user using a new feature. The definition of a session changed (for example, a longer idle timeout merges visits into one long session). The mix of users shifted: more casual users with short sessions and the same few power users. Or a real change: a new feature helps some people go deeper and makes others leave sooner.

*What I'd check first.* The distribution itself: a histogram and the 25th, 50th, 75th and 95th percentiles before and after. Then whether the session definition or logging changed, whether bots or idle sessions are included, and whether the mix of new and returning users changed. I'd break the number down by segment (C12.7) to see if the pattern is a mix effect.

*Which number to use.* It depends on the decision. If the question is "is the typical user better off?", the median and the share of sessions above a useful length. If it is "how many total hours are we delivering?", the mean, since totals are sums. I'd report both with the group sizes, and I would not call a 10% rise in the average an improvement until I know which of these it is.

**Follow-ups.**

- **Q.** What is the first check you would run? **A.** "Whether the measurement changed. A new session timeout, a logging change or a new platform can move the mean and median without any change in behavior. Then I would look at the distribution: percentiles (25th, 50th, 90th) and a histogram for before and after, and the mix of new and returning users and of platforms. If the percentiles show the middle falling and the top rising, the typical session got shorter and a few got longer. I would report both numbers and say that the median describes the typical experience and the mean describes total time."
- **Q.** Which number answers whether users spent more time? **A.** "It depends on the decision. For capacity and cost, total time matters, which is the mean times the number of sessions. For whether the typical user is getting more value, the median and the share of sessions above a threshold matter. Here the mean rose and the median fell, so total time may be up while the typical session is shorter, which could mean the product became less engaging for most users while a few heavy users carried the average. I would say that plainly and not choose the more flattering number."

#### IQ-C12-02 · Beginner · analytics · AN

**Prompt.** Explain a 95% confidence interval to a non-technical executive.

**Rubric.**
- **Baseline:** "It's the range where the true value is 95% likely to be," or a technical definition the executive cannot use.
- **Strong:** Gives a plain statement with an example, explains what it says about uncertainty, and links it to a decision.
- **Standout:** Avoids the common misreading, uses counts, ties the interval to a decision threshold, and says how more data would narrow it.

**Model answer.** I'd say it in terms of the decision. "We measured how many customers buy, in a sample of 10,000: 4.0% bought. We don't know the true rate for all customers, because we only saw some. The confidence interval is the range of true rates that are consistent with what we saw. Here it runs from about 3.6% to 4.4%. So when someone says 'conversion is 4%,' what the data really says is 'somewhere around 3.6% to 4.4%'."

*Why the width is what it is.* "The more customers we measure, the narrower the range. To make the range half as wide, we need about four times as many customers. So a bigger sample buys precision, and it buys it slowly."

*How to use it.* "If we need conversion to be at least 4.5% to justify the project, then the whole range is below the bar, so we should not expect to clear it. If the bar were 3.5%, the whole range is above it, and we can be fairly confident. If the bar were 4.0%, the range straddles it, and we don't know yet."

*What it does not mean.* "It is not the range that 95% of customers fall in. Individual customers either buy or not. And I'd be careful with the phrase '95% chance the true value is inside': the careful statement is that if we repeated the whole measurement many times, about 95% of the ranges we'd produce would contain the true value. For a decision, the plain version above is close enough."

I'd close with the one thing the executive should take away: ask for the range, not only the number.

**Follow-ups.**

- **Q.** What is the common misreading, and how do you avoid it? **A.** "The common misreading is that there is a 95% chance the true value lies in this particular interval. The careful statement is that the method produces intervals that contain the true value 95% of the time. For an executive I avoid probability language and say the interval is the range of true rates that are consistent with what we saw. I tie it to a decision: if the break-even rate is 3.5% and the interval is 3.6% to 4.4%, the product clears the bar even at the low end; if the break-even were 4.2%, the data would not settle it."
- **Q.** How would more data change the interval? **A.** "It narrows with the square root of the sample. With 10,000 customers and a 4% rate the interval is about ±0.38 points; quadrupling the sample to 40,000 halves it to about ±0.19 points. So a lot more data is needed for modest precision, and I would ask what precision the decision requires before collecting more. If the decision is the same anywhere between 3.6% and 4.4%, more data is not worth the cost."

#### IQ-C12-03 · Intermediate · analytics · AN

**Prompt.** An A/B test shows conversion up 2% (relative) with p = 0.04. Do you ship?

**Rubric.**
- **Baseline:** "Yes, it's significant," or "no, 2% is too small," without reasoning.
- **Strong:** Asks for the absolute change, the sample size and the interval, and compares with the cost.
- **Standout:** Sets the decision threshold from the cost, reads the interval against it, checks the test's validity (sample ratio, peeking, multiple metrics), and gives a decision with the condition that would change it.

**Model answer.** I'd not answer from the p-value alone. I'd ask five things.

*The numbers.* Suppose the base rate is 5.00% and the variant is 5.10%, which is a 2% relative and 0.1 point absolute lift. With 400,000 users in each arm, p comes out near 0.04. The 95% interval for the lift is about +0.004 to +0.196 points, or from nothing to about four percent in relative terms.

*What it is worth.* Suppose 10,000,000 visitors a month and $10 of contribution per extra purchase (invented). The best estimate, +0.1 point, is 10,000 purchases and about $100,000 a month. The interval runs from about $4,000 to about $196,000 a month.

*The threshold.* Suppose the change costs $50,000 to build and $5,000 a month to maintain (invented). The upkeep is covered if the lift is at least 0.005 points, which is 500 purchases a month. The lower end of the interval, 0.004 points, is just under that, and the best estimate is twenty times it. So the interval mostly clears the cost and the bottom edge touches it.

*Validity.* I'd check that the arms are the planned size (a mismatch can signal an assignment problem, covered in C14), that nobody stopped the test the first time it crossed the threshold, and that the 2% was the one metric chosen in advance, not the best of several. If we looked at five metrics and report the best, a p of 0.04 is much weaker.

*The decision.* "I would ship it, with a guardrail on a metric the change could harm, because the whole interval is above zero, most of it is above the cost, and the change is cheap and reversible. I'd tell the team the gain is probably real and could be small, and that I wouldn't plan the roadmap around +$100,000 a month. I'd change my mind if the check showed the test was not run as planned, or if the maintenance cost were several times higher, in which case the interval would straddle break-even and I'd extend the test."

**Follow-ups.**

- **Q.** What validity checks would you run before trusting the test? **A.** "First, whether the split matches the plan: with a 50/50 design, check that the arms have about equal numbers (a sample ratio mismatch suggests a bug). Second, how the test was monitored: was it stopped early when the result looked good? Third, how many metrics were examined: with 20 metrics at the 5% level, about one will look significant by chance, so I would want the primary metric named in advance. Fourth, duration: whole weeks to cover weekday patterns, and a check for a novelty effect. Fifth, whether the lift is consistent across major segments."
- **Q.** What would change your decision? **A.** "The value and the cost of shipping. With 10 million visitors a month, a 0.1-point lift is 10,000 extra conversions; at the $10 of contribution used above that is $100,000 a month, and at the low end of the interval (0.004 points) about $4,000 a month. If shipping is cheap and reversible, I would ship to a staged group with a 5% holdout for four weeks to confirm. If shipping adds maintenance cost or risk, I would ask for a replication first. Either way, I would write the decision rule before the next read."

#### IQ-C12-04 · Intermediate · analytics · AN

**Prompt.** Roughly how many users do you need to detect a one-point lift on a 10% conversion rate, and how long would that take?

**Rubric.**
- **Baseline:** "A few thousand," or "as many as possible."
- **Strong:** Uses a rule or formula, states the assumptions (power, significance), and converts to duration.
- **Standout:** Shows what happens at half the lift, states that the rule is approximate, uses whole weeks, and gives options if the test is too long.

**Model answer.** I'll use the rule of 16, which I'd say is a sketch: for 80% power at the usual 5% significance, users per arm ≈ 16 × p(1 − p) ÷ δ². Here p = 0.10, so p(1 − p) = 0.09, and δ = 0.01. That is 16 × 0.09 ÷ 0.0001 = 14,400 per arm, so about 28,800 in total. An exact calculation gives about 14,750 per arm, so the rule is within a few percent.

*Duration.* Assume 4,000 eligible users a day, split evenly: 2,000 per arm per day. 14,400 ÷ 2,000 = 7.2 days. I'd run two full weeks, not eight days, so that each weekday appears in both arms equally and any weekly cycle averages out.

*If the lift were half as large.* For δ = 0.5 points the requirement is 16 × 0.09 ÷ 0.005² = 57,600 per arm: four times as many for half the lift. That is 28.8 days at the same traffic, so five whole weeks. This is why the smallest effect worth detecting should come from the decision, not the calendar.

*If the test is too long.* I'd raise the minimum effect if the decision allows it, narrow the population to people the change targets, measure a metric closer to the change so there is less noise, or accept lower power and release in stages with a guardrail. I'd not set the effect size to fit the traffic and then report whatever comes out.

*Caveats.* The rule assumes independent users, a two-arm test on a proportion, and that I have chosen the effect and the duration before starting. If users interact (a social feature) or if I will look at the data repeatedly, a data scientist should design it.

**Follow-ups.**

- **Q.** What if you want to detect a lift of half a point instead? **A.** "The sample grows with the inverse square of the lift, so halving the lift quadruples it: n per arm = 16 × 0.09 ÷ 0.005² = 57,600, about 115,000 in total. At 4,000 eligible users a day that is about 29 days, so I would plan five whole weeks. This is why the minimum effect worth detecting should come from the business value of the lift, not from what is convenient: a test powered for a one-point lift can miss a half-point effect that is still worth shipping."
- **Q.** What if the test would take too long? **A.** "There are options. Test a bolder change with a larger effect. Choose a more sensitive metric or reduce noise, for example with a pre-experiment covariate adjustment `[V: Deng, Xu, Kohavi and Walker, CUPED, WSDM 2013, pp. 123 to 132: pre-experiment data to reduce metric variance]`. Increase the eligible traffic. Accept lower power and a wider interval and say so. Or decide on cost and reversibility without waiting for significance. I would rather state what the test can and cannot detect than run a test whose conclusion is a foregone shrug."

#### IQ-C12-05 · Hard · analytics · AN

**Prompt.** An account-takeover detector catches 95% of takeovers and wrongly flags 3% of legitimate logins. Takeovers are 0.2% of logins. What should happen when the detector flags a login?

**Rubric.**
- **Baseline:** "Lock the account, since the detector is 95% accurate."
- **Strong:** Computes the share of flags that are real with counts, and sees that most flags are false alarms.
- **Standout:** Matches the response to the cost of each error (a challenge is cheap, a lock is not), shows how the number moves with the false-alarm rate and the base rate, and sets metrics for both kinds of error.

**Model answer.** I'd build the counts for 100,000 logins.

- Takeovers: 0.2% of 100,000 is 200. The detector flags 95% of them: 190.
- Legitimate logins: 99,800. The detector flags 3%: 2,994.
- Total flags: 190 + 2,994 = 3,184. Of these, 190 are real.

The chance that a flagged login is a takeover is 190 ÷ 3,184, about 6%. Roughly 94 flags in 100 are false alarms. "95% accurate" is the catch rate among takeovers, a different number from the share of flags that are right.

*What follows for the response.* Locking the account on a flag would lock 2,994 legitimate users for every 190 attackers, which is harmful and expensive. A cheap challenge (a code sent to the user's phone) costs the legitimate user a few seconds and stops most attackers. So the response should match the cost of a wrong call: a challenge for a flag, and a lock only when the evidence is much stronger (more signals, or a failed challenge).

*How the number moves.* If the false-alarm rate fell from 3% to 0.5%, legitimate flags would be about 499 and the share of flags that are real would rise to 190 ÷ 689, about 28%. If the base rate fell (attacks drop) with the same detector, the share of real flags falls too, so the precision must be recomputed over time and not assumed fixed.

*Metrics.* Primary: the share of takeovers stopped. Guardrails: the share of legitimate logins challenged (here about 3%), challenge failure rate among legitimate users, and support contacts about lockouts. Counter metric: the time attackers spend inside an account before detection, which a looser threshold would shorten. I'd set the threshold with the security and support teams, and I'd say which cost is higher in this product, since the right balance differs by what the account holds.

**Follow-ups.**

- **Q.** How would the 6% change with a lower false-alarm rate? **A.** "A lot, because precision depends on the base rate and the false alarms together. With 100,000 logins and 190 caught takeovers: at a 3% false-alarm rate there are 2,994 false flags and 190 ÷ 3,184 is about 6% precision. At 1% there are 998 false flags and precision is 190 ÷ 1,188, about 16%. At 0.5% it is 499 false flags and 190 ÷ 689, about 28%. Improving the false-alarm rate matters more than the catch rate here, because takeovers are rare."
- **Q.** What response matches the cost of each error? **A.** "A tiered response. A flag triggers a cheap, reversible action, such as a step-up verification, since wrongly challenging a real user costs a few seconds. Locking the account needs more evidence, such as a new device plus a password change plus a high-risk action. The metrics are takeovers prevented, the share of legitimate users challenged and the false-lock rate, with a guardrail on login completion. I would review the thresholds when the base rate changes, because a campaign of attacks changes the precision of the same detector."

#### IQ-C12-06 · Hard · analytics · AN

**Prompt.** Average order value fell from $24.00 to $21.82 after a marketing push, but it rose in every country. What happened and what do you do?

**Rubric.**
- **Baseline:** "It's an error," or "the marketing push hurt order value."
- **Strong:** Identifies a mix shift (Simpson's paradox) and computes a like-for-like comparison.
- **Standout:** Notices that the shift itself (fewer orders from the high-value country) is the real question, reports a mix-adjusted figure and the revenue effect, and proposes where to look.

**Model answer.** This is Simpson's paradox: a rate that rises within every group and falls overall because the mix of groups changed. I'd confirm with the numbers (invented).

| | Before: orders | Before: average value | After: orders | After: average value |
|---|---|---|---|---|
| Country X | 1,000 | $60 | 200 | $62 |
| Country Y | 9,000 | $20 | 9,800 | $21 |
| All | 10,000 | $24.00 | 10,000 | $21.82 |

Before, revenue was 1,000 × $60 + 9,000 × $20 = $240,000, an average of $24.00. After, it was 200 × $62 + 9,800 × $21 = $12,400 + $205,800 = $218,200, an average of $21.82. Order value rose in X ($60 to $62) and in Y ($20 to $21). It fell overall because X, the high-value country, went from 10% of orders to 2%.

*A like-for-like figure.* At the old mix (10% X, 90% Y) and the new averages: 0.1 × $62 + 0.9 × $21 = $6.20 + $18.90 = $25.10, against $24.00 before, up about 4.6%. Within each country things improved.

*The real question.* The headline average is not the main problem. What matters is that orders from X fell from 1,000 to 200, and total revenue fell from $240,000 to $218,200 (about 9%) on the same 10,000 orders. The push brought more orders in Y and X shrank. I'd ask why: did the campaign pull spend and attention away from X, was there an outage, a regulatory problem, a competitor or a shipping change in X, or did the push change who is counted in X? I'd look at X's funnel before and after, by week, to find when it dropped.

*What I'd report.* Order value by country and a mix-adjusted figure, with order counts, and revenue in total. I'd not tell leadership that the push "lowered order value," since within each country it rose, and I'd not say it succeeded, since total revenue fell. The decision depends on the unit economics in each country (margin per order, cost to acquire) and on whether the shift toward Y is intended. I'd change my view if X's drop were found to be unrelated to the push, in which case two separate stories sit in one number.

**Follow-ups.**

- **Q.** How would you report a mix-adjusted figure? **A.** "By holding the mix fixed. Using the before-period mix of 10% from country X and 90% from country Y with the after-period values of $62 and $21 gives 0.10 × 62 + 0.90 × 21 = $25.10, against $24.00 before, an increase of about 4.6%. That is the like-for-like change, and it shows the average order value rose within countries. I would report both numbers and say which question each answers: the unadjusted figure answers what an average order is worth now, the adjusted one answers whether orders got more valuable."
- **Q.** What do you do about the mix shift itself? **A.** "I treat it as the real finding. Orders from country X fell from 1,000 to 200, and revenue fell from $240,000 to $218,200, about 9%, even though total orders were unchanged. I would find out why: the campaign may have reached country Y, supply or pricing in X may have changed, or X customers may have left. Then decide whether the push is a success: it brought orders from lower-value customers and lost higher-value ones. The decision depends on margins by country, so I would ask for contribution, not revenue, before changing the campaign."

#### IQ-C12-07 · Hard · analytics · AN

**Prompt.** Your data scientist says the test is underpowered and recommends running six more weeks. The launch is in two weeks. What do you do?

**Rubric.**
- **Baseline:** "Launch anyway," or "wait six weeks," without weighing the stakes.
- **Strong:** Describes what the current data does and does not say, weighs the cost of delay against the cost of being wrong, and offers options.
- **Standout:** Quantifies both sides, distinguishes reversible from irreversible decisions, proposes a staged rollout with a stopping rule and a long-run holdout, and keeps the data scientist as a partner.

**Model answer.** I'd treat it as a decision under uncertainty, not as a fight between the test and the date. First I'd ask the data scientist for what the data says now: the estimate and its interval, and what lift the test was designed to detect. Suppose the lift is +0.3 points with an interval of −0.5 to +1.1, and the team's threshold for worthwhile is +0.5.

*What the data says.* "Underpowered" means the interval is wide: it includes harm, nothing, and a gain above the threshold. I can't say the change works, and I can't say it doesn't.

*The two costs.* Delay: if the true lift is +0.5 points on 6,000,000 monthly visitors at $10 per purchase (invented), the change is worth about 30,000 purchases, $300,000 a month, so six weeks' delay costs roughly $420,000 of benefit if the change is good. Being wrong: if the true effect is −0.5 points the change costs about $300,000 a month, and the question is how fast we would see it and undo it.

*Reversibility is the deciding fact (C02).* If the change can be undone in a day, the cost of being wrong is limited to the days it runs, and the cost of delay is real. If it cannot be undone (a migration, a public commitment), I'd wait or reduce the risk differently.

*Options.* (1) Launch in stages: 10% of users, then 50%, then all, with a guardrail and a written stopping rule (stop if the guardrail metric drops by more than a set amount), while the test continues in the background with a holdout group that never gets the change, so the full six weeks of data arrive anyway. (2) Narrow the metric or population so the test is more sensitive, for example the first-step completion rate among new users, and check whether the shorter test is now adequate. (3) Raise the minimum effect: if the change only pays above +0.5 points and the data cannot rule out a smaller effect, say that the question is whether the team would act on a result of +0.3. (4) Delay six weeks, if the decision is hard to reverse.

*My recommendation.* If reversible: option 1 with the holdout. It keeps the date, caps the downside and still produces the evidence. I'd say to leadership: "We don't yet know if this helps. We'll release in steps with a stop rule, and we'll know by [date]. If it hurts, we'll pull it within a day." I'd thank the data scientist for raising the issue and ask them to own the stopping rule. I'd change my mind if the guardrail could not be measured quickly, in which case staging gives no protection and delay is safer.

**Follow-ups.**

- **Q.** How would you stage the rollout and what stopping rule would you use? **A.** "Ramp to 5%, then 25%, then 100% over the two weeks, checking guardrails at each step. The stopping rule is written in advance: stop the ramp if the lower end of the interval for the guardrail metric falls below a limit (for example, a conversion loss worse than 0.5 points) or error rates exceed twice the baseline. I would keep a 5% holdout for the six weeks the data scientist asked for, so that the original test finishes and we get the answer after launch. The launch is a feature flag, so it is reversible, which is why shipping with a holdout is reasonable."
- **Q.** How do you keep the data scientist as a partner? **A.** "By treating their warning as a requirement for the plan. I would ask them to define the stopping rule and the holdout design, document the assumptions together, and commit to reading the full result in six weeks and to reversing if it turns negative. I would present the decision to leadership as ours, with the data scientist's uncertainty stated plainly, and credit them for the guardrails. If I ignored the warning, I would lose their trust and the next test would be less honest."

## 12. Exercises

Ten exercises. Each has a model solution and an alternative. Figures are assumptions unless marked, and the arithmetic was computed.

#### EX-C12-01 · Which summary?

**Problem.** Ten order values in dollars: 12, 14, 15, 15, 16, 18, 19, 22, 25, 400. Compute the mean, the median and the 90th percentile (nearest rank). Which would you report to (a) forecast revenue, (b) describe a typical customer?

**Context.** One very large order is in the data.

**Data.** As above.

**Constraints.** Three minutes.

**Expected approach.** Use the summary selector (FW-C12-02).

**Solution.** Sum = 556, so the mean is $55.60. The median is the average of the 5th and 6th values, (16 + 18) ÷ 2 = $17. The 90th percentile by nearest rank is the 9th value, $25. (a) For a revenue forecast, the mean (or the total, $556), since revenue is a sum and the large order is part of it, though one large order is unlikely to repeat, so I'd also look at the total without it ($156, mean $17.33). (b) For a typical customer, the median, $17. The mean describes almost nobody.

**Alternative solution.** Report the median with the share of orders above $25 (10%), and the total, so each reader gets the number that fits their question.

**Tradeoffs.** A forecast built on the mean is fragile when a single order dominates it; say so.

#### EX-C12-02 · An interval by hand

**Problem.** 400 of 5,000 users clicked an email link. Compute the click rate and an approximate 95% interval. How many users would give a margin of ±0.5 points?

**Context.** You will report the click rate to a team that wants one number.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** Standard error √(p(1 − p) ÷ n); interval ± 1.96 standard errors (C12.3).

**Solution.** p = 400 ÷ 5,000 = 8.0%. Standard error = √(0.08 × 0.92 ÷ 5,000) = √0.00001472 ≈ 0.00384, or 0.38 points. The margin is 1.96 × 0.38 ≈ 0.75 points, so the interval is about 7.25% to 8.75%. For a margin of ±0.5 points, n = (1.96 ÷ 0.005)² × 0.08 × 0.92 = 153,664 × 0.0736 ≈ 11,300 users, about 2.25 times the current sample for two thirds of the margin.

**Alternative solution.** Use the shortcut margin ≈ 2 × √(p(1 − p) ÷ n) = 2 × 0.00384 = 0.77 points: close to the exact figure.

**Tradeoffs.** The formula assumes independent users and a sample that represents the population; an email list of the most engaged users would bias the rate upward.

#### EX-C12-03 · Read the interval

**Problem.** A test gives a lift of +0.3 points with a 95% interval of −0.4 to +1.0. The smallest worthwhile effect is +0.5 points. What do you conclude, and what would narrow the interval?

**Context.** The test ran as planned.

**Data.** As above.

**Constraints.** Three minutes.

**Expected approach.** Compare the whole interval with zero and with the threshold (FW-C12-03).

**Solution.** The interval includes zero (so it is not significant at 5%), includes harm down to −0.4, and includes the threshold: values from −0.4 to +1.0 are all consistent with the data, and +0.5 sits in the middle. The conclusion is "we don't know yet," not "no effect." To halve the width (from about 1.4 points to 0.7), we would need about four times the data.

**Alternative solution.** Decide on cost and reversibility: if the change is cheap and reversible, a staged rollout with a guardrail may be reasonable while the data accumulate.

**Tradeoffs.** Four times the data may be too slow; a more sensitive metric might narrow the interval faster.

#### EX-C12-04 · Size a test

**Problem.** Baseline conversion 5%. You want to detect +0.5 points. 3,000 eligible users arrive each day, split evenly. How many users per arm, how many weeks, and what if you only need +1 point?

**Context.** Use the rule of 16.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** FW-C12-05.

**Solution.** p(1 − p) = 0.05 × 0.95 = 0.0475. For δ = 0.005: 16 × 0.0475 ÷ 0.000025 = 30,400 per arm (the exact figure is about 31,200). At 1,500 per arm per day, 30,400 ÷ 1,500 = 20.3 days, so three whole weeks. For δ = 0.01: 16 × 0.0475 ÷ 0.0001 = 7,600 per arm, 5.1 days, so one whole week. Halving the effect quadruples the sample: 20.3 days against 5.1, or three whole weeks against one after rounding.

**Alternative solution.** Test a more sensitive upstream metric (for example, clicks on the new element) to detect a smaller change faster, and say that it is a proxy.

**Tradeoffs.** A one-week test misses weekly cycles beyond one full cycle; for a purchase that varies by weekday, one full week is the minimum.

#### EX-C12-05 · Triage four results

**Problem.** The smallest worthwhile lift is +1.0 point. Classify each result (lift, 95% interval) and say what to do: (a) +2.5, [+1.6, +3.4]; (b) +0.15, [+0.05, +0.25]; (c) +0.05, [−0.15, +0.25]; (d) +0.8, [−0.9, +2.5].

**Context.** All tests ran as planned.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** Use the significance triage (FW-C12-04).

**Solution.** (a) Significant and big: the whole interval is above +1.0; ship and check guardrails. (b) Significant but small: the interval excludes zero and sits wholly below the threshold; do not ship unless it is nearly free. (c) Not significant and precise: the interval is narrow around zero and below the threshold; conclude there is no worthwhile effect and stop. (d) Not significant and imprecise: the interval includes harm, zero, and values above the threshold; we don't know. Get more data, or release in stages if the change is cheap and reversible.

**Alternative solution.** For (b), if the change costs nothing to keep and carries no risk, shipping can still be right, because a real small gain is free.

**Tradeoffs.** The threshold must be set before the test; set afterward, it can be bent to fit the result.

#### EX-C12-06 · A base-rate calculation

**Problem.** A quiz flags "likely power users." 10% of users are power users. The quiz identifies 60% of power users and wrongly flags 15% of other users. Of 1,000 users, how many are flagged, and what share of flags are power users? If the perk offered to each flagged user costs $20, what is the cost per true power user reached?

**Context.** The team plans to give the perk to every flagged user.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** Natural frequencies (FW-C12-06).

**Solution.** Power users: 100; flagged: 60. Others: 900; wrongly flagged: 135. Total flagged: 195. The share of flags that are power users is 60 ÷ 195 ≈ 31%. Cost: 195 × $20 = $3,900, which reaches 60 power users, $65 each. 69% of the spend goes to people who are not power users.

**Alternative solution.** Raise the bar (a stricter quiz) to cut false flags, or give a cheaper perk to flagged users and a larger one only after a second signal.

**Tradeoffs.** A stricter quiz misses more power users; the right bar depends on what a missed power user and a wasted perk each cost.

#### EX-C12-07 · Find the reversal

**Problem.** A product compares guided setup with self-setup by completion rate. Small accounts: guided 90 of 100, self 800 of 1,000. Large accounts: guided 600 of 1,000, self 40 of 100. Compute each rate, the overall rates, and explain the result.

**Context.** A manager says self-setup is better because its overall rate is higher.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** The trap detector (FW-C12-07): break down by the factor that decides the outcome.

**Solution.** Small accounts: guided 90%, self 80%. Large accounts: guided 60%, self 40%. Overall: guided (90 + 600) ÷ (100 + 1,000) = 690 ÷ 1,100 = 62.7%; self (800 + 40) ÷ (1,000 + 100) = 840 ÷ 1,100 = 76.4%. Guided is better in both groups and worse overall because guided was used mostly for large accounts (1,000 of 1,100, or 91%), which complete less often, while self-setup was used mostly for small ones (1,000 of 1,100). The overall comparison is between different mixes. The manager's conclusion is wrong; compare within the account size.

**Alternative solution.** Standardize both to the same mix (for example 50% small and 50% large): guided = 0.5 × 90% + 0.5 × 60% = 75%, self = 0.5 × 80% + 0.5 × 40% = 60%.

**Tradeoffs.** Guided setup was probably given to harder cases on purpose, so even the within-group comparison may be confounded; a randomized test is stronger (C14).

#### EX-C12-08 · Twenty slices

**Problem.** A team slices an experiment result by 20 user segments and finds one with p = 0.03. What is the chance of at least one such result if nothing is going on, and what do you do with it?

**Context.** The overall result was not significant.

**Data.** 20 segments, a 5% threshold.

**Constraints.** Four minutes.

**Expected approach.** Multiple comparisons (C12.7).

**Solution.** With a 5% threshold and 20 independent comparisons, the chance of at least one false positive is 1 − 0.95²⁰ = 64%. The expected number of false positives is 20 × 0.05 = 1, so finding one is what chance alone predicts. A simple correction is a threshold of 0.05 ÷ 20 = 0.0025, which p = 0.03 does not meet. Treat the segment as a hypothesis, state a reason it would respond differently, and test it in a new experiment aimed at that segment, with the hypothesis written in advance.

**Alternative solution.** If a plausible mechanism was specified before looking, the segment is a planned comparison and deserves a stronger look, though still a confirmation.

**Tradeoffs.** A strict correction misses real small effects; a retest costs time but is cheap against launching on a false segment.

#### EX-C12-09 · Did the email work?

**Problem.** A team emailed the 10% of users with the lowest activity last week (average 1.0 sessions). This week their average rose to 1.4, a 40% increase. The team concludes the email works. What is wrong, and how would you test it?

**Context.** No control group was kept.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** Regression to the mean (C12.7).

**Solution.** The group was selected for an extreme low value, partly by chance, so it would tend to move toward the average even with no email. To separate the effect, take the lowest-activity users, randomly split them in two, email half and not the other, and compare the changes. Suppose the control group also rose, from 1.0 to 1.3 (invented). Then the email's effect is about 1.4 − 1.3 = 0.1 sessions, not 0.4, and most of the 40% rise was regression.

**Alternative solution.** If a control group is not possible, select a comparison group by the same rule from an earlier week, and compare how that group moved without any email.

**Tradeoffs.** Withholding the email from half the group costs a little reach and buys a credible answer.

#### EX-C12-10 · Critique a dashboard

**Problem.** Critique these five dashboard items and say what you would ask for: (a) a bar chart of weekly signups whose vertical axis starts at 9,500; (b) a line chart with signups on the left axis and revenue on the right axis, showing lines that move together; (c) a cumulative chart of total users that keeps rising; (d) "average rating 4.6" with no count; (e) a table of conversion rates by country without denominators.

**Context.** You are reviewing a weekly business report.

**Data.** None.

**Constraints.** Five minutes.

**Expected approach.** The chart reading checklist (FW-C12-08).

**Solution.** (a) A truncated axis exaggerates small changes; ask for a zero baseline or label the range, and show the percentage change. (b) Two axes let the author choose scales so that the lines look related; ask for the correlation with the data, and for each series on its own chart or indexed to 100. (c) A cumulative total rises even when growth has stopped; ask for the weekly additions. (d) A rating without a count could rest on 12 reviews or 12,000; ask for the number and the distribution of ratings. (e) Conversion rates without denominators hide small samples; ask for the visits and conversions and an interval for the smallest countries.

**Alternative solution.** Pick the two most likely to mislead a decision this week and ask only those two questions, which keeps the meeting moving.

**Tradeoffs.** Skepticism toward a chart should not feel like an attack on the author; frame each point as a question about the data.

## 13. Practice protocol

**Timed drills (three a week for four weeks).**

- *Week 1: summaries and intervals.* Use IQ-C12-01, IQ-C12-02, EX-C12-01, EX-C12-02 and EX-C12-03. Say the answer aloud in plain language with one numeric example. Ten minutes each.
- *Week 2: tests, power and sample size.* Use IQ-C12-03, IQ-C12-04, EX-C12-04 and EX-C12-05. Do the arithmetic without a calculator using the rule of 16 and the interval rules, then check with a calculator.
- *Week 3: base rates and traps.* Use IQ-C12-05, IQ-C12-06, EX-C12-06, EX-C12-07, EX-C12-08 and EX-C12-09. Build the counts table every time. Name the trap and the check.
- *Week 4: decisions under uncertainty.* Use IQ-C12-07 and EX-C12-10. Run two timed answers to prompts you have not seen, with a partner who uses the interventions in section 4.

**Explain it to someone.** Each week, explain one idea (a p-value, an interval, a base rate) to a friend outside product, in three sentences with one example. If they cannot repeat it back, the explanation is not ready.

**Arithmetic drill.** Practice without a calculator: square roots of round numbers, the margin for n = 100, 400, 1,000 and 10,000, and the sample size for 10%, 5% and 20% baselines at 1-point and 0.5-point lifts. After a week, these should take ten seconds each.

**Feedback checklist (yes, partly, no).**

1. Did I fix what is compared, the unit and the window first?
2. Did I ask for the sample size and the interval?
3. Did I choose a summary that fits the shape of the data?
4. Did I read the result against a decision threshold, not only against significance?
5. Did I build a counts table for any flag or detector?
6. Did I name the trap that could be at work and the check?
7. Did I state my arithmetic assumptions and say the rules are approximate?
8. Did I explain it in plain words with one example?
9. Did I give a decision and what would change it?
10. Did I finish with the two-sentence close from section 4?

**Answer journal.** For each drill record the date, the prompt, the arithmetic, the trap you named, your score out of ten and the step you rushed. After eight drills, look for the step you skip most (usually the threshold or the base rate) and drill it alone for a week.

## 14. Implementation playbook

Apply the chapter on real work over the next three weeks. Each deliverable doubles as an interview story.

**Days 1 to 3.** Take the most recent experiment result or metric report your team used for a decision. Run the six-question check (FW-C12-01) on it. Write down what was missing (the interval, the sample size, the threshold, the mix) and what it would have changed.

**Week 1.** For the main metric you own, compute a rough interval with the shortcut in C12.9 and write the metric as "value, with a range." Share it with your manager. Ask whether the last change in the metric was larger than the range.

**Week 1.** Check one metric that is reported as an average for skew. Ask the data team for the median and the 90th percentile, and write what each says that the average does not.

**Week 2.** Size one upcoming test with the rule of 16 (FW-C12-05). Write the smallest effect that would change the decision, the duration in whole weeks and the options if it is too long. Compare your estimate with the data scientist's.

**Week 2.** Take one alert, flag or model in your product and build the counts table (FW-C12-06) from its hit rate, false-alarm rate and base rate. Write the share of flags that are right and what response fits it.

**Week 3.** Break a recent change in a rate down by the main segments (device, country, new versus returning) and compare the mix before and after (FW-C12-07). Write whether a mix shift explains any of the movement.

**Deliverables that become stories:** the six-question review (a time you found a gap in an analysis before a decision was made), the sample-size sketch (a time you set the minimum effect from the decision, not the traffic), and the counts table (a time you showed a team that most flags were false alarms and changed the response). Keep the numbers real, and keep what you did separate from what the team did.

## 15. Key takeaways and further reading

### Key takeaways

1. Treat every number as an estimate with a range: ask how many, how noisy, compared with what, and whether the size matters, before asking whether it is significant.
2. Choose the summary that fits the shape of the data and the decision: the median for a typical user, the mean for a total, a high percentile for the worst common experience.
3. Read the p-value, the interval and the effect size together, against a threshold set from the cost of the decision; "significant" and "worth doing" are different questions, and "not significant" with a wide interval means "unknown."
4. Apply the base rate with counts before trusting a flag, a test or a correlation, and match the response to the cost of each kind of error.
5. Name the trap and the check: a mix shift (Simpson's paradox), survivorship, regression to the mean, and many comparisons; and say when you would bring in a data scientist.

### Further reading

- Ron Kohavi, Diane Tang and Ya Xu, *Trustworthy Online Controlled Experiments* (2020). The standard practical text on running and reading experiments in products.
- Ronald L. Wasserstein and Nicole A. Lazar, "The ASA's Statement on p-Values: Context, Process, and Purpose," *The American Statistician* 70(2), 129 to 133 (2016). A short authoritative statement of what p-values do and do not say `[V: The American Statistician 70(2), 129 to 133, doi 10.1080/00031305.2016.1154108]`.
- Gerd Gigerenzer, *Calculated Risks* (2002), published in the United Kingdom as *Reckoning with Risk*. Natural frequencies and how to teach risk `[V: Calculated Risks: Simon & Schuster, 2002, ISBN 9780743205566 (US title); published in the UK as Reckoning with Risk, Penguin, 2002]`.
- Darrell Huff, *How to Lie with Statistics* (1954). An old and still useful guide to misleading charts and averages.
- Daniel Kahneman, *Thinking, Fast and Slow* (2011). The chapters on the law of small numbers and regression to the mean.
- Judea Pearl and Dana Mackenzie, *The Book of Why* (2018). Simpson's paradox and causal reasoning.
- P. J. Bickel, E. A. Hammel and J. W. O'Connell, "Sex Bias in Graduate Admissions: Data from Berkeley," *Science* 187(4175), 398 to 404, 7 February 1975 (doi 10.1126/science.187.4175.398). The primary source for CS-C12-02.
- Andrew Gelman and Eric Loken, "The Garden of Forking Paths" (2013, unpublished manuscript). The idea behind the mental model of unrecorded analysis choices `[V: unpublished manuscript, Columbia Department of Statistics, 14 November 2013]`.
