---
id: C04
title: Estimation Under Pressure
tier: 1
competencies: [problem-solving]
prerequisites: [C03]
defines_terms: [estimation, sanity-check, anchor, order-of-magnitude, sensitivity-analysis]
uses_terms: [mece, issue-tree, hypothesis, tradeoff, reversible-decision, first-principles-reasoning, pareto-principle, framework-theater, second-order-effect, unit-economics, funnel, retention, metric, base-rate]
frameworks: [FW-C04-01, FW-C04-02, FW-C04-03, FW-C04-04, FW-C04-05, FW-C04-06]
case_studies: [CS-C04-01 (Illustrative), CS-C04-02 (Verified)]
cross_refs_out: [C02, C03, C05, C07, C09, C12, C18, C20, C21, C22, C24, C25, C33, C34]
cross_refs_pending: []
status: draft
---

# C04 — Estimation Under Pressure

## 1. What interviewers test

The skill is producing a reasoned approximate number, quickly, from assumptions you state, and showing that the number is good enough for the decision it serves. C03 trained you to structure a problem. Estimation is structure applied to a quantity: you split an unknown into factors you can reason about, put a number on each, and check the result.

**Where it shows up.** `Inferred` from the round structures candidates commonly report: a dedicated estimation round in some early-career loops (reported as program-specific for Google's APM program), estimation prompts inside product and strategy answers where you size a market or an opportunity, and capacity or cost questions in technical rounds. On the job the same skill appears when you size an opportunity before you prioritize it, when you plan capacity or cost with engineers, when you forecast launch demand, and when you check a number on someone else's slide that looks too good.

**What is scored.** Google publicly lists general cognitive ability among its hiring attributes `Public` `[V: summaries citing Google's how-we-hire page; Google re:Work structured-interviewing guide]`, and an estimation prompt is a compact way to observe it `Inferred`. Amazon publishes principles that include Dive Deep and Are Right, A Lot `Public` `[V: Amazon's Leadership Principles page, amazon.jobs]`, and candidates commonly report follow-ups that test whether you checked a number `Inferred`. The scorer is not looking for the "right" answer, because there rarely is one. The scorer is looking for five behaviors:

1. You clarify what is being estimated and why.
2. You decompose it into factors you can estimate.
3. You state each assumption aloud, with a reason, in round numbers.
4. You check the result by a second route and say which assumption dominates it.
5. You connect the number to a decision and say how wrong it could be.

**The failure this prevents.** Five patterns lose candidates and new PMs: guessing a final number with no path to it, reciting memorized "facts" that may be wrong, false precision (an answer of 4,127,500), arithmetic that collapses under time pressure, and a correct estimate that is never connected to a decision.

## 2. The concept from first principles

### C04.1 What estimation is, and why it works

**Estimation** is producing a reasoned approximate number from stated assumptions and a decomposition of the quantity. [[estimation]] is sometimes called a Fermi problem, after the physicist Enrico Fermi, who was known for quick order-of-magnitude estimates from simple assumptions `[V: Fermi's Trinity estimate, CS-C04-02]`.

Two properties make it work.

**Decomposition turns one unknowable guess into several guessable ones.** You cannot guess the number of coffee shops in a city of two million people, but you can guess how many people buy coffee out on a typical day and how many customers one shop serves. Each guess is closer to something you have seen.

**Independent errors partly cancel.** If you guess one factor too high and another too low, the product is closer than either error alone. The multiplicative error of a product of independent factors is usually smaller than the worst case, which is why a decomposition into four rough factors is often within a factor of two or three of the truth `Inferred`.

The product of the steps is therefore only as good as the weakest factor, and the skill is knowing which factor that is. That is [[sensitivity-analysis]] (C04.5).

**When not to estimate.**

- When you can look it up or measure it in less time than you would spend estimating: a count in your own database is a ten-minute query, not a guess.
- When the decision does not depend on the number within a wide range. If the action is the same at one million and at ten million, the estimate adds nothing.
- When accuracy is required, as in financial reporting, safety margins or contract terms.
- When the quantity is dominated by a few large values, so that a product of averages misleads.

> **Counterexample.** A team estimates revenue from a customer base as customers times average revenue per customer. But 2% of customers produce 60% of revenue (invented). The average is a poor guide for the segment the product actually serves, and the product of two averages produces a number that describes no real customer. The right move is to segment first (large and small customers separately) and estimate each. Decomposition works when the factors are roughly uniform; when they are heavy-tailed, split the population before you multiply.

**Hidden risk.** A tidy decomposition can feel more reliable than it is. Four precise-looking factors can hide a bad assumption about one of them, and the confidence a clean calculation produces is not evidence.

### C04.2 The method: clarify, decompose, assume, compute, sanity-check

Five steps, in this order. FW-C04-01 records the protocol.

1. **Clarify.** Pin down what is being estimated (the definition, the unit, the place and the time), whether it is a stock (how many exist now) or a flow (how many per day), and why it is being asked. Ask two or three questions. If the interviewer says "you decide," state your definition aloud.
2. **Decompose.** Choose a structure from the library in C04.4 and write three or four factors that multiply or add to the answer. Each factor must be something you can reason about. Use the logic of [[mece]] (C03): factors should not overlap, and together they should cover the quantity.
3. **Assume.** Give each factor a number, a reason, and a provenance (a defined fact, a published figure, or your judgment). Use round numbers: 2, 3, 5, 10, 25, 50. Say each aloud.
4. **Compute.** Multiply step by step, tracking units and powers of ten. Round at each step to one or two significant figures. Narrate the arithmetic so the interviewer can follow and correct you.
5. **Sanity-check.** A **sanity check** is testing a result against an independent route or a known bound before trusting it. [[sanity-check]] means a second decomposition, a comparison with something you know, and a check of units. Then say which assumption dominates and what you would do with the number (C04.6).

**What to say aloud.** "I'll estimate the number of riders per day. I'll define a rider as someone who takes at least one trip. I'll split by population, share who ride, and trips per rider." "I'll assume about 70% of people are adults, because roughly a quarter of the population is under 15." "That gives about 280,000 riders. Let me cross-check from the driver side."

**Why the order matters.** Candidates who start with numbers cannot be scored on structure, and those who stop after computing have not shown that they would trust the result. The check and the so-what are the two steps most candidates skip, and they are the two that distinguish Strong answers from Baseline ones.

### C04.3 The anchor library, with provenance marked

An **anchor** is a well-known quantity used as the starting point for an estimate. [[anchor]] is what you reason from. You are not expected to know exact figures. You are expected to pick reasonable ones, state them as assumptions, and say how confident you are.

Mark where each anchor comes from. FW-C04-03 gives the ladder; the library below shows the three provenance classes:

- **D** (defined): exact by definition or arithmetic.
- **P** (published, approximate): a widely published figure, rounded; verify before relying on it for anything beyond an interview.
- **J** (judgment): a figure you reason to from experience; state it as an assumption and give a range.

| Group | Anchor | Value to use | Class | Note |
|---|---|---|---|---|
| Time | Seconds per day | 86,400 (about 10^5) | D | 10^5 is about 15% too high; fine for rough work |
| Time | Hours per year | 8,760 (about 9,000) | D | |
| Time | Seconds per year | about 3 × 10^7 (31.5 million) | D | |
| Time | Working hours per year | about 2,000 | J | 40 hours × 50 weeks, both assumed |
| People | World population | about 8.3 billion | P `[V: UN World Population Prospects 2024, mid-2026]` | The 8 billion mark was announced for late 2022 |
| People | India, China | India about 1.5 billion, China about 1.4 billion | P `[V: UN World Population Prospects 2024, India 1.48 billion for mid-2026]` | India passed China around 2023 (the UN announced April 2023; some estimates based on its 2024 edition place it in 2022) |
| People | United States | about 347 million (2025) | P `[V: UN World Population Prospects 2024: 347 million in 2025]` | |
| People | Indonesia, Brazil, Nigeria | about 285, 215 and 240 million | P `[V: UN World Population Prospects 2024 (INED reproduction): 286, 213 and 238 million in 2025]` | |
| People | Large city | 5 to 20 million | J | Define by metro area or city proper |
| People | People per household | about 2.5 (United States), about 4 to 5 (India) | P `[V: NFHS-5 for India, about 4.4; US Census Bureau, 2.59 in 2010 with one-person households at 29% in 2025]` | Varies by country and by year |
| People | Share of the world online | about three-quarters (74% in 2025) | P `[V: ITU statistics page, 2025: about 6 billion people, 74 per cent of the world's population, online]` | |
| People | Share of people under 15 | about a quarter worldwide; much lower in aging countries | P `[V: UN World Population Prospects 2024 as compiled by secondary sites: 25.8 percent aged 0 to 14 worldwide in 2024 (Gitnux) and 16.0 percent in China in 2024 (World Bank series built on UN data); the UN table itself was not opened]` | |
| Devices | Adults with a smartphone | 70% to 95% depending on market | J `[unverified: judgment range; no source]` | State as an assumption |
| Data | A phone photo | about 3 MB | J | Range 2 to 5 MB |
| Data | A minute of phone video | about 100 MB | J | Depends on resolution |
| Data | Streaming video | about 1 to 5 Mbps | J | Depends on quality tier |
| Data | A text message | 140 bytes | D | The original SMS limit |
| Money | A coffee, a city ride | $4, $10 to $20 | J | State the currency and market |
| Money | A monthly streaming subscription | $10 to $20 | J | |
| Money | A smartphone | $300 to $1,000 | J | |
| Behavior | Sleep, waking hours | 8 hours, 16 hours | J | |
| Behavior | Commute | 30 to 60 minutes a day | J | Varies widely by city |
| Business | Visit-to-purchase conversion in online retail | 1% to 4% | J | Wide range by category |
| Business | Free-to-paid conversion | 2% to 5% | J | Wide range by product |

**Using the library.** Prefer D to P to J. When you must use a judgment, anchor it to something you know: your own household, your own week. Say "I'm reasonably confident within a factor of two," and the interviewer hears calibration, not bluff.

> **Regional Lens: India.** Estimates about India start from a handful of base numbers, so say which you use and when it was measured. The United Nations projects about 1.48 billion people in mid-2026, about 38% of them urban `[V: UN World Population Prospects 2024, as reproduced by Worldometer and Statistics Times]`; the last completed census was in 2011, so every current figure is a projection. India's telecom regulator counted 1.114 billion internet subscriptions at the end of June 2026 `[V: TRAI performance-indicator report, as reported by DD India]`. Subscriptions are not people, because one person can hold several, so convert them before treating them as users `Inferred`. Choose a segment first (C09), and read the current figures yourself at the time you read this book `[as of 2026-10]`.

### C04.4 Decomposition patterns

Seven patterns cover most prompts. FW-C04-02 summarizes them, and the table below shows the shape.

| Pattern | Shape | Use when | Example prompt |
|---|---|---|---|
| Top-down (demand side) | Population × share who qualify × frequency × size | You know the people better than the supply | Coffee consumed in a city per day |
| Bottom-up (supply side) | Units of supply × capacity per unit × utilization | You know the providers | Customers served by all coffee shops |
| Balance | Estimate demand and supply, reconcile | A market with both sides | Ride-hailing trips |
| Capacity and throughput | Arrival rate × time per job ÷ servers; peak versus average | Systems with queues or limits | Couriers needed at the dinner peak |
| Benchmark (reference class) | Scale a known comparable by a ratio | A close analog exists | Orders per capita, scaled from a similar city |
| Unit economics | (Revenue − cost) per unit × units | The question is about profit or payback | Profit from a new subscription tier |
| Funnel | Starting population × conversion at each step | A path leads to the outcome | Paying users from a free product |

**Choose a pattern by what you know best,** and use a second pattern for the check. If you reason well about people, use top-down and check from supply. If the prompt is about a system, use capacity.

**Make the factors estimable.** A factor you cannot reason about ("market adoption of an unknown product") is a sign to split again. The test is whether you can name a number and a reason in ten seconds.

**Mind the stock-flow distinction.** "How many earbuds are in use" is a stock; "how many are sold per year" is a flow. A stock divided by a typical lifetime gives an annual flow, and that is one of the best cross-checks (CS-C04-01).

### C04.5 Rounding, precision and error ranges

**Rounding.** Round assumptions to one significant figure ("about 3 million") and the final answer to two at most. Never present more precision than your weakest factor supports. "About 280,000" is better than "283,400," because the second invites a challenge you cannot answer.

**Ranges, not points.** For each key factor give a low, base and high value, and report the result as "about 280,000, plausibly between 150,000 and 500,000." If the factors multiply, the extreme range multiplies too (low × low × low to high × high × high), but independent errors partly cancel, so the true range is usually narrower than the extreme range. Treat the multiplied extremes as an outer bound and your base case as the estimate.

**The geometric midpoint.** When a range spans a factor of several, the right center is the geometric mean, not the arithmetic one. For a range of 10 to 40 million, the geometric midpoint is 20 million (the square root of 10 × 40), while the arithmetic midpoint, 25 million, is pulled toward the high end.

**Order of magnitude.** An **order of magnitude** is a factor of ten. [[order-of-magnitude]] thinking asks whether an answer is about a thousand, a million or a billion. Most decisions only need you to be within a factor of two or three, and an interviewer will forgive an answer that is a factor of two off but punish one that is a factor of a hundred off with no way to notice `Inferred`.

**Sensitivity analysis.** **Sensitivity analysis** is checking how much the result changes when an assumption changes. [[sensitivity-analysis]] is simple: move each factor by a factor of two and see which move changes the answer most. That factor is where your remaining uncertainty lives, and it is the one to refine, ask about or test. It is the [[pareto-principle]] applied to estimation: one or two factors usually dominate.

### C04.6 Estimating for a decision: from the number to the so-what

A number matters only if it changes an action. The so-what bridge (FW-C04-05) has four steps:

1. **Name the decision threshold.** What number would change what we do? "We need at least $50 million of annual revenue to justify a dedicated team" is a threshold. "It's a big market" is not.
2. **Compare the range with the threshold.** If the whole range is above or below it, the decision is clear. If the range straddles it, the estimate cannot settle the question.
3. **Find the assumption that drives the straddle,** using sensitivity analysis, and propose the cheapest way to narrow it (a survey, a pilot, a data pull).
4. **State the action** and what would change it.

**Good enough is relative to the decision.** A factor-of-two estimate can be entirely sufficient. CS-C04-02 describes a famous case in which a quick estimate that was off by about a factor of two was enough for the decision it was made for.

**When not to use the bridge.** When no decision depends on the number, the bridge is unnecessary. In an interview, though, saying "if this were for a launch decision, I'd..." costs a sentence and signals judgment.

### C04.7 The mental-math toolkit

Estimation under pressure fails more often on arithmetic nerves than on reasoning. These tools make the arithmetic safe.

**Powers of ten.** Thousand is 10^3, million 10^6, billion 10^9, trillion 10^12. To multiply, add exponents: 3 million × 4 thousand = 12 × 10^9 = 12 billion. Write quantities as a number times a power of ten (4 × 10^5) when they get large.

**Percentages.** 10% is the number with the decimal moved one place; 1% moves it two places. 5% is half of 10%; 15% is 10% plus 5%; 25% is a quarter; 33% a third; 12.5% an eighth. To take 7% of 800: 1% is 8, so 7% is 56.

**Splitting products.** 17 × 24 = 17 × 20 + 17 × 4 = 340 + 68 = 408. Round one factor to a friendly number and correct afterward.

**Time conversions.** Per day to per year, multiply by 365, or by 400 and subtract about 10%. A day has about 10^5 seconds and a year about 3 × 10^7.

**The rule of 72.** Years to double is roughly 72 divided by the growth rate in percent. At 8% a year, doubling takes about 9 years.

**Compounding and percent changes.** A 10% rise followed by a 10% fall leaves you 1% lower, since 1.10 × 0.90 = 0.99. A 50% rise followed by a 50% fall leaves you 25% lower (1.5 × 0.5 = 0.75).

**Bits and bytes.** Eight bits make a byte. One megabit per second is 125 kilobytes per second. One gigabyte is 1,000 megabytes in everyday decimal use, and one petabyte is 1,000 terabytes.

**Units as a check.** Carry the units: people × orders per person per day = orders per day. If the units do not cancel to what you want, a factor is missing.

**Per-capita check.** Divide the result by the population: "that's about two orders per hundred people per day." Most wrong answers look wrong on a per-capita basis.

## 3. Frameworks

Six frameworks, set out below. FW-C04-01 is the core protocol, FW-C04-02 and FW-C04-03 supply structure and inputs, FW-C04-04 to FW-C04-06 are the checks. The frame card (FW-C03-01) and the skeleton (FW-C03-07) from C03 are reused for clarifying and pacing.

#### FW-C04-01 · The estimation protocol · Original

**Core framework.** Learn this one first.

- **Inputs:** a quantity to estimate, a purpose, and ten minutes.
- **Outputs:** a stated definition, a decomposition, assumptions with provenance, a computed result with a range, a cross-check and a so-what.
- **Assumptions:** the quantity can be decomposed into factors you can reason about; the interviewer will answer clarifying questions and may give corrections.
- **Tradeoffs:** speed versus rigor; each extra step costs time and buys confidence.
- **Failure modes:** starting with numbers before defining the quantity; unstated assumptions; computing without a cross-check; no link to a decision.
- **Worked example:** "estimate daily food-delivery orders in a city of five million" is defined as orders placed in a day, split by households, share ordering weekly and orders per household, cross-checked from restaurants, and bridged to a courier count at the dinner peak (Worked example 1).

Steps: **Clarify, Decompose, Assume, Compute, Sanity-check, So-what** (six, counting the bridge).

#### FW-C04-02 · The decomposition library · Original

- **Inputs:** a quantity and what you know best about it.
- **Outputs:** a decomposition with three or four estimable factors, and a second decomposition for the check.
- **Assumptions:** at least one pattern fits; the factors are roughly uniform within the population.
- **Tradeoffs:** a simpler pattern is faster and rougher; a richer one catches more but costs time.
- **Failure modes:** factors that overlap and double count; a factor you cannot estimate; mixing a stock with a flow; ignoring a heavy tail.
- **Worked example:** the market for an expense tool is estimated top-down from firms, share buying, and price, and checked bottom-up from the vendors' customer counts (Worked example 2).

The seven patterns are in the table in C04.4: top-down, bottom-up, balance, capacity, benchmark, unit economics, funnel.

#### FW-C04-03 · The anchor ladder · Original

- **Inputs:** a factor that needs a number.
- **Outputs:** a value, a stated provenance (D, P or J), a confidence level and a range.
- **Assumptions:** you can reason to a plausible value even without an exact figure.
- **Tradeoffs:** a published figure is more credible and may be wrong or out of date; a judgment is flexible and can be biased.
- **Failure modes:** presenting a judgment as a fact; quoting a "fact" you are not sure of; anchoring on one memorized figure; failing to give a range.
- **Worked example:** for the share of adults with a smartphone, the ladder gives a judgment (J) of 85%, stated as an assumption with a plausible range of 70% to 95% (Worked example 1 and the Baseline, Strong, Standout answers).

**The ladder, from most to least preferred:** (1) a defined fact (D); (2) a widely published figure you are fairly sure of (P), stated as approximate; (3) a figure derived from your own experience, anchored to something you can name (J); (4) a plain guess, which you say is a guess and show a range for. Always say which rung you are on.

#### FW-C04-04 · The two-route sanity check · Original

**Core framework.** Learn this one first.

- **Inputs:** a computed estimate and a second decomposition.
- **Outputs:** a verdict (the routes agree within a factor of about two, or they do not), and a note on which assumption explains any gap.
- **Assumptions:** the two routes are independent enough that agreement means something.
- **Tradeoffs:** a second route costs a minute and catches large errors; two routes that share an assumption can agree and both be wrong.
- **Failure modes:** a "second route" that reuses the same assumptions; stopping at agreement without a unit and per-capita check; ignoring a large gap.
- **Worked example:** top-down daily deliveries of about 86,000 are compared with a bottom-up figure of 80,000 from restaurant counts, and the two agree within 10% (Worked example 1).

Checks, in order: (1) units; (2) per-capita or per-unit plausibility; (3) a second independent route; (4) a bound (can it be larger than the population? smaller than one?); (5) a known comparison (is it close to something I know?). If routes disagree by more than about a factor of two, find which assumption differs and decide which you trust more.

#### FW-C04-05 · The so-what bridge · Original

- **Inputs:** an estimate with a range, and the decision it serves.
- **Outputs:** a decision threshold, a verdict (clear above, clear below, or straddling), the driving assumption, a cheap way to narrow it, and an action.
- **Assumptions:** the decision can be stated with a number that would change it.
- **Tradeoffs:** a precise threshold forces clarity and can be arbitrary; sensitivity work costs time.
- **Failure modes:** no threshold ("it's big"); treating a range that straddles the threshold as if it settled the question; proposing a study that costs more than the decision.
- **Worked example:** an AI feature's daily cost converts to a break-even conversion rate of about 3%, which the team compares with a plausible range for paid conversion (Worked example 4).

Steps: threshold, compare, drive, narrow, act (C04.6).

#### FW-C04-06 · The range method · Original

- **Inputs:** an estimate built from factors with uncertain values.
- **Outputs:** a base case, a low case and a high case, a geometric midpoint, and the factor that drives the spread.
- **Assumptions:** factors are roughly independent; low and high values are chosen as plausible, not extreme.
- **Tradeoffs:** ranges are more honest and take longer; multiplied extremes overstate the true spread.
- **Failure modes:** extreme values that make the range useless; arithmetic midpoints for wide ranges; reporting only the base case.
- **Worked example:** for riders in a city of ten million, the share of adults who ride on a given day is taken as 3% to 6%, giving 210,000 to 420,000 riders with a base of about 280,000 (Baseline, Strong, Standout answers in section 6).

Steps: (1) base value for each factor; (2) plausible low and high for the two or three most uncertain; (3) compute low, base, high; (4) take the geometric midpoint if the range is wide; (5) report "about X, plausibly Y to Z."

## 4. Answer architecture

Four question types use this chapter. Spend the first minutes on structure and keep time for the check and the so-what, which most candidates skip.

### Type A: the pure estimate ("How many X?")

*Example prompts:* "Estimate the number of coffee shops in a city of two million." "How many video calls happen at a company of 10,000 people each day?"

**Time budget for a ten-minute segment**

| Step | Minutes | What to produce |
|---|---|---|
| Clarify | 1.5 | Definition, scope, unit, stock or flow |
| Decompose | 1.5 | Three or four factors from the library |
| Assume | 2 | A number, a reason and a provenance for each |
| Compute | 2 | Stepwise arithmetic with units |
| Sanity-check | 1.5 | A second route, a per-capita check, the dominant assumption |
| So-what and close | 1.5 | The range, the threshold, what you would do next |

**What to clarify first.** The definition of the thing (what counts), the geography and the time frame, and whether the answer is a stock or a flow. **Where to signpost.** "I'll split this into four factors." "Now I'll cross-check from the other side." **How to close.** "About 1,250 shops, plausibly between 800 and 2,500. The share of people who buy coffee out dominates; if this were for a store-opening decision I'd check that first."

### Type B: market sizing and opportunity ("How big is the opportunity?")

*Example prompts:* "Estimate the annual revenue for a mobile wallet in a country of 50 million adults." "How big is the market for expense software for small businesses?"

Use top-down or funnel with the unit being customers, then multiply by price. Separate the **total** market (everyone who could use it) from the **serviceable** market (those you can reach with your product and channels) and from the **obtainable** share. Name the decision threshold early (what size justifies action), and finish with the so-what bridge. A strong answer says which of the three (total, serviceable, obtainable) the number is. The market-sizing vocabulary and its reality checks are developed in C18.

### Type C: capacity, cost and technical estimates ("How much storage, how many servers, what cost?")

*Example prompts:* "How much storage does a photo-sharing app need in a year?" "How much capacity does a live stream with five million concurrent viewers require?"

Use capacity and throughput. Pay particular attention to units (bits and bytes, megabytes and terabytes), to peak versus average, and to redundancy (copies, headroom). Convert to cost with a stated unit price, flagged as an assumption. Finish with what the number means for a decision: cost per user, break-even, or which design choice matters most. Technical background is in C21, system-design questions in C22, and AI cost estimates in C24 and C25.

### Type D: critique a number ("Our market is $10 billion. Do you believe it?")

Ask for the decomposition behind the number. Rebuild it from the bottom, factor by factor. Look for the usual errors: a total market presented as a serviceable one, a share-of-a-big-number argument ("just 1% of a trillion"), a price applied to customers who will not pay it, and factors that overlap. Say which factor drives the gap, and give your own range. Worked in IQ-C04-06.

**Pacing rules for all types.** Go broad before deep: choose the structure before computing. Keep arithmetic visible. If you make an arithmetic error, say so and fix it; interviewers value the recovery. If the interviewer corrects an assumption, update the whole chain aloud and say how much the answer changes. When the clock runs short, give the estimate and the range first, then the check, rather than finishing the computation and having no conclusion.

## 5. Worked examples

All four examples are `Illustrative`: the products are fictional, and every figure that is not a defined fact is an invented assumption, marked as such.

### Worked example 1 — Consumer: daily food-delivery orders in a city of five million (Illustrative)

**Clarify.** An order is one checkout, not one item. "Per day" is a flow. The city is five million people (invented). The purpose is courier planning, so the answer should also give the dinner peak.

**Decompose (top-down).** Orders per day = households × share that order delivery weekly × orders per active household per week ÷ 7.

**Assume, with provenance.**

| Factor | Value | Class | Range |
|---|---|---|---|
| People per household | 2.5 | P (typical for a high-income city) | 2.2 to 3 |
| Households | 5,000,000 ÷ 2.5 = 2,000,000 | computed | |
| Share ordering at least weekly | 20% | J (invented) | 10% to 30% |
| Orders per active household per week | 1.5 | J (invented) | 1.2 to 2 |

**Compute.** Active households: 2,000,000 × 20% = 400,000. Orders per week: 400,000 × 1.5 = 600,000. Per day: 600,000 ÷ 7 ≈ 86,000.

**Sanity-check, route 2 (bottom-up).** Restaurants on the platform: 10,000 (J, invented; range 5,000 to 15,000) × 8 orders per restaurant per day (J, invented) = 80,000. The two routes agree within about 7%. Per-capita: 86,000 ÷ 5,000,000 = 1.7 orders per 100 people per day, which is plausible for a dense city with strong delivery use.

**Sensitivity.** The share of households ordering weekly dominates: at 10% the answer halves to about 43,000, and at 30% it rises to about 129,000. The orders-per-household factor moves it far less (1.2 to 2 changes it by about -20% to +33%). So the weekly-ordering share is the assumption to confirm.

**So-what (courier planning).** Assume the dinner peak hour carries 12% of daily orders (J, invented): 86,000 × 12% ≈ 10,300 orders in the peak hour. If one courier completes 2 orders an hour (J, invented), the peak needs about 5,100 couriers online. If the weekly-ordering share is really 10%, the need is about 2,600. The number to confirm before committing capacity is therefore the share, and a short check of order logs from a comparable city would do it.

**Close.** "About 86,000 orders a day, plausibly 45,000 to 130,000; the weekly-ordering share drives it; for planning I'd staff for roughly 5,000 couriers at the peak and confirm the share first."

**What this shows.** Provenance on each factor, two routes that agree, the dominant assumption identified, and a number converted into a staffing decision.

### Worked example 2 — B2B: the market for expense software for small businesses (Illustrative)

**Clarify.** "Market" here means annual spend on expense-management software by US employer businesses with 10 to 99 employees (a definition I state). The purpose is a go or no-go on a new entrant, so I will separate the total, the spend today, and what a new entrant could obtain.

**Decompose (funnel).** Firms × share that would use the product × price, then narrowed by current adoption and share capture.

**Assume.**

| Factor | Value | Class | Range |
|---|---|---|---|
| US employer businesses | about 6 million (5.6 to 5.9 million depending on the Census series) | P `[V: Census Bureau Business Dynamics Statistics and Annual Business Survey, 2022 to 2023]` | |
| Share with 10 to 99 employees | 20% | J (invented) | 15% to 25% |
| Firms in scope | 6,000,000 × 20% = 1,200,000 | computed | |
| Share that buy dedicated expense software today | 15% | J (invented) | 8% to 25% |
| Price per firm per year | $1,500 | J (invented) | $900 to $2,400 |

**Compute.** Total, if every firm in scope bought: 1,200,000 × $1,500 = $1.8 billion. Spend today: 1,200,000 × 15% = 180,000 buyers × $1,500 = $270 million a year. A new entrant that wins 3% of that spend (J, invented) obtains about $8 million.

**Sanity-check, route 2 (supply side).** Suppose five leading vendors each serve about 30,000 firms in this segment (J, invented). That is 150,000 firms × $1,500 = $225 million, and a long tail of smaller vendors accounts for the rest, which is consistent with $270 million. The check is independent of the adoption-share assumption, because it comes from how many customers vendors say they have.

**Sensitivity.** Adoption share dominates. At 8% the spend is $144 million, and at 25% it is $450 million. Price matters less (about -40% to +60%).

**So-what.** Suppose a new entrant needs about $10 million of annual revenue to justify a dedicated team (invented threshold). The obtainable $8 million is below it, and the plausible range for the obtainable share (2% to 5% of $144 million to $450 million, that is $3 million to $22 million) straddles it. The estimate does not settle the question. The assumption that drives the straddle is the share a new entrant can win, so the cheapest narrowing step is a pilot with design customers rather than more desk research.

**What this shows.** Total versus spend-today versus obtainable are three different numbers, and naming them prevents the most common market-sizing error. The so-what ended in a pilot, not a verdict.

### Worked example 3 — Infrastructure: a year of storage for a photo-sharing app (Illustrative)

**Clarify.** Storage added during one year, in petabytes, for an app with 50 million monthly active users (invented). Include copies for reliability, since the cost depends on what is stored, not only what users upload.

**Decompose (capacity).** Photos per year × size per photo × overhead × copies.

**Assume.**

| Factor | Value | Class |
|---|---|---|
| Share of users who upload in a typical week | 30% | J (invented) |
| Photos per uploader per week | 5 | J (invented) |
| Size per stored photo | 3 MB | J (typical phone photo, range 2 to 5 MB) |
| Overhead for thumbnails and metadata | 10% | J (invented) |
| Copies kept | 3 | J (a common practice for reliability; stated as an assumption) |

**Compute.** Weekly uploaders: 50,000,000 × 30% = 15,000,000. Photos per week: 15,000,000 × 5 = 75,000,000. Per year: 75,000,000 × 52 = 3.9 billion photos. Raw size: 3.9 billion × 3 MB = 11.7 billion MB = 11.7 petabytes. With 10% overhead: about 12.9 petabytes. With 3 copies: about 38.6 petabytes added in the year.

**Sanity-check.** Per user: 38.6 petabytes ÷ 50 million users = about 770 megabytes per user per year, including copies. Per user without copies and overhead it is about 234 megabytes, which is 78 photos a year at 3 MB. A product where a typical user posts about 1.5 photos a week gets 78 photos a year, which matches the assumptions. Units: 1 petabyte = 10^9 megabytes, so 11.7 billion MB is 11.7 PB.

**So-what (cost).** Storage accumulates through the year, so the average stored volume in year one is about half of the year-end figure: 38.6 ÷ 2 ≈ 19.3 petabytes, or about 19,300 terabytes. At an assumed $20 per terabyte-month `[as of 2026-10; invented here]`, cost is about 19,300 × $20 × 12 = $4.6 million in year one. A 10% reduction in stored size by better compression saves about $0.46 million a year, which tells the team how much effort compression is worth.

**What this shows.** Unit discipline (MB to PB), copies and overhead as explicit factors, average versus year-end volume, and a cost that connects to a design choice.

### Worked example 4 — AI: the daily cost of an assistant feature (Illustrative)

**Clarify.** Cost per day and per user of a text assistant that answers questions in the app, for 2 million daily active users (invented), using a hosted language model priced per token. The purpose is to decide whether the feature can be offered free.

**Decompose (unit economics).** Queries per day × tokens per query × price per token.

**Assume** (all invented, and model prices change quickly `[as of 2026-10]`).

| Factor | Value |
|---|---|
| Queries per daily active user per day | 3 |
| Input tokens per query (question plus context) | 1,500 |
| Output tokens per query | 500 |
| Price per million input tokens | $1 |
| Price per million output tokens | $4 |

**Compute.** Input cost per query: 1,500 × $1 ÷ 1,000,000 = $0.0015. Output cost: 500 × $4 ÷ 1,000,000 = $0.0020. Total per query: $0.0035. Queries per day: 2,000,000 × 3 = 6,000,000. Cost per day: 6,000,000 × $0.0035 = $21,000. Per year: about $7.7 million. Per daily active user per month: 3 × 30 × $0.0035 = $0.315.

**Sanity-check.** Units: tokens times dollars per token gives dollars. Reasonableness: about 31 cents per user per month is a small fraction of a typical subscription price and a large one for a free product, so the check is consistent with why teams worry about this cost.

**Sensitivity.** Input tokens are three-quarters of the tokens and about 43% of the cost; output is about 57% of the cost because it is priced higher. Doubling queries per user doubles the cost. Reducing the context sent with each query (for example, by sending only relevant passages) would cut the input cost directly.

**So-what.** If the feature is supported by a $10-a-month subscription, then to cover $0.315 per user per month across all daily users, about 3.15% of them (0.315 ÷ 10) would need to pay, before any other cost. That threshold can be compared with a plausible paid-conversion range (2% to 5% for many products, J). The estimate straddles the break-even, so the driver to test is the conversion rate, and the levers to pull in parallel are less context per query, a smaller model for simple questions, and a usage cap on the free tier (AI costs are developed in C24 and C25).

**What this shows.** Unit economics for a modern feature, with the unit price flagged as time-sensitive, a break-even threshold, and levers tied to the dominant factors.

## 6. Baseline, Strong, Standout

**Prompt:** "Estimate how many people use ride-hailing apps in a city of 10 million on a typical day." (All inputs are assumptions.)

### Baseline answer

"I think about a million people. It's a big city, and a lot of people use apps like that these days. Maybe a bit less, maybe a bit more."

*What is wrong:* no definition, no path to the number, no check. A guess with a confident tone.

### Strong answer

"I'll define a rider as someone who takes at least one trip that day. I'll split by population, share who ride, and trips per rider.

"Ten million people; about 70% are adults, so 7 million. I'll assume about 4% of adults take a ride on a typical day, so about 280,000 riders. At about 1.4 trips per rider that is about 390,000 trips.

"Let me check from the supply side. Assume about 25,000 drivers are active on a typical day, each doing about 15 trips, which is 375,000 trips. That is within 5% of my 390,000, so I'm fairly comfortable. I'd say about 280,000 riders a day."

### Standout answer

Everything in the Strong answer, plus:

"I'll first confirm the definition, because 'use' could mean riders or trips, and 'city' could mean the city proper or the metro area. I'll take the city proper, and give riders as the answer with trips as a by-product.

"I'd rather give a range. The share of adults is the shaky factor: I'd put it between 3% and 6%, so 210,000 to 420,000 riders, and the geometric midpoint is about 300,000. The supply check gives 20,000 to 30,000 drivers times 12 to 18 trips, which is 240,000 to 540,000 trips, overlapping my demand range, so I trust it.

"The share dominates, because the other factors are fairly stable. If I could ask for one fact, it would be trips per day in a comparable city, to calibrate that share.

"If this is for a launch decision, I'd turn it into value: about 390,000 trips a day at an assumed $8 average fare is about $3.1 million in gross value a day, and at a 20% take rate about $0.63 million a day, or about $230 million a year. Whether that clears the bar depends on the cost of entering the city, and I'd want the competitor's share too, because I've estimated the whole market, not what we would obtain."

### What moves an answer up a band

| From Baseline to Strong | From Strong to Standout |
|---|---|
| Defines the quantity and decomposes | Resolves definitions (riders versus trips, city versus metro) |
| States assumptions in round numbers | Gives ranges and a geometric midpoint |
| Cross-checks by a second route | Identifies the dominant assumption and what fact would calibrate it |
| Gives one number | Converts the number into a decision and separates total from obtainable |

## 7. Company lens

All claims describe what companies say publicly or what candidates commonly report, not insider knowledge. Interview formats change `[as of 2026-10]`.

> **Company lens: Google [as of 2026-10].** Candidates report a dedicated estimation round in Google's APM loop `Inferred` `[unverified: candidate-reported]`, and Google publicly lists general cognitive ability among its hiring attributes `Public` `[V: summaries citing Google's how-we-hire page]`. Practical consequence: make structure and checking visible, and treat the estimation prompt as a test of how you reason rather than of what you know.

> **Company lens: Amazon [as of 2026-10].** Amazon publishes principles that include Dive Deep and Are Right, A Lot `Public` `[V: Amazon's Leadership Principles page, amazon.jobs]`. Candidates commonly report follow-ups that ask where a number came from and how you would verify it `Inferred`. Practical consequence: attach a provenance (defined, published or judgment) to each factor and say how you would confirm the one that drives the answer.

> **Company lens: Meta [as of 2026-10].** Candidates commonly report sizing and opportunity estimation embedded in product and execution questions rather than as a separate round `Inferred` `[unverified: candidate-reported]`. Practical consequence: after a feature idea, estimate its reach and effect in a sentence or two, and say which assumption you would test first.

> **Company lens: Microsoft [as of 2026-10].** Microsoft publicly emphasizes a growth-mindset culture `Public` `[V: Microsoft careers culture page]`. Reports suggest enterprise sizing (seats, price, adoption) and capacity-style questions appear in some loops `Inferred` `[unverified: candidate-reported]`. Practical consequence: separate buyers from users, and total from serviceable market, in B2B estimates.

> **Company lens: Apple [as of 2026-10].** Third-party prep guides report team-specific loops, and product or technical deep dives may include device-related estimates such as storage, battery or supply `Inferred` `[unverified: candidate-reported]`. Practical consequence: be ready to convert units precisely (bits and bytes, watt-hours, units shipped) and to estimate a stock of devices from an annual flow and a typical lifetime (IQ-C04-03).

> **Company lens: Netflix [as of 2026-10].** Netflix stopped reporting quarterly subscriber counts from 2025 (it announces milestones instead) and runs a content catalog with large fixed content costs `Public` `[V: Netflix Q1 2024 shareholder letter, as reported by CNBC and CBS News]`. Candidates commonly report estimation prompts that relate viewing, content cost and subscribers `Inferred`. Practical consequence: tie an estimate to a decision such as cost per hour watched, decompose by subscribers × hours × share of hours, and sanity-check against what a household plausibly watches in a week.

> **Company lens: Stripe [as of 2026-10].** Stripe's revenue is tied to a share of the payment volume it processes `Public` `[V: Stripe pricing page: percentage plus fixed fee per transaction, custom pricing for large volume]`. Candidates report sizing prompts for payments and developer products `Inferred`. Practical consequence: decompose payment volume as businesses × transactions per business × average value, apply a fee rate to reach revenue, and sanity-check the average value against the kind of business.

## 8. Common mistakes

| # | Mistake | How to detect it | Fix |
|---|---|---|---|
| 1 | Starting with numbers | Your first sentence has a figure and no definition | Define the quantity, unit and scope first |
| 2 | An unstated assumption | The interviewer asks "where did that come from?" | Say each assumption aloud with a reason |
| 3 | No cross-check | You finish the arithmetic and stop | Run a second route and a per-capita check |
| 4 | False precision | Your answer has four or more significant figures | Round to one or two, and give a range |
| 5 | Unit slips | You cannot say whether it is MB or Mb, per day or per year | Carry units through every step |
| 6 | Mixing stock and flow | You divide units sold per year by people who own them | Convert with a lifetime: stock = annual flow × lifetime |
| 7 | Double counting | A factor covers people already in another factor | Check factors for overlap (C03.2) |
| 8 | Ignoring a heavy tail | You multiply averages for a skewed population | Split into segments before multiplying |
| 9 | A factor you cannot estimate | You stall on one factor | Split it again, or use a benchmark |
| 10 | The answer with no decision | You end on the number | Add the threshold and the action |

### C04.9 Failure modes: false precision, unstated assumptions, no cross-check

**False precision.** A number reported with more digits than the weakest factor supports. It invites a challenge you cannot meet and signals that you do not know what you do not know. *Detect:* could you defend the third digit? *Fix:* one or two significant figures and a range.

**Unstated assumptions.** The reasoning is in your head, so the interviewer cannot score it or correct it. If a hidden assumption is wrong, the whole answer is wrong and nobody knows why. *Detect:* the interviewer asks where a figure came from and the answer is "I just thought so." *Fix:* every factor gets a value, a reason and a provenance, said aloud.

**No cross-check.** An estimate with one route is a single point of failure. *Detect:* you cannot name a second route or a known comparison. *Fix:* the two-route sanity check (FW-C04-04), a per-capita check and a bounds check.

Three more that are specific to estimation: **precision theater with the wrong units** (a carefully computed number in the wrong unit), **an overcomplicated decomposition** (eight factors where three would do, so you run out of time), and **forgetting the question** (a thorough calculation of something adjacent to what was asked).

## 9. Mental models applied

Four models, each tied to a decision in this chapter. [[pareto-principle]] from C03 and [[first-principles-reasoning]] from C02 also apply: sensitivity analysis is Pareto applied to assumptions, and a decomposition is first-principles reasoning applied to a quantity.

**Order-of-magnitude thinking** (`MM-order-of-magnitude`) asks whether an answer is about a thousand, a million or a billion before it asks about the digits. Application: when two routes differ by a factor of a hundred, one has a unit error or a missing factor, and you should find it before refining anything. Most decisions are insensitive to a factor of two and very sensitive to a factor of a hundred.

**Reference-class thinking** (`MM-reference-class`), sometimes called the outside view, asks how similar cases turned out instead of reasoning only from the details of this one. It is associated with Daniel Kahneman and Amos Tversky's work on forecasting `[V: Kahneman and Tversky (1979) on the outside view and reference class forecasting, as summarized in reference-class sources]`. Application: an estimate of adoption for a new feature should be compared with what similar features achieved. The related idea of a [[base-rate]] (C12) is the same discipline applied to probabilities. A bottom-up estimate that is ten times larger than any comparable product's actual figure should make you doubt your assumptions.

**Error cancellation** (`MM-error-cancellation`) is the observation that independent errors in factors partly offset one another, so a product of rough factors is usually closer to the truth than its worst-case range suggests. Application: give an outer range from the multiplied extremes and a typical range narrower than it, and avoid defending a single high or low value as if it carried the whole error. The caution is that errors that come from a common cause (a shared assumption about the market) do not cancel; they add.

**Sensitivity thinking** (`MM-sensitivity`) says to ask which input matters most, not just what the answer is. Application: in Worked example 2 the adoption share dominated, which told the team where the next dollar of research should go. A sensitivity result that points at an assumption you cannot improve is a reason to change the design of the decision.

## Engineering, design and data-science perspectives

- **Engineering.** Capacity estimates need peak, not average, and headroom for failures. Ask engineers for the peak-to-average ratio and the redundancy policy, and treat their numbers as inputs you convert to cost. Units discipline (bits versus bytes, binary versus decimal) is where product estimates most often go wrong.
- **Design.** Estimates of adoption and effort improve when designers describe the behavior you are assuming ("users will return weekly") in concrete terms; a design review is a cheap way to challenge a behavioral factor.
- **Data science.** A data pull replaces a guess where it can. Ask what the data contains and what it leaves out (selection effects in who rates or who opts in), and use an analyst's estimate as the second route when one is available.

## Checklist: before you give a number

1. Is the quantity defined, with a unit, a place and a time, and is it a stock or a flow?
2. Are there three or four factors, each one I can reason about?
3. Is each assumption stated with a reason and a provenance (D, P or J)?
4. Did I use round numbers and carry units?
5. Did I check by a second route and by a per-capita or bounds test?
6. Do I know which assumption dominates?
7. Did I give a range and round to one or two figures?
8. Did I say what decision the number serves and what would change it?

## 10. Case studies

#### CS-C04-01 · From a billion-dollar market to a go or no-go · Illustrative · Beginner

*Fictional composite. Every number is invented.*

**Situation.** A product manager at a grocery app proposes a dedicated team for a meal-planning feature, justified by "a $1 billion market": 100 million households times $10.

**Constraints.** Two days to review; no new research budget; the company's rule is that a dedicated team needs a credible path to $5 million of annual recurring revenue within three years.

**Data.** The country has 50 million households (not 100 million, a figure the proposal had copied from a neighboring market). Survey data from the company's own users show that about 30% of households plan meals weekly.

**Problem definition.** The proposal sizes the total market at full price. The decision needs the revenue the company could obtain, compared with $5 million.

**Analysis.** Rebuild as a funnel. Households: 50 million. Plan meals weekly: 30% gives 15 million. Would use an app for it: 20% (J, range 10% to 30%) gives 3 million. Would pay: 10% (J, range 5% to 15%) gives 300,000 payers. Price: $6 a month, or $72 a year (J).

Serviceable revenue: 300,000 × $72 = $21.6 million a year. The company's obtainable share, with its existing user base, is taken as 10% of that: about $2.2 million. At the extremes of the ranges the serviceable revenue is 15,000,000 × 0.10 × 0.05 = 75,000 payers × $72 = $5.4 million (low) to 15,000,000 × 0.30 × 0.15 = 675,000 payers × $72 = $48.6 million (high). At a 10% obtainable share, that is $0.5 million to $4.9 million, below the $5 million threshold even at the high end. A second route: if a leading app in the category has about 500,000 payers (J) and the company could reach 10% of that scale, that is 50,000 payers × $72 = $3.6 million, which is also below the threshold.

**Options.**

| Option | Optimizes | Costs |
|---|---|---|
| A. Dedicated team on the $1 billion claim | Ambition | Likely a team with no path to its own threshold |
| B. Ship a small meal-planning feature inside the existing app and measure | Learning at low cost | Slower; no dedicated owner |
| C. Drop it | Focus | Misses a possible retention benefit |

**Tradeoffs.** B gives up speed and ownership for evidence, and it is reversible. A commits headcount on a figure that does not survive a rebuild.

**Decision.** Choose B, with a pilot to 5% of users and the metric of weekly plan creation and 30-day retention, and revisit a dedicated team if paid conversion in the pilot exceeds the high-case assumption of 15% of interested households.

**Outcome.** In this fictional scenario the pilot showed 4% paid conversion among interested households (invented) and an uplift in retention for planners. The team kept the feature inside the app and did not request a dedicated team.

**Alternative outcomes.** If the pilot had shown conversion near 15%, the high case would have been confirmed and a dedicated team defensible. If the original proposal had gone ahead, the error in the household count (100 million instead of 50 million) would have been caught later and at greater cost. The case shows the habit: question the total, rebuild bottom-up, compare with the threshold.

#### CS-C04-02 · Fermi at the Trinity test, 1945: an estimate good enough for its purpose · Verified · Advanced

*Sources (types): a peer-reviewed technical note (J. I. Katz, "Fermi at Trinity," Nuclear Technology 207, supplement 1, S326 to S334, 2021, doi 10.1080/00295450.2021.1927627), read through its open-access text and its arXiv version; the Los Alamos reassessment of the Trinity yield (H. D. Selby and colleagues, "A New Yield Assessment for the Trinity Nuclear Test, 75 Years Later," Nuclear Technology, 2021), read through its arXiv text; and eyewitness oral histories published by the Harvard Gazette. The US Department of Energy's history page was not read, and no claim here rests on it. The framing of the lessons is the author's. Re-read in October 2026.*

**Situation.** On July 16, 1945, the United States conducted the first test of a nuclear device in New Mexico. Enrico Fermi, a physicist who was present, estimated the energy released using a simple observation: he dropped small pieces of paper before the blast wave arrived and observed how far it carried them.

**Constraints.** He had no instrument beyond the paper. The estimate had to be made on the spot; Katz notes that it would not have been easy to measure the timing of the blast without photographic or electronic equipment, so on his reconstruction Fermi estimated the width of the blast wave from theory, though Katz adds that Fermi might instead have judged it by eye and that Fermi did not say which `[V: Katz, 2021]`. Formal measurements would take longer.

**Data.** Fermi estimated the yield at about 10 kilotons of TNT equivalent, from how far scraps of paper dropped before the blast wave were carried by it (about 2.5 metres, at about 10 miles from the explosion) `[V: Katz, 2021]`. Katz compares this with the radiochemically derived value of 25 ± 2 kilotons, so the estimate was about 40% of the modern value; an earlier preprint of the note used about 21 kilotons, the value previously accepted by the Department of Energy (21 ± 2 kilotons), and the 2021 Los Alamos reassessment gives 24.8 ± 2 kilotons `[V: Katz, 2021; Selby and colleagues, 2021]`. Katz observes that the radiochemical value includes thermal and nuclear radiation that do not contribute to the blast wave, so the blast-based estimate is better read as a lower bound, and concludes that it was sufficient to declare Trinity a success `[V: Katz, 2021]`. Katz also notes that popular accounts describe the experiment but that no account of how Fermi related the displacement to the yield appears to exist, so his note reconstructs it.

**Problem definition.** The immediate question was whether the test had worked, and roughly how large the release was. That needed an order of magnitude, not three significant figures.

**Analysis.** Four features made the estimate useful. First, he used what was at hand and in time: small scraps of paper dropped before the blast wave arrived, so that the wave itself did the measuring. Second, he chose a simple observable that is physically tied to the quantity of interest (the displacement of paper in the wind of the blast). Third, the error was a factor of about two to two and a half (depending on which radiochemical value is used), which for the decision was small, and the direction of the error was understood, because the blast-wave energy is less than the total. Fourth, Katz reports that there appears to be no account of exactly how Fermi turned the displacement into a yield, so the story is a reminder that a trusted estimator's judgment, tested later against careful measurement, can be valuable even when the steps are not fully written down. That is a caution as well as a lesson: in an interview you must write the steps down.

**Options.** (1) Wait for the formal measurements and radiochemical analysis. (2) Make an immediate low-cost estimate. (3) Do both.

**Tradeoffs.** Speed against precision, in a setting where an early order of magnitude had value and a later precise figure would follow.

**Decision.** He made the immediate estimate, and the later analyses followed.

**Outcome.** The documented result is an estimate within a factor of about two to two and a half of the radiochemical value, made on the spot `[V: Katz, 2021]`. Katz's note describes the estimate as sufficient to declare the test a success.

**Alternative outcomes.** *Inference.* Had the estimate been off by a factor of ten, it would have misled the decision. Had the paper measurement been left to improvisation, it would have been unreliable. The estimate was useful in part because it used what was at hand and the error's direction was understood.

**Lesson for an interview answer.** Precision should match the decision. Prepare your check before you need it, know which way your estimate errs, and write down the steps, because the interviewer cannot score judgment they cannot see.

## 11. Interview questions and model answers

Eleven questions, with at least three per difficulty. Model answers are `Illustrative`; every input is an assumption unless marked defined or published. Each is written against the five behaviors in section 1.

#### IQ-C04-01 · Beginner · estimation · PR

**Prompt.** Estimate the number of coffee shops in a city of two million people.

**Rubric.**
- **Baseline:** Names a number ("maybe a thousand") with no path to it.
- **Strong:** Defines a coffee shop, decomposes by demand and shop throughput, cross-checks, and gives a rounded answer.
- **Standout:** States a range, identifies the dominant assumption, cross-checks per capita, and says what would change the estimate.

**Model answer.** I'll define a coffee shop as a place whose main business is selling coffee for takeaway or sit-down, excluding restaurants and hotel lounges. The answer is a stock: shops that exist today.

I'll go from demand. Two million people. Suppose about 25% buy coffee out on a typical weekday, which is 500,000 purchases, assuming one purchase each. That is a judgment, anchored to my own week: I buy out about a third of days, and many people buy less. A shop serves about 400 customers a day: over a 12-hour day that is about one customer every 1.8 minutes, which feels right for a busy small shop and generous for a quiet one.

Shops: 500,000 ÷ 400 = 1,250.

Check. Per capita that is one shop per 1,600 people. In a coffee-heavy city that is plausible, and in a city with little coffee culture I would expect fewer. Second route, supply side: I'd guess a typical neighborhood of 10,000 people has five to eight coffee shops, which is one per 1,250 to 2,000 people, consistent with 1,250 shops for two million people.

Range. The share of people who buy out dominates: at 15% I get about 750 shops, and at 35% about 1,750. Widening for shop throughput (300 to 500 customers a day) gives roughly 600 to 2,300. I'd say about 1,250, plausibly 800 to 2,500. If this were for a store-opening decision, I'd check how many shops already serve the target neighborhood and what share of people there buy coffee out.

**Follow-ups.**

- **Q.** How would you cross-check the demand-side estimate from the supply side? **A.** "I would sample the supply directly. Take five neighbourhoods of different density, count the shops on a map in one of them, and scale by population. Suppose a dense district of 50,000 people has 30 shops, a typical one of 100,000 has 40, and a sparse one of 40,000 has 8. That is roughly 1 shop per 1,700, 1 per 2,500 and 1 per 5,000 people. Weighting toward typical districts gives about 1 per 2,500, or 800 shops for two million people. My demand-side figure was 1,250, so the two routes bracket the answer: I would say roughly 800 to 1,300 and explain that the gap comes from how many customers a shop really serves."
- **Q.** What if the interviewer says chains are 40% of shops and serve more customers than independents? **A.** "I would use two throughputs. If chain outlets serve about 600 customers a day and independents about 250, the weighted average is 0.4 × 600 + 0.6 × 250 = 390 customers per shop. Then 500,000 purchases ÷ 390 is about 1,280 shops, close to my original 1,250. So the count is robust to the mix, and what the mix changes is the split: about 510 chain outlets and 770 independents."

#### IQ-C04-02 · Beginner · estimation · PR

**Prompt.** How many video calls happen each day on a work-chat app at a company of 10,000 employees?

**Rubric.**
- **Baseline:** "Everyone has a few calls, so maybe 30,000," without separating calls from participants.
- **Strong:** Separates calls from participations, decomposes, and checks plausibility.
- **Standout:** Resolves the definition of a call, gives a range, notes that the share using video is the dominant assumption, and ties the result to a capacity or cost question.

**Model answer.** First the definition. A call is one meeting with several participants, so I need to separate participations (one person joining one call) from calls. I'll estimate participations and then divide by the average call size. The app is the company's work-chat app, and I'll count only calls on it, not calls on other tools.

Ten thousand employees. Suppose 60% join at least one video call on a typical workday (the rest are in person, on other tools, or not at a desk): 6,000 people. Each of them joins about 2.5 calls: 15,000 participations. Average call size is about four people. So calls are 15,000 ÷ 4 = 3,750 per day.

Check. Per employee that is 1.5 call participations a day for the whole company, which fits a knowledge-work company; it would be high for a manufacturing one. And 3,750 calls over about eight working hours is about 470 an hour, and the number running at the same moment is perhaps 100 to 300 at the busiest time, which is a plausible load for a company of this size.

Range. The share who use video dominates, at 40% to 80%, which gives about 2,500 to 5,000 calls. Calls per user is next. I'd say about 3,750 calls a day, plausibly 2,500 to 5,000. If the question is about infrastructure, I'd next estimate the peak concurrent calls, because capacity is set by the peak, not the average.

**Follow-ups.**

- **Q.** The finance team asks how many simultaneous calls the app must support. How do you use your estimate? **A.** "I would move from a daily total to a peak. Suppose 60% of the 3,750 daily calls fall in a four-hour window, 2,250 calls, or about 560 starting each hour, and the average call lasts 30 minutes. Concurrent calls are starts per hour times duration in hours: about 280 on average in the peak window. Meetings cluster on the hour, so the true peak is perhaps twice that, about 560. I would plan for roughly 600 concurrent calls and add headroom of about 20%, so around 720, and say that the clustering factor is my weakest assumption and would be replaced by real data from the vendor's admin reports."
- **Q.** What if only 30% of people use video on a typical day, not 60%? **A.** "Everything scales with that factor: 3,000 people, 7,500 participations and about 1,875 calls a day, half the original. That is why I called video share the dominant assumption. I would give the range as roughly 1,900 to 3,750 calls a day and ask what evidence is cheap to get: a week of the company's own usage data would settle it. Meanwhile I would size capacity for the high end, because under-provisioning costs more than over-provisioning for a few weeks."

#### IQ-C04-03 · Intermediate · estimation · PR · Apple

**Prompt.** Estimate how many wireless earbuds are in active use in one large city.

**Rubric.**
- **Baseline:** "Maybe a couple of million," with no structure.
- **Strong:** Decomposes by population, age, phone ownership and earbud ownership, adds an active-use factor, and cross-checks.
- **Standout:** Distinguishes people from pairs, converts the stock to an annual sales flow through a replacement cycle as the second route, and explains how to add a brand-share factor if asked about one maker.

**Model answer.** *Setting only: no company data is used; all figures are assumptions.* I'll define the quantity as pairs of wireless earbuds, of any maker, used at least weekly. That is a stock. I'll take a city of 10 million people.

Decompose by people. Of 10 million, suppose 65% are of an age to own and use them (roughly 15 to 64): 6.5 million. About 85% of those have a smartphone, which I treat as a prerequisite: 5.5 million. About 40% of smartphone owners own wireless earbuds (a judgment, anchored to the proportion of my own acquaintances): 2.2 million owners. About 75% of owners use them at least weekly: 1.66 million people. Some people keep a second pair, so I'll take 1.1 pairs per active person: about 1.8 million pairs in active use.

Check, using the flow. If a pair lasts about 2.5 years before replacement, a stock of 1.8 million implies about 730,000 pairs bought a year in the city, which is 7.3 per 100 people per year. That is high but plausible for a wealthy, phone-heavy city, and I'd expect it to be lower in a lower-income one. This second route does not use the ownership factor directly, so it is a real check on the plausibility of the stock.

Sensitivity. Ownership share dominates (at 25% I get about 1.1 million pairs, at 55% about 2.5 million). If asked about one maker's earbuds, I would add a brand-share factor, say 30% to 60%, and I'd flag it as my weakest anchor, since it is the one I know least about. My answer: about 1.8 million pairs, plausibly 1.1 to 2.5 million. I would change it if I learned the city's smartphone penetration was well off my 85%.

*Company note.* Apple is the setting only: `Inferred` from third-party reports that product and technical deep dives at Apple may include device-related estimates `[unverified: candidate-reported]`. No Apple data is used or implied.

**Follow-ups.**

- **Q.** How do you turn pairs in use into annual sales? **A.** "Through a replacement cycle plus growth. With 1.8 million pairs in active use and an average life of about 2.5 years, replacements are 1.8 ÷ 2.5 = about 0.72 million a year. If the stock grows about 10% a year, that adds about 0.18 million. Annual city sales are therefore about 0.9 million pairs. I would check the life assumption against my own and my friends' experience, since battery wear sets it, and note that a one-year change in life moves the answer by about 40%."
- **Q.** If asked about one maker's share, how would you add it? **A.** "I would add a share factor and say where it comes from. Suppose one maker has about 30% of pairs in use: about 540,000 pairs. That share is an assumption I would anchor to public market-share reports rather than invent, and I would flag that share among premium or recent buyers is usually higher than the share of the installed base. I would also say what the number is for: sizing an accessory or a service for that maker's users needs the installed base, while sizing next year's sales needs the share of new purchases."

#### IQ-C04-04 · Intermediate · estimation · PR

**Prompt.** Estimate the annual revenue opportunity for a mobile wallet in a country of 50 million adults.

**Rubric.**
- **Baseline:** "Fifty million adults times something," with no funnel.
- **Strong:** Builds a funnel from adults to users, then multiplies by transactions and a take rate, and states the assumptions.
- **Standout:** Separates the long-run potential from a near-term adoption path, gives a range driven by the take rate, and names the decision the number serves.

**Model answer.** I'll define the opportunity as net revenue a wallet could earn from payments, per year, and I'll separate long-run potential from a year-three figure.

Funnel. Fifty million adults. About 70% have a smartphone: 35 million. About 60% of those hold a bank account or equivalent that a wallet can connect to: 21 million. In the long run, perhaps 40% of them use a wallet regularly: 8.4 million users.

Revenue per user. Suppose a regular user makes about 12 payments a month, 144 a year, at an average of $15, so $2,160 of annual payment value. If the wallet earns a take rate of 0.5%, revenue is about $10.80 per user per year. Total: 8.4 million × $10.80 ≈ $91 million a year.

Near term. If adoption reaches 15% in year three: 21 million × 15% = 3.15 million users × $10.80 ≈ $34 million.

Range. The take rate drives the spread: at 0.3% it is about $54 million a year at 40% adoption, and at 0.8% it is about $145 million. Adoption drives the timing more than the total.

Check. Per user, $10.80 a year is small relative to the cost of acquiring a user, so the question is whether the wallet can earn other revenue (lending, merchant services) or must be very cheap to run. The estimate says the payments take rate alone is a thin business, which is the important finding. The decision it serves is whether to enter on payments alone, and I'd say not without a second revenue stream. Payment-method context is region-specific `[as of 2026-10; varies by market]`; in a country with an established low-cost interbank payment system, take rates may be lower than 0.5%, which would weaken the case further.

**Follow-ups.**

- **Q.** Which assumption drives the range most, and how do you bound it? **A.** "The take rate. Revenue per user is payment value times take rate, and competition pushes the take rate down. At 0.3% the long-run revenue is 8.4 million × $2,160 × 0.003 = about $54 million; at 1.0% it is about $181 million, a threefold range from one assumption. Adoption matters too: 25% to 55% of the 21 million with accounts gives 5.3 to 11.6 million users. I would present the central case of about $91 million, the range of roughly $50 to $180 million, and say the first thing to test is what take rate comparable wallets actually earn."
- **Q.** What decision does the number serve, and would a near-term figure change it? **A.** "It serves an invest-or-not decision, so the near-term path matters more than the long-run ceiling. At 15% adoption in year three there are 3.15 million users and about 3.15 × $10.80 = $34 million a year. If building and launching costs $60 million over three years, the near-term revenue does not pay it back, while the long-run figure might. So I would recommend a staged plan: fund the first stage against a year-two adoption target, and expand only if the target is met."

#### IQ-C04-05 · Intermediate · estimation · PR · Amazon

**Prompt.** A retailer wants to deliver 200,000 same-day orders in one metro area. Estimate how many delivery vans it needs.

**Rubric.**
- **Baseline:** "200,000 divided by some number per van," with no consideration of stops, utilization or peak.
- **Strong:** Converts orders to stops, uses stops per van per day, adds a utilization allowance, and states the result.
- **Standout:** Identifies stops per van as the dominant assumption (density), checks the cost per order, and says what would change the plan.

**Model answer.** *Setting only: no real operating data is used or implied; every figure is an assumption.* I'll define the target as vans in service on a peak day to complete 200,000 orders.

Orders to stops. Some orders go to the same address, so suppose 1.2 orders per stop: 200,000 ÷ 1.2 ≈ 167,000 stops. A van's capacity is set by stops per day, which depends on how dense deliveries are. In a dense metro, perhaps 120 stops a day (about 15 an hour over an 8-hour route, including driving and handover). Vans: 167,000 ÷ 120 ≈ 1,390. No operation runs vehicles at 100% utilization because of breakdowns, imbalance between routes and time windows, so at 80% the fleet is about 1,390 ÷ 0.8 ≈ 1,740.

Check. Cost: if a van and driver cost about $200 a day all-in, that is about $350,000 a day, or about $1.74 an order. That is plausible for dense delivery and would be too low for sparse areas. Per capita: if the metro has 10 million people, 200,000 orders is 2 per 100 people per day, which is high but not implausible for a mature same-day service.

Sensitivity. Stops per van dominates: at 80 stops a day the fleet is about 2,600, and at 150 it is about 1,390. Orders per stop matters less. So I would ask about route density, and I'd compare two cities before committing.

Decision. If the unit cost per order from vehicles alone is already $1.74, the retailer needs the order value or delivery fee to cover it, so I would also ask for average order value. I would change the plan if density were much lower than assumed, which would favor a different model (pickup points, lockers, or scheduled delivery days).

*Company note.* Amazon is the setting only: `Inferred` from third-party reports that capacity and logistics estimates appear in some retail loops `[unverified: candidate-reported]`.

**Follow-ups.**

- **Q.** What if traffic cuts stops per van from 120 to 80? **A.** "Vans scale inversely with stops per van. 167,000 stops ÷ 80 is about 2,090 vans, and at 80% utilization about 2,610, which is 50% more than the 1,740 in my base case. Cost per order rises from about $1.74 (1,740 × $200 ÷ 200,000) to about $2.61. That shows density is the dominant assumption: a third fewer stops per van raises the fleet and the cost per order by half, so I would test it with a pilot in two zones before committing to a fleet."
- **Q.** How would you reduce the fleet without cutting service? **A.** "By raising stops per van, because that is the lever with the most leverage. Batching orders into delivery windows, offering pickup points for part of the volume, and better route planning might lift stops per van from 120 to about 132, which is 10%. Then 167,000 ÷ 132 ÷ 0.8 is about 1,580 vans, 9% fewer. I would also look at utilization: raising it from 80% to 85% saves a further 6%. Each lever has a cost in customer choice or in software, so I would compare the savings with those costs and pilot the cheapest first."

#### IQ-C04-06 · Hard · estimation · TE

**Prompt.** Estimate the network capacity needed for a live stream with five million concurrent viewers.

**Rubric.**
- **Baseline:** "A lot of bandwidth, maybe a few hundred gigabits," with no calculation.
- **Strong:** Multiplies viewers by bitrate, converts units correctly, adds headroom, and gives a server count.
- **Standout:** Handles bits versus bytes, peak and ramp-up, total data volume and cost, and ties the numbers to a design decision such as a content network and bitrate tiers.

**Model answer.** I'll define the quantity as peak outbound bandwidth to viewers and the total data delivered for a two-hour event.

Bandwidth. Five million concurrent viewers. With adaptive quality, many viewers receive a mid-tier stream, so I'll assume an average of 4 megabits per second. 5,000,000 × 4 Mbps = 20,000,000 Mbps = 20 terabits per second. In bytes, dividing by 8, that is 2.5 terabytes per second. I'm watching the units here: network capacity is in bits, storage and volume are in bytes.

Volume. Two hours is 7,200 seconds. 2.5 TB/s × 7,200 = 18,000 TB = 18 petabytes. At an assumed delivery price of $0.01 per gigabyte (a judgment, and the kind of figure that changes with contracts `[as of 2026-10]`), 18 million gigabytes costs about $180,000.

Capacity. If one edge server can send 40 gigabits per second, 20,000 Gbps ÷ 40 = 500 servers at full load. No one runs at 100%, so with a target of 50% utilization for headroom the fleet is about 1,000 servers, spread across regions because viewers are everywhere and a single site cannot carry the load.

Check. Per viewer, 4 Mbps for two hours is 4 × 7,200 ÷ 8 = 3,600 megabytes, or 3.6 GB, and 5 million viewers × 3.6 GB = 18,000,000 GB, which matches the 18 petabytes. Both ways agree.

Sensitivity and design. Bitrate dominates, so a lower top tier or a smarter ladder of quality levels cuts capacity directly: dropping the average from 4 to 3 Mbps saves 25%. The shape of the audience matters as much as the size: if viewers join within five minutes of the start, the peak is a ramp, and the system must be ready at the start, not on average. Because the ramp and the failure cost are what hurt, I'd ask about the distribution of start times and whether the stream can degrade gracefully (lower quality) rather than fail (C22 develops system-design answers).

**Follow-ups.**

- **Q.** Does a peak of 20 terabits per second change the design? **A.** "Yes: no single origin can send that, so the design must use a content delivery network. Viewers are served from edge caches near them, and each video segment is fetched from the origin once per edge location, not once per viewer, so origin egress is a small fraction of the 20 Tbps. I would use more than one delivery provider for resilience, an adaptive bitrate ladder so that congested viewers step down instead of buffering, and a load test with a ramp, since viewers arrive in a surge at the start. The capacity number's job is to tell us this cannot be a single-site design."
- **Q.** How would you reduce the delivery cost of about $180,000? **A.** "Three levers. Lower the average bitrate: at 3 Mbps instead of 4, volume falls 25% to about 13.5 petabytes and the cost to about $135,000, saving $45,000 at some loss of picture quality. Negotiate the price per gigabyte, which depends on volume commitments. Use a peer-assisted or multicast approach where the platforms allow it. I would keep buffering rate and viewer drop-off as guardrails, because a cheaper stream that stalls costs more in lost viewers than it saves."

#### IQ-C04-07 · Hard · estimation · PR

**Prompt.** Your CEO says the market for our product is $10 billion. How would you test that in 15 minutes?

**Rubric.**
- **Baseline:** "I'd research the market online and see if it's right."
- **Strong:** Asks for the decomposition, rebuilds it bottom-up, finds the factor that differs, and gives a revised number.
- **Standout:** Separates total from serviceable from obtainable, audits the claim for typical errors, gives a range, and says what to do with the gap.

**Model answer.** I'd first ask where the number comes from, because a market claim is a decomposition in disguise. Suppose the claim is 5 million businesses times $2,000 a year, which is $10 billion. That is a clear structure, so I can test each factor.

Factor one: 5 million businesses. Do all of them have the problem the product solves? I'd guess only about a fifth do, so 1 million. Factor two: can we reach them? A product sold through a certain channel reaches a share of them, say 60%, so 600,000. Factor three: the price. Is $2,000 what customers pay, or a list price for the highest tier? If typical buyers pay about $1,200, the serviceable market is 600,000 × $1,200 = $720 million.

So the claim is about 14 times higher than my rebuild ($10 billion ÷ $0.72 billion). The gap comes from counting every business, counting them all as reachable and pricing them at the top tier. These are the usual errors: a total market presented as a serviceable one, and a price applied to buyers who would not pay it.

Range. Taking each factor's plausible range (needing the product 10% to 30%, reachable 40% to 80%, price $800 to $1,800), the serviceable market is about 5 million × 0.10 × 0.40 × $800 = $160 million to 5 million × 0.30 × 0.80 × $1,800 = $2.16 billion, with a base of about $720 million. Even the high end is a fifth of the claim.

What I'd do. I'd keep $10 billion as an upper bound on the total opportunity and use about $0.7 billion for planning, and I'd say which factor I'd test first: the share of businesses with the need, with ten customer interviews. I'd want to know what decision the number is being used for, because a $10 billion claim might be fine for a story to investors and wrong for a hiring plan.

**Follow-ups.**

- **Q.** The CEO insists the $10 billion figure is right. What do you do? **A.** "I would not argue about the number; I would make the decomposition visible. I would show the rebuild (1 million businesses with the problem, 600,000 reachable, $1,200 typical price, about $720 million serviceable) next to the claim's structure and agree what each term means: total, serviceable and obtainable. Then I would propose a 15-minute check on the weakest factor, for example calling ten customers to learn what they actually pay. The CEO's figure can stay as the long-run vision; the plan should use the serviceable and obtainable numbers, and I would say that plainly."
- **Q.** How would you get from the serviceable market to what is obtainable? **A.** "From the capacity of our channels. Suppose a sales team of 10 reps each closes 60 deals a year at $1,200: $0.72 million a year of new revenue, plus a self-serve channel I would estimate separately from traffic and conversion. Against a $720 million serviceable market, that is 0.1% a year. The gap says the constraint is distribution, not market size, so the decision the number should drive is how to build channels, not whether the market is big enough."

#### IQ-C04-08 · Beginner · estimation · PR

**Prompt.** How many customer-support agents does a company need for a product with two million monthly users?

**Rubric.**
- **Baseline:** Gives a number from instinct or a ratio of agents to users, with no decomposition.
- **Strong:** Decomposes into contacts, handling time and agent hours, states the assumptions, gives a range and a check.
- **Standout:** Chooses the swing assumption, converts the answer into cost per user, and says how deflection or peaks would change it.

**Model answer.** I would build it from contacts and agent time. Two million monthly users. Suppose 8% contact support in a month (a judgment, anchored to products with good self-service): 160,000 contacts. Each takes about 12 minutes including notes: 160,000 × 12 ÷ 60 = 32,000 hours. An agent is paid for about 150 hours a month, but breaks, training and leave leave about 70% as handling time, so 105 hours: 32,000 ÷ 105 = about 305, so about 300 agents.

Check. Two million users per 300 agents is one agent per 6,700 users, plausible for a product with good self-service and too lean for one with complex accounts. Cost: at $4,000 a month per agent, 300 agents cost $1.2 million, or $0.60 per user per month.

Range. A contact rate of 5% gives 190 agents and 12% gives 457. So about 300, plausibly 190 to 460, and the contact rate is the swing assumption; I would take it from actual ticket counts. If the question is for a staffing plan, I would add that demand is not flat across the week.

**Follow-ups.**

- **Q.** What if a chatbot resolves 30% of contacts? **A.** "Agents would handle 70% of 160,000, which is 112,000 contacts and 22,400 hours, so about 213 agents, roughly 90 fewer, about $360,000 a month at $4,000 each. That assumes the 30% are fully resolved and not just deferred, so I would check how many return as agent contacts."
- **Q.** Staffing for the average leaves you short on Mondays. What do you do? **A.** "Plan for the peak, not the average. If Monday volume is 1.4 times the daily average, covering it needs about 420 agents that day, but that is a scheduling and flexible-capacity question (shifts, overflow partners, longer response targets) and not a case for 420 permanent hires."

#### IQ-C04-09 · Intermediate · estimation · PR

**Prompt.** How many public electric-vehicle charging points does a city of three million people need in five years?

**Rubric.**
- **Baseline:** Names a number or a ratio with no decomposition.
- **Strong:** Estimates the stock of vehicles, the share that is electric and needs public charging, converts sessions into chargers, and gives a range.
- **Standout:** Adds peak demand, identifies the swing assumption, and compares the result with a city further along instead of trusting it.

**Model answer.** I would estimate a stock of vehicles first, then convert it into demand for chargers. Three million people. Suppose one car per four people: 750,000 cars. In five years suppose 10% are electric (a judgment; plausible range 5% to 20%): 75,000 vehicles. Suppose 70% can charge at home or work, so 30% rely on public charging: 22,500 vehicles. Each needs about two public sessions a month: 45,000 sessions a month, 1,500 a day.

From sessions to chargers. A public charger handles about 8 sessions a day (about an hour each over eight busy hours, an assumption): 1,500 ÷ 8 = about 188. Demand clusters in evenings and at weekends, so I would plan for 1.5 times that: about 281 chargers.

Check. 281 chargers for 75,000 electric vehicles is one per 267 vehicles. I would compare that with a city further along in adoption instead of trusting it. Range: electric share of 5% gives about 141 and 20% about 562, so about 281, plausibly 141 to 562. The electric share dominates, then the share who can charge at home. If this were for a procurement decision, I would stage the build against the adoption actually observed each year.

**Follow-ups.**

- **Q.** What if only half of owners can charge at home or work? **A.** "Then 50% rely on public charging instead of 30%, and the number scales by 0.5 ÷ 0.3: about 469 chargers. That shows the home-charging share is the second swing assumption, so I would check housing types in the city, because apartment blocks without parking behave differently from houses."
- **Q.** Would you use fast or slow chargers for this estimate? **A.** "The estimate counts sessions, so the type enters through the sessions per charger per day. A fast charger serves more sessions a day than a slow one, so I would estimate by type: fast chargers on corridors and for short stops, slow ones where cars park for hours, and size each from the sessions it would serve."

#### IQ-C04-10 · Intermediate · estimation · PR

**Prompt.** A designer says a change will save each user two seconds on a task they do many times a day. Is it worth building?

**Rubric.**
- **Baseline:** Says two seconds is too small to matter, or that every improvement is worth it, without numbers.
- **Strong:** Multiplies out the time saved, converts it to value, haircuts it for how time savings really behave, and compares with the cost.
- **Standout:** Separates the customer's value from what the company can capture, says what else the change might move (friction, retention), and proposes a cheap way to test it.

**Model answer.** I would turn two seconds into a total and then into a decision. Suppose a work tool with 200,000 daily active seats, each doing the task 25 times a day (invented). Time saved: 200,000 × 25 × 2 seconds = 10,000,000 seconds, about 2,778 hours a day, and over 250 working days about 694,444 hours a year.

Value. At a loaded cost of $40 an hour that is about $27.8 million a year of customer time. But two-second savings are not recovered as work; people do not convert slivers into output. Suppose only 30% is realized: about $8.3 million. The company captures a small part through retention and willingness to pay; suppose 5%: about $416,667 a year.

Cost. Suppose two engineers for three months plus design and testing: about $150,000. Payback is about 4.3 months on the captured value. So it clears the bar, but the number rests on two weak assumptions, the realized share and the captured share.

What I would add. The larger effect of a faster task may be less friction, which shows up as more use or fewer abandoned tasks, not as saved time. I would test a faster version on a subset of seats and read task completion and weekly use, instead of arguing about the value of two seconds. I would change my mind if the task is rare for most users, because then the total shrinks.

**Follow-ups.**

- **Q.** What would make you build it even if the value looked small? **A.** "If it removes a visible irritation that shows up in support tickets or reviews, or if it lowers a failure rate such as abandoned tasks. A small time saving that also reduces errors or frustration can matter more than the time itself, and I would check for that in the data."
- **Q.** How would you test it quickly? **A.** "Ship the faster version to a random 10% of seats for four weeks and compare task completion, tasks per user per day and weekly active use with the rest, reading the intervals. If the whole interval is above the smallest effect worth the cost, build for everyone."

#### IQ-C04-11 · Hard · estimation · PR

**Prompt.** In a country with 800 million adults, estimate the payments per second a payments app must handle at its evening peak.

**Rubric.**
- **Baseline:** Gives an average rate, or a number with no peak and no decomposition.
- **Strong:** Decomposes users, payments per user and the daily total, converts to a rate, and applies a peak factor with a stated reason.
- **Standout:** Separates the average from the peak minute, checks the ratio between them, gives a range, and says what the number means for how the system is sized.

**Model answer.** I would define the unit first: a completed payment. Adults: 800 million (invented). Suppose 60% have a bank or wallet account: 480 million. On a typical day suppose 25% of them pay with the app: 120 million active users. Each makes about 2.5 payments: 300 million payments a day, which is 3,472 a second on average.

Payments are not spread evenly. Suppose the busiest hour carries 15% of the day: 45 million an hour, 12,500 a second. The peak minute runs above the peak hour, say 1.5 times: about 18,750 a second.

Check. The peak is about 5.4 times the average, plausible because payments cluster in a few evening hours and around paydays. A ratio near 1 would mean flat demand and one near 20 would suggest a spike-driven product such as ticketing. Per capita, 120 million daily users is 15% of all adults, which I would test against any published usage figure.

Range. The share of account holders who pay on a given day dominates: 15% to 35% gives about 11,250 to 26,250 a second at the peak. So about 18,750, plausibly 11,000 to 26,000.

What it means. The system must be sized for the peak minute, with headroom for festival or payday days, not for the average of 3,472; so the question to engineering is the capacity at the busiest minute and what degrades first when it is exceeded.

**Follow-ups.**

- **Q.** A festival day has three times the normal volume. What does that do to the number? **A.** "The peak would be about 56,250 a second. I would check whether the system is built for that, whether the extra volume is spread or concentrated into a few minutes, and what the plan is if it is concentrated: queue and retry with clear status for the user, not drop payments."
- **Q.** What would you ask engineering to measure before trusting the estimate? **A.** "The actual payments per second by minute for the last busiest days, the ratio of the peak minute to the peak hour and to the daily average, and the number of distinct users paying per day. Those replace the three assumptions that matter most: active share, payments per user and the peak shape."

## 12. Exercises

Ten exercises. Each has a model solution and an alternative. Numbers are assumptions unless marked.

#### EX-C04-01 · Photos uploaded per day

**Problem.** Estimate the photos uploaded per day on a social app with 20 million daily active users.

**Context.** You are sizing storage growth.

**Data.** *Invented.* About a quarter of daily users upload on a given day, and each uploader uploads about two photos.

**Constraints.** Five minutes; show a cross-check.

**Expected approach.** Funnel decomposition with units.

**Solution.** Uploaders: 20,000,000 × 25% = 5,000,000. Photos: 5,000,000 × 2 = 10,000,000 a day. Check: 0.5 photos per daily user, plausible for a social app. Storage, at an assumed 3 MB a photo (the size used in Worked example 3): 10,000,000 × 3 MB = 30,000,000 MB = 30 TB a day, or about 11 PB a year before copies (30 × 365 ≈ 11,000 TB).

**Alternative solution.** Estimate from the supply side: a typical phone user takes a few photos a day and shares about a tenth of them.

**Tradeoffs.** A daily share of 25% is the dominant assumption; check it against event logs when available.

#### EX-C04-02 · Taxis and ride-hail vehicles in a city

**Problem.** Estimate the number of taxi and ride-hail vehicles in a city of 8 million, using two routes.

**Context.** A launch team needs a rough size for driver supply.

**Data.** *Invented.* 5% of residents take a taxi or ride-hail trip on a typical day; a vehicle does about 20 trips a day; a comparable city has about 2.5 vehicles per 1,000 people.

**Constraints.** Two routes that are independent enough to mean something.

**Expected approach.** Demand route, benchmark route, and reconcile.

**Solution.** Demand route: 8,000,000 × 5% = 400,000 trips a day; 400,000 ÷ 20 = 20,000 vehicles. Benchmark route: 8,000,000 × 2.5 ÷ 1,000 = 20,000 vehicles. The two agree. Note that the second route reuses a comparable city, so confirm that the city is truly comparable in size, density and regulation.

**Alternative solution.** Add a supply-side route: count taxi stands or driver licenses if you can.

**Tradeoffs.** Agreement between two routes built on similar behavior is weaker than agreement between a demand route and a count of licenses.

#### EX-C04-03 · Classify the anchors

**Problem.** Classify each anchor as D, P or J and say how you would state it aloud: (a) seconds in a day; (b) India's population; (c) the share of adults with a smartphone; (d) the price of a coffee; (e) hours in a year; (f) the share of the world that is online; (g) bits in a byte; (h) visit-to-purchase conversion for online retail.

**Context.** You are preparing an anchor sheet.

**Data.** None beyond the list.

**Constraints.** One line each.

**Expected approach.** Apply the anchor ladder (FW-C04-03).

**Solution.** (a) D: "86,400, about 10^5." (b) P: "about 1.5 billion; I'd verify it if it matters." (c) J: "I'll assume 85%, plausibly 70% to 95%." (d) J: "I'll assume $4; it varies by city." (e) D: "8,760, about 9,000." (f) P: "about three-quarters (74% in 2025, per the ITU); I'd check it if it matters." (g) D: "eight." (h) J: "1% to 4%, wide by category; I'll take 2%."

**Alternative solution.** Add a confidence factor to each: "within 10%," "within a factor of two."

**Tradeoffs.** Stating provenance costs a few words and prevents the interviewer from asking "are you sure?"

#### EX-C04-04 · Range for a new feature's weekly users

**Problem.** Estimate weekly active users of a new feature, as a low, base and high case, and the geometric midpoint.

**Context.** The product has 2 million daily active users.

**Data.** *Invented.* Share who discover the feature: 25% (low), 40% (base), 60% (high). Share of those who try it: 15%, 25%, 35%. Share of triers who use it weekly: 20%, 30%, 40%.

**Constraints.** Show arithmetic and explain why the extreme range overstates the real uncertainty.

**Expected approach.** The range method (FW-C04-06).

**Solution.** Base: 2,000,000 × 0.40 = 800,000; × 0.25 = 200,000; × 0.30 = 60,000. Low: 2,000,000 × 0.25 × 0.15 × 0.20 = 15,000. High: 2,000,000 × 0.60 × 0.35 × 0.40 = 168,000. Geometric midpoint: the square root of 15,000 × 168,000 ≈ 50,000. The extreme range spans a factor of about 11 because it assumes all three factors are at their lows together or highs together; independent errors partly cancel, so a typical range is narrower, perhaps 35,000 to 90,000. Report: about 50,000 to 60,000, plausibly 25,000 to 100,000.

**Alternative solution.** Give a range only for the two most uncertain factors and hold the third at its base.

**Tradeoffs.** Fewer varied factors give a tighter range and hide uncertainty in the factor you fixed.

#### EX-C04-05 · Mental-math drill

**Problem.** Compute in your head, then check: (1) 15% of 480; (2) 7% of 900; (3) 23 × 12; (4) 3 million × 400 thousand; (5) 2.5 million a day, per year; (6) doubling time at 6% growth; (7) a 20% rise then a 20% fall; (8) 50 Mbps in megabytes per second; (9) 600 GB in terabytes; (10) seconds in three days.

**Context.** Warm-up for timed estimation rounds.

**Data.** None.

**Constraints.** Two minutes for all ten.

**Expected approach.** Use percentages, splitting, powers of ten and unit rules from C04.7.

**Solution.** (1) 72 (10% is 48, 5% is 24). (2) 63 (1% is 9). (3) 276 (230 + 46). (4) 1.2 trillion (12 × 10^11). (5) about 0.9 billion (× 365, or × 400 less 10%). (6) 12 years (72 ÷ 6). (7) down 4% (1.2 × 0.8 = 0.96). (8) 6.25 MB/s. (9) 0.6 TB. (10) 259,200 seconds, about 2.6 × 10^5.

**Alternative solution.** Do (3) as 23 × 12 = 23 × 6 × 2 = 138 × 2 = 276.

**Tradeoffs.** Speed risks slips; say the intermediate step aloud so errors are visible and correctable.

#### EX-C04-06 · Reconcile two routes

**Problem.** Two estimates of a city's daily active users of an app disagree: top-down gives 300,000 and bottom-up from installs gives 120,000 (1.2 million installs × 10% daily active). Reconcile them.

**Context.** The routes differ by a factor of 2.5.

**Data.** *Invented.* The install figure includes people who installed years ago and stopped. The top-down route assumed that 8% of the population uses the app daily.

**Constraints.** Decide which assumption to challenge first, and give a final estimate.

**Expected approach.** Find the weakest assumption in each route; check each against a plausibility test.

**Solution.** The bottom-up route uses installs, which overcount people who left, but its 10% ratio of daily users to installs may then be too low for the installs that are still active. The top-down route's 8% daily share may be too high for a niche app. A per-capita check: 300,000 daily users in a city of 3.75 million (8%) would make this app very widely used, which seems high; 120,000 is 3.2%. Without better data I'd take the geometric midpoint, about 190,000 (the square root of 300,000 × 120,000), and I'd ask for one fact that separates them: the daily-to-monthly active ratio in the analytics data, which converts monthly installs of active users to a daily figure.

**Alternative solution.** Find a third route (for example from advertising impressions) and take the value the two closest routes support.

**Tradeoffs.** A midpoint is a compromise; the better move is to find the fact that explains the gap.

#### EX-C04-07 · From a number to a decision

**Problem.** Estimate the annual revenue from a niche tool and decide whether a dedicated team is justified.

**Context.** The company requires $2 million of annual revenue to justify a dedicated team.

**Data.** *Invented.* 400,000 potential users; adoption between 2% and 8%, base 5%; price $120 a year.

**Constraints.** Use the so-what bridge, including break-even adoption.

**Expected approach.** Threshold, compare, driver, narrow, act.

**Solution.** Base: 400,000 × 5% = 20,000 users × $120 = $2.4 million. Low: 400,000 × 2% = 8,000 × $120 = $0.96 million. High: 400,000 × 8% = 32,000 × $120 = $3.84 million. Break-even adoption: $2,000,000 ÷ $120 = 16,667 users, which is 4.2% of 400,000. The range straddles the $2 million threshold, and the base case is only slightly above it, so the estimate does not settle the decision. The driver is adoption, so the cheapest narrowing step is a small pre-order or fake-door test to measure interest. Action: run a four-week test and fund the team only if measured interest implies adoption above about 4.2%.

**Alternative solution.** Fund a half-size team with an explicit review at six months.

**Tradeoffs.** The test delays a decision by four weeks and avoids committing a team to a base case that is barely above the threshold.

#### EX-C04-08 · Units and capacity for video calls

**Problem.** A company runs 2,000 concurrent video calls at its peak, each with four participants. Each participant uploads 1.5 Mbps and downloads 3 Mbps. Estimate the bandwidth the service must handle, and the data per hour.

**Context.** Capacity planning for an internal tool.

**Data.** As given (assumptions).

**Constraints.** State units carefully.

**Expected approach.** Capacity decomposition and unit conversion.

**Solution.** Participants: 2,000 × 4 = 8,000. Upload: 8,000 × 1.5 Mbps = 12,000 Mbps = 12 Gbps. Download: 8,000 × 3 Mbps = 24,000 Mbps = 24 Gbps. In bytes: 12 Gbps ÷ 8 = 1.5 GB/s inbound; 24 Gbps ÷ 8 = 3 GB/s outbound. Per hour: 1.5 GB/s × 3,600 = 5,400 GB = 5.4 TB inbound; 3 GB/s × 3,600 = 10,800 GB = 10.8 TB outbound. With 50% headroom, plan for about 18 Gbps in and 36 Gbps out.

**Alternative solution.** Use a media relay that forwards one stream per participant, which changes the download factor; ask engineering how the system is built.

**Tradeoffs.** Peak capacity costs more than average capacity, and under-provisioning shows up as dropped calls at the worst time.

#### EX-C04-09 · Spot the flaw

**Problem.** A candidate estimates daily pizza orders in a city of 1 million like this: "1,000,000 people times 30% order pizza each day times one pizza is 300,000 orders a day." Critique and correct.

**Context.** A practice transcript.

**Data.** None given; use your own anchors.

**Constraints.** Name each flaw.

**Expected approach.** Check units, per-capita plausibility and the stock-flow definition.

**Solution.** Flaws: (1) the 30% is "per day," which implies 110 pizzas per person per year on average (0.3 × 365), implausible; (2) the candidate did not define whether an order is a pizza or a checkout; (3) there is no cross-check. A per-capita test exposes the error immediately. Correction: define an order as one checkout; assume 15% of people order pizza for delivery in a given week and place one order, so 150,000 orders a week, about 21,000 a day (150,000 ÷ 7), or 0.02 per person per day, roughly 8 a year, which is plausible. Cross-check from supply: 400 pizza places × 50 delivered orders a day = 20,000.

**Alternative solution.** Estimate households instead of people, then orders per household.

**Tradeoffs.** A weekly share is easier to reason about than a daily one, and converting to a daily number is one extra step.

#### EX-C04-10 · A five-minute drill with calibration

**Problem.** In five minutes, estimate the daily trips on ride-hailing apps in a city of 5 million, and give an 80% confidence interval.

**Context.** A timed spoken drill.

**Data.** None given.

**Constraints.** Include a cross-check and a range.

**Expected approach.** The estimation protocol, compressed.

**Solution.** Define a trip as one completed ride. Adults: 5,000,000 × 70% = 3,500,000. Share riding on a typical day: 4%: 140,000 riders. Trips per rider: 1.4: about 196,000, so about 200,000 trips. Cross-check from supply: 12,000 active drivers × 16 trips = 192,000, which agrees. Range: share of adults 3% to 6% gives 105,000 to 210,000 riders and about 150,000 to 300,000 trips. My 80% interval: 120,000 to 320,000 trips. Note which assumption dominates (the adult share) and what would calibrate it (trips in a similar city).

**Alternative solution.** Start from supply: drivers times trips, then check from demand.

**Tradeoffs.** In five minutes you have time for one check; choose the one that is most independent of your main assumption.

## 13. Practice protocol

**Timed drills (three a week for three weeks).**

- *Week 1: five-minute estimates.* Pick a prompt (the exercises and IQ-C04-01 to IQ-C04-11). Clarify, decompose, assume, compute, say the answer. Five minutes.
- *Week 2: ten-minute estimates with a check.* Add a second route, a per-capita check, and a range.
- *Week 3: add the decision.* Add the so-what bridge, and include one "critique a number" drill (IQ-C04-07).

### C04.8 Timed drills and calibration practice

Timed drills build speed; calibration builds honesty about your ranges. Calibration means that when you say a range holds the truth 80% of the time, it does. Research on judgment commonly finds that people's intervals are too narrow, so their ranges capture the truth less often than they claim: in one review, 90% intervals contained the true value only about half the time `[V: Soll and Klayman, Journal of Experimental Psychology: Learning, Memory, and Cognition 30(2), 299-314, 2004; McKenzie, Liersch and Yaniv, 2008]`. Train it with quantities you can check. For each, write an 80% interval before you compute, then compute:

| # | Quantity | Answer |
|---|---|---|
| 1 | Seconds in a week | 604,800 |
| 2 | Minutes in a year | 525,600 |
| 3 | Hours in ten years | 87,600 |
| 4 | Days in a million seconds | about 11.6 |
| 5 | Years in a billion seconds | about 31.7 |
| 6 | 17 × 24 | 408 |
| 7 | 12.5% of 640 | 80 |
| 8 | Weeks in 10,000 hours | about 59.5 |
| 9 | Working years in 10,000 hours (2,000 hours a year) | 5 |
| 10 | Kilobytes in a gigabyte (decimal) | 1,000,000 |

Count how many of your ten intervals contain the answer. If fewer than eight do, your intervals are too narrow; widen them by about 50% and repeat with a fresh set. Track the hit rate in the journal over the three weeks.

**Feedback checklist (yes, partly, no).**

1. Did I define the quantity, unit and scope, and say stock or flow?
2. Did I use three or four estimable factors?
3. Did I state each assumption with a reason and a provenance?
4. Did I use round numbers and carry units?
5. Did I check with a second route and a per-capita test?
6. Did I name the dominant assumption?
7. Did I give a range and round to one or two figures?
8. Did I say what decision the number serves?
9. Did I recover cleanly from any arithmetic slip?
10. Did I finish in the time?

**With a partner.** Ask your partner to challenge your largest assumption at minute four ("why 25%?") and to correct one of your numbers at minute six. Practice updating the whole chain aloud and saying how much the answer moves.

**Answer journal.** For each drill record the date, the prompt, your estimate and range, the dominant assumption, your score out of ten, the item to fix, and, for calibration, your hit rate. After six drills, look for the factor you most often get wrong, and write a better anchor for it.

## 14. Implementation playbook

Apply the chapter on real work over the next two weeks. Each deliverable doubles as an interview story.

**Days 1 to 3.** Collect three numbers from your own work that people quote without a source: a market size, a traffic figure, a capacity claim. For each, ask for the decomposition, or rebuild it with the protocol (FW-C04-01) and a second route. Note where the figure and your rebuild disagree.

**Week 1.** Size the opportunity for your team's next feature using the range method (FW-C04-06) and the so-what bridge (FW-C04-05). Write a one-page memo using the decision-memo template from C02 (FW-C02-06), with the threshold, the range, the driving assumption and the cheapest way to narrow it.

**Week 2.** Start a forecast log: before each launch or experiment, write your estimate of the key number with an 80% interval, then score it afterward. Do this five times.

**Week 2.** Sanity-check one figure on a slide that someone else made, using a per-capita check and a bounds check, and tell the author what you found, kindly and with the arithmetic.

**Deliverables that become stories:** the sizing memo (a time you used numbers to shape a decision), the forecast log (calibration and learning), and the slide check (catching an error and handling it well). Keep the numbers real.

## 15. Key takeaways and further reading

### Key takeaways

1. Define the quantity first, then decompose it into three or four factors you can reason about, and say each assumption aloud with a provenance.
2. Check every estimate by a second route and a per-capita test, and name the assumption that dominates the result.
3. Round to one or two figures and give a range; false precision signals that you do not know what you do not know.
4. Tie the number to a decision: name the threshold, compare the range with it, and say what would narrow the gap.
5. Practice mental math and calibration, because arithmetic nerves and overconfident ranges cost more answers than reasoning does.

### Further reading

- Lawrence Weinstein and John A. Adam, *Guesstimation* (2008). A collection of worked estimation problems in the Fermi tradition.
- Sanjoy Mahajan, *Street-Fighting Mathematics* (2010). Short, practical methods for getting approximate answers fast.
- Douglas W. Hubbard, *How to Measure Anything* (2nd edition, 2010). Calibrated estimates, ranges and the value of information.
- Philip E. Tetlock and Dan Gardner, *Superforecasting* (2015). The practice of forecasting with explicit probabilities and tracking accuracy.
- Daniel Kahneman, *Thinking, Fast and Slow* (2011). Includes the outside view and the planning fallacy, which bear on reference-class estimates.
