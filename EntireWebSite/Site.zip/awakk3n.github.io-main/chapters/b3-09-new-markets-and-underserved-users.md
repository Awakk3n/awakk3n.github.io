---
id: C09
title: New Markets and Underserved Users
tier: 1
competencies: [product-sense, discovery, strategy-gtm]
prerequisites: [C06, C07]
defines_terms: [localization, underserved-user, trust-signal]
uses_terms: [survivorship-bias, tradeoff, second-order-effect, inversion, first-principles-reasoning, mece, hypothesis, estimation, sanity-check, order-of-magnitude, metric, north-star-metric, guardrail-metric, counter-metric, funnel, activation, retention, churn, cohort, proxy-metric, user-segment, problem-statement, jobs-to-be-done, pain-point, say-do-gap, product-sense, legacy-user, cannibalization, assumption, mvp, unit-economics, platform, latency, api]
frameworks: [FW-C09-01, FW-C09-02, FW-C09-03, FW-C09-04, FW-C09-05, FW-C09-06, FW-C09-07]
case_studies: [CS-C09-01 (Illustrative), CS-C09-02 (Verified)]
cross_refs_out: [C02, C04, C05, C06, C07, C08, C10, C12, C14, C15, C17, C18, C19, C20, C21, C24, C27, C31, C33, C34]
cross_refs_pending: []
status: draft
---

# C09 — New Markets and Underserved Users

## 1. What interviewers test

"How would you launch this product in a country where it does not exist yet?" and "Design something for people whom current products do not serve" are product-sense questions with a twist. The product or the person is unfamiliar, and the interviewer wants to see whether you assume the world looks like your own. A candidate who copies a home-market product and translates it fails the question, however polished the rest of the answer is.

**Where it shows up.** `Inferred` from the round structures candidates commonly report: new-market and underserved-user prompts appear in product-sense rounds at Google, Meta, Microsoft, Amazon, Apple, Stripe and others, often as a variant of a design or improvement prompt (for example, "design for users with limited connectivity" or "launch a wallet where cards are uncommon") `[unverified: candidate-reported]`. Several of these companies serve people in many countries and with many abilities, which probably explains why the question recurs `Inferred`. On the job it is the work of a PM asked to take a product to a new country or to a group the product was not built for.

**What is scored.** The same five things as a design round (structure, user choice, problem choice, solutions, a decision with a measure), plus three that belong to this question `Inferred`: whether you identified what is different about the market and what you do not know, whether you found the binding constraint and designed to it, and whether you handled distribution, economics and responsibility, not only the interface.

Six observable behaviors:

1. You state what changes between the home market and the new one, across users, infrastructure, regulation, competition, distribution and price, and mark what you are assuming.
2. You find evidence without an existing market, using proxies, workarounds and fieldwork, and say how you would avoid the biases specific to research across cultures.
3. You name the binding constraint (connectivity, devices, payments, trust, literacy, shared use) and design for it first.
4. You decide what to keep, adapt or rethink, and you go beyond translation.
5. You show how users will find and trust the product and whether the economics work at low revenue per user.
6. You design inclusively, name who could be harmed or left out, and set limits on what you would not do.

**The failure this prevents.** Six patterns end new-market answers: treating "emerging markets" as one uniform place, copying the home product and translating it, stereotyping the users as poor or unsophisticated, ignoring payments and trust, ignoring regulation and distribution, and an answer with no sense of whether it can earn its keep.

## 2. The concept from first principles

### C09.1 What changes in a new market

A product is a bet that a set of conditions holds: people have a certain kind of device and connection, can pay a certain way, trust certain signals, and are free to use it under the law. A new market changes those conditions, and every one of them can break the product. FW-C09-02 organizes the changes into six dimensions.

| Dimension | The question | Why it can break a product |
|---|---|---|
| Users | Who are they, what do they do today, and what languages and abilities do they bring? | A job done differently (or not at all) changes the product's reason to exist |
| Infrastructure | What devices, connectivity, power and identity systems are common? | The product may not run, or may cost the user more than it is worth |
| Regulation | What does the law require, forbid or license? | A feature may be illegal, or require a local entity, local data storage or a license |
| Competition | Who already serves this need, including informal and non-digital options? | The real rival may be cash, a shopkeeper or a free local app |
| Distribution | How will people find the product and trust it? | Channels that work at home (app stores, paid ads) may reach few people |
| Price | What can people pay, how, and how often? | A price or payment method that fits at home may be out of reach or unusable |

**Markets are not uniform.** The most common mistake is to treat a country, or worse a group of countries, as one market. A large country contains cities with high-end phones and fast connections and regions with neither; it contains several languages and many income levels. Segment inside the market first (C06 and C07), then ask how the constraints differ by segment.

**Unknowns are part of the answer.** You will not know the details of every market. Say what you assume, mark what you would verify, and give the interviewer a chance to correct you. That is judgment, not weakness, and it is how you avoid presenting a stereotype as a fact.

**When not to use the new-market spine.** If the new market is close to the home one (shared language, similar rules, similar infrastructure), the work is closer to improving an existing product (C08), with a localization checklist. If the question is about a specific group inside the home market (people with a disability, people with low incomes), use the user steps of C07 together with the underserved-user check in C09.6. If the question is whether to enter at all, you are in strategy (C18).

> **Counterexample.** Asked to launch a food-delivery app in a large Southeast Asian city, a candidate says, "I'd use the same app, translate it, offer the same promotions, and partner with restaurants." The interviewer asks how the app finds a customer's address, how customers pay and who delivers. The candidate has not considered that in some cities addresses are given by landmarks and not street numbers, that cash on delivery may be the norm, and that couriers may ride motorbikes and carry their own data plans. Each is a design decision. The candidate's plan is the home product with a new language, and the first constraint (finding the customer) would break the core flow on day one.

**Hidden risks.** Two. First, stereotyping: assuming that people in a new market are poor, unsophisticated or uniformly price-sensitive. Many are none of these, and a design for an imagined user serves no one. Second, claiming knowledge you do not have: "most people there use feature phones" is a statement of fact that may be wrong or out of date. Say "I'd expect" and "I'd verify", and use public sources.

> **Regional Lens: India.** India is the worked regional case in this chapter. It is a very large and varied market: many languages and scripts, large differences between cities and villages in devices and connectivity, and a payments landscape built around interoperable account-to-account transfers more than cards `Inferred` `[V: UPI volume in the merchant-fee FAQs of 15 September 2026, as reproduced by FinTech BizNews]`. The practical consequence for an answer is to choose a segment (for example, urban small merchants or first-time smartphone users in smaller towns) before making any claim about "Indian users." The boxes that follow add regional facts where the context genuinely differs; they do not replace the global method.

### C09.2 Discovery without an existing market

You cannot interview users of a product that does not exist, and your own intuition about a place you do not live in is the least reliable guide. C06 gives the research methods; here the problem is how to apply them when you are an outsider and the product is new. FW-C09-04 sets out the approach.

**Start from what people do today.** Every need already has a workaround: informal savings groups, a bus driver carrying cash, a shopkeeper keeping a tab, a relative who sets up the phone. The workaround is evidence of the need and shows what the product must beat. Ask about the last time someone did the task (C06's habit), and watch it if you can.

**Use proxies.** An adjacent behavior can stand in for the one you cannot yet observe: how people top up their phones tells you about small payments; how they send money tells you about trust and distance; which apps they already keep tells you about storage and data limits.

**Go to the place, with local people.** Field visits and shadowing show the constraints that survey answers never mention: a shared phone, a weak signal at the usual place of use, a shop where the product would have to be sold. Local researchers and partners are not an optional extra. They know the language and the norms, they catch questions that mean something different from what you intended, and they are trusted by the people you want to hear from.

**Test cheaply in one place.** A concierge test (a person performs the service by hand), a fake door (a page for a feature that does not exist, to measure interest) or a pilot in a single city gives behavior to read, in the spirit of the riskiest-assumption test in C06 (FW-C06-07).

**Know the biases that are stronger across cultures.** Politeness can hide a "no": people may say what they think the visitor wants to hear (the [[say-do-gap]] widens). A foreign interviewer, or one visibly higher in status, changes the answers. Phone surveys miss people without phones or with a shared one. Translated questions can shift meaning. Counter them by using local interviewers, asking about behavior, observing, and sampling from places and channels that include the people you are most likely to miss.

> **Counterexample.** A team plans a savings product for a new market and runs an online survey in the capital. Ninety percent of respondents say they would use it. The survey reached only people with smartphones and fast connections, in one city, in one language, and asked a hypothetical question. The result describes the people who were easy to reach. A day spent with market traders, asking about the last time they set money aside and what they did, would have taught the team more.

**Why it works.** Behavior and workarounds are harder to fake than opinions, and local partners reduce the translation loss.

**When not to do it at length.** In an interview you cannot run research; say which of these you would do and what you would hope to learn, in two or three sentences, and spend the rest of the time on the design.

### C09.3 Localization beyond translation

**Localization** is adapting a product to a market's language, norms, infrastructure and rules, so that it works and feels right there. Translation is only the first layer. FW-C09-05 gives a ladder of three levels.

| Level | What changes | Example |
|---|---|---|
| Translate | The words | Interface text in the local language |
| Adapt | Formats, content and flows | Date and number formats, names and addresses, local payment methods, local examples, support in the local language |
| Rethink | The product's model | A different way to find customers, to pay, or to establish trust, because the home model does not fit |

Work down the layers: language and script (including right-to-left scripts, several scripts in one country, and mixed-language typing); content and examples; names, addresses and phone numbers; payments; trust signals; units, dates and numbers; legal and policy requirements; support channels; and local calendar events that shape demand.

> **Regional Lens: India.** India recognizes many languages and scripts. The Constitution lists 22 scheduled languages, and a product aimed beyond the largest cities usually needs more than one `Public` `[V: Constitution of India, Eighth Schedule: 22 languages (Sindhi added 1967; Konkani, Manipuri, Nepali 1992; Bodo, Dogri, Maithili, Santhali by the 92nd Amendment, 2003)]`. Numbers in India are commonly written with lakh (100,000) and crore (10,000,000) groupings, as in the UPI figures cited by government sources, so a display that shows only millions and billions can look foreign `Public` `[V: merchant-fee FAQs of 15 September 2026, which state volumes in crore and lakh crore]`. People often use phone numbers as the main identifier for accounts and payments `Inferred` `[unverified: author's synthesis; no source checked]`. These are adapt-level changes; the rethink-level question is how a customer finds, trusts and pays for the product.

**A trust signal** is a visible cue that tells a person a product, a person or a payment is legitimate and safe, and the lack of one can stop a transaction. Trust signals differ by market: a known local brand, a physical shop, an agent the person already knows, a receipt in the local language, a recognized payment method, a visible way to reach a human. In markets where fraud is common or digital services are new, a trust signal can matter more than any feature, and when you rethink a product, the question "what will make a stranger trust this?" often decides the design.

**Why it works.** The ladder stops localization from being a translation task, and it gives you a way to say what you would keep, change or rebuild.

**When not to climb the whole ladder.** If the interviewer asks for a first launch with limited time, translate and adapt the critical path (sign-up, payment, support) and defer the rest, saying so.

### C09.4 Constraints: connectivity, devices, payments, trust, literacy

Six constraints do most of the damage in a new market, and one of them is usually binding: if it is not met, nothing else matters. FW-C09-03 is the stack. Ask, for each, whether it applies, and design for the tightest one first.

| Constraint | Question | Typical design response |
|---|---|---|
| Connectivity | Is data expensive, slow or intermittent? | Work offline; queue actions and sync later; small downloads; a low-data mode; show data use |
| Devices | What memory, storage, screen and operating-system versions are common? | A small app; support older versions; avoid heavy background work; test on typical hardware, not on flagship phones |
| Payments | How do people pay, and who can they pay? | Support the dominant local method first; cash-in and cash-out routes; low-value payments; clear receipts |
| Trust | Why would a stranger give this product money or data? | Trust signals; local partners; human support; visible refunds and dispute routes |
| Literacy | What are the levels of text and digital literacy, and the spoken languages? | Voice, icons and video; short flows; help from an agent or a relative; local-language audio |
| Shared use | Do several people share one device or account? | Profiles and privacy on a shared phone; no assumption that a phone number is one person |

> **Regional Lens: India.** On payments, interoperable account-to-account transfers are central. The Unified Payments Interface (UPI), developed by the National Payments Corporation of India under the Reserve Bank of India's oversight and piloted in April 2016, lets people pay from a bank account through many different apps `Public` `[V: NPCI UPI product overview; pilot launched 11 April 2016 with 21 banks]`. The merchant-fee FAQs report about 24.5 billion transactions worth ₹29.9 lakh crore in August 2026 `Public` `[V: merchant-fee FAQs of 15 September 2026, as reproduced by FinTech BizNews]`. The consequence for a new wallet or checkout is that the rival is free and interoperable, not a card, so the product needs a reason to exist beyond "paying without cards." Pricing is shaped by policy too. Merchant payments from bank accounts through UPI have carried no merchant fee since January 2020. On 15 September 2026 a merchant discount rate was announced, effective 15 October 2026: 0.4% on person-to-merchant payments above ₹2,000, capped at ₹300 for payments of ₹75,000 and above, with a flat ₹5 for categories such as railways, telecom, insurance, fuel and utilities, and a separate 0.02% (capped at ₹300) for capital-market payments such as mutual funds and securities. Consumers, person-to-person transfers, payments up to ₹2,000 and small merchants in the micro-merchant category stay free, and payment apps may not charge a platform fee; accounts differ on whether the Ministry of Finance or the UPI and Services Steering Committee headed by NPCI announced the framework, and a Department of Financial Services notification of 14 September 2026 keeps UPI payments up to ₹2,000 free of charge `Public` `[V: MDR FAQs dated 15 September 2026, as reproduced by FinTech BizNews; Department of Financial Services notification of 14 September 2026, as reported by Inc42 and Moneylife; UNI explainer of 10 August 2026 for the January 2020 zero fee]`. A business that depended on a fee per payment would have been exposed to that policy. On regulation, the Reserve Bank of India's directive of 6 April 2018 requires payment-system data to be stored in India (processing abroad is allowed if the data is deleted abroad and stored in India) `Public` `[V: RBI FAQ on the directive, 2019]`, and the Digital Personal Data Protection Act of 2023 sets general rules for personal data, with rules notified on 13 November 2025, with the Data Protection Board provisions effective at once, consent-manager provisions from 13 November 2026 and the main obligations from 13 May 2027 `Public` `[V: law-firm summaries of the DPDP Rules]`. These shape architecture and vendor choices, and a PM should know to ask about them early. On devices and connectivity, mid-range and low-end Android phones and variable connections are common outside the largest cities `Inferred` `[unverified: author's synthesis; no source checked]`.

> **Other regions, briefly.** In Kenya, a mobile-money service run on a telecom operator's network and a network of cash agents became a widely used way to move money (the subject of CS-C09-02). In Brazil, the central bank launched an instant-payment system called Pix in November 2020 `Public` `[V: Banco Central do Brasil launched Pix on 16 November 2020 (Brazilian press at launch)]`. The pattern is the same: the local payment rail, and who runs it, decides what a product can do. Check what the dominant rail is before designing a wallet.

**Why it works.** Naming the binding constraint turns "a new market" from a vague difficulty into a design problem with a first move.

**When not to dwell.** Name the one or two constraints that bind; listing all six is the recitation the interviewer will discount.

### C09.5 Distribution and unit economics at low revenue per user

**Distribution** is how people find a product and trust it enough to try. At home you may rely on app stores, search and paid advertising. In a new market those may reach few people, or cost more than a user is worth. Other routes: partnerships with mobile carriers (bundles and pre-installation), retail shops and agents (people who sign others up, as in the Kenyan case), employers and institutions, community organizations, and word of mouth. Choose the route by who it reaches, how it builds trust, and what it costs per user.

**Unit economics** compares what a user earns with what the user costs, per user. [[unit-economics]] is covered with strategy in C18; the short form you need here is FW-C09-06: revenue per user per month, minus the cost to serve (data, support, payment fees), gives a monthly margin; divide the cost to acquire a user by the margin for the payback period; and the expected lifetime (one over monthly [[churn]]) times the margin gives the margin earned over a user's life.

Take an invented case. A savings app earns $0.50 per active user per month (invented) and costs $0.20 a month to serve (invented), so the margin is $0.30. Monthly churn is 10%, so the expected lifetime is 10 months and the lifetime margin is $3.00. Acquiring a user through paid advertising costs $2.50: payback in 8.3 months, and a ratio of lifetime margin to cost of 1.2, thin. Acquiring a user through a partner network costs $1.00: payback in 3.3 months, and a ratio of 3.0. If churn rises to 15%, the lifetime is 6.7 months, the lifetime margin is $2.00, and the advertising route loses money (a ratio of 0.8) while the partner route still returns twice its cost.

Three lessons. At low revenue per user, the cost of acquiring and serving a user decides whether the business works, so distribution is part of the product. Support and payment fees often cost more than the cloud. And [[churn]] is the number most likely to turn a plan from profitable to unprofitable.

**Why it works.** A rough economic sketch shows you know that a market is attractive only if the product can pay for itself.

**When not to build the full model.** Give revenue, cost to serve and cost to acquire in a sentence each and name the one that dominates.

### C09.6 Designing for underserved users: accessibility, inclusion, ethical limits

An **underserved user** is a person or group that existing products fail because of cost, access, ability or context, described by what the product lacks for them and not by who they are. "Farmers with feature phones" is a description by access; "poor farmers" is a label. The distinction matters because the first leads to a design (voice, SMS, an agent) and the second leads to charity or condescension.

**Inclusion.** Ask who cannot use the product as designed: people with low vision or blindness, deafness, limited mobility or cognitive differences; people who read little or read another script; people who cannot afford a device of their own. Design the main path for them, not an add-on (C07's curb-cut effect). Test with the people themselves.

**Dignity.** Do not design for "the poor" in a way that signals pity, and do not assume that low income means low sophistication. People who run informal businesses and manage irregular money are often skilled financial managers; they lack tools that fit.

**Safety and exploitation.** Underserved users are often targets for harm: scams, predatory credit, data taken without understanding, and harassment (particularly for women using shared or monitored phones). Ask who could profit from this product at the user's expense, including the company itself. A loan with fees that trap people in debt is not an inclusion product, and a growth plan that depends on it is not a plan.

**Consent and comprehension.** Terms in a language and form the person understands, a clear price before commitment, and a way to say no and to leave.

**Limits.** State what you would not do. "I would not launch short-term credit with fees above a threshold that traps borrowers, even if it grows fastest." A stated limit is a sign of judgment, and it answers the follow-up "what would you not build?"

**Why it works.** Inclusion widens the market, and the ethical limits protect the people the product serves and the company's license to operate.

**When not to dwell.** Make two or three specific points about the group in question and move on; a moral lecture is not a design.

### C09.7 Answer architecture

Section 4 sets out the new-market spine with a time budget: clarify, read the market, choose the segment, find the binding constraint, shape the product, distribution and economics, metrics and risks. It reuses the pieces from C07 and C08 and adds the six-dimension scan, the constraint stack and the economic sketch.

### C09.8 Worked examples

Section 5 gives four worked answers: merchant payments in India, a ride-hailing launch where addresses and payment differ, a health-information service for people with feature phones, and a distribution and economics choice for a savings app. Section 11 adds seven questions with model answers, including an Apple wallet question, a Google question on low-connectivity video and a Stripe question on small-merchant payments.

## 3. Frameworks

Seven frameworks, set out below. The spine (FW-C07-01), the segment scorecard (FW-C06-02), the riskiest-assumption test (FW-C06-07), the responsible-design check (FW-C07-06), the surface lens (FW-C07-07) and the success-metric template (FW-C05-06) are reused, not repeated.

#### FW-C09-01 · The new-market answer spine · Original

- **Inputs:** a prompt about a market or user group the product does not yet serve, and 35 to 45 minutes.
- **Outputs:** an answer with eight visible steps: clarify, market, segment, constraint, shape, distribution and economics, metrics, risks.
- **Assumptions:** the interviewer will answer clarifying questions and will correct a wrong assumption.
- **Tradeoffs:** structure makes the reasoning scorable and can crowd out the one insight that matters; the budget is a guide.
- **Failure modes:** copying the home product; reciting the six dimensions equally; no decision; stereotyping.
- **Worked example:** the ride-hailing launch in Worked example 2, and the model answers in section 11.

Steps: **Clarify → Market → Segment → Constraint → Shape → Distribute and earn → Measure → Risks.** The time budget is in section 4.

#### FW-C09-02 · The market-difference scan · Original

- **Inputs:** the product, the home market where it works, and the target market.
- **Outputs:** a six-row table (users, infrastructure, regulation, competition, distribution, price), each with what you assume, how it differs from home, and what you would verify, with the one or two differences that matter most marked.
- **Assumptions:** you can reason about the target market from public information and from the interviewer's answers.
- **Tradeoffs:** a scan forces coverage and can become a list; marking the two that matter is the point.
- **Failure modes:** treating the market as uniform; presenting assumptions as facts; scanning all six at equal length.
- **Worked example:** the scan in Worked example 1 for merchant payments.

| Dimension | Assumption (labeled) | Difference from home | Verify | Matters most? |
|---|---|---|---|---|
| Users | | | | |
| Infrastructure | | | | |
| Regulation | | | | |
| Competition | | | | |
| Distribution | | | | |
| Price | | | | |

#### FW-C09-03 · The constraint stack · Original

- **Inputs:** the product's core flow and the target segment.
- **Outputs:** an answer for each of six constraints (connectivity, devices, payments, trust, literacy, shared use), the binding one marked, and a design response to it first.
- **Assumptions:** the core flow can be traced step by step to see where each constraint bites.
- **Tradeoffs:** designing for the tightest constraint can lower the experience for people who have none; offer a richer path where it is available.
- **Failure modes:** listing constraints without a design response; missing the binding one; designing for the worst case and imposing it on everyone.
- **Worked example:** the health-information service in Worked example 3, where devices, literacy and shared use bind.

Method: trace the flow (find, sign up, use, pay, get help) and mark at each step which constraint stops it. The one that stops the most steps is binding.

#### FW-C09-04 · The discovery-without-a-market plan · Original

- **Inputs:** a need in a market you do not know, and limited time and money.
- **Outputs:** a short plan with five parts: today's workarounds to study, proxies to use, fieldwork with local partners, a cheap behavioral test in one place, and the biases to correct.
- **Assumptions:** local partners and respondents are reachable.
- **Tradeoffs:** fieldwork is slow and costly, and it replaces guesses with observation.
- **Failure modes:** an online survey from the capital; foreign interviewers only; hypothetical questions; sampling the easy-to-reach.
- **Worked example:** the plan in IQ-C09-02, and the Kenyan pilot in CS-C09-02.

| Part | Question | Example |
|---|---|---|
| Workarounds | What do people do today? | Informal savings group; asking a shopkeeper to hold money |
| Proxies | What adjacent behavior can I observe? | How people top up their phones; how they send money home |
| Fieldwork | What do I see in the place, with local people? | A shared phone; a weak signal at the usual place of use |
| Cheap test | What can I test in one place in two weeks? | A concierge service for twenty traders |
| Bias fix | Which bias is strongest here? | Politeness; sample that excludes people without phones |

#### FW-C09-05 · The localization ladder · Original

- **Inputs:** a product that works in the home market.
- **Outputs:** a sorted list of changes at three levels (translate, adapt, rethink) across the layers (language, content, flows, payments, trust, formats, legal, support), with a launch scope.
- **Assumptions:** you can list the layers of the product that depend on the home market.
- **Tradeoffs:** deeper localization raises cost and delays launch; shallow localization can break trust.
- **Failure modes:** stopping at translation; rethinking everything; ignoring legal changes.
- **Worked example:** the ladder for ride-hailing in Worked example 2.

Rule: translate everything on the critical path, adapt what the user must do to pay and be paid, and rethink only where the home model fails the binding constraint.

#### FW-C09-06 · The low-revenue unit-economics sketch · Original

- **Inputs:** a revenue per user, costs to serve, a cost to acquire by channel and a churn assumption.
- **Outputs:** monthly margin, payback period, expected lifetime and lifetime margin per channel, with the swing assumption named.
- **Assumptions:** order-of-magnitude values are enough to compare channels (C04).
- **Tradeoffs:** a quick sketch guides the choice of channel and can hide cohort differences; check with a pilot.
- **Failure modes:** ignoring churn; counting gross revenue as margin; assuming home-market acquisition costs.
- **Worked example:** the savings-app arithmetic in C09.5 and Worked example 4.

Formulas: **margin = revenue − cost to serve; payback = cost to acquire ÷ margin; lifetime = 1 ÷ monthly churn; lifetime margin = margin × lifetime.** Name the assumption that would flip the decision.

#### FW-C09-07 · The underserved-user design check · Original

- **Inputs:** a design for a group that current products fail.
- **Outputs:** answers to six questions with a design response for each and a stated limit on what you would not build.
- **Assumptions:** you can name how the group is excluded and how it could be harmed.
- **Tradeoffs:** protections reduce friction-free growth; omitting them risks harm and trust.
- **Failure modes:** a moral statement with no design; describing the group by a label; a limit that never binds.
- **Worked example:** the checks for the health-information service in Worked example 3, and the lending limit in IQ-C09-06.

| Check | Question | Typical response |
|---|---|---|
| Access | Who cannot use the main path? | Voice, icons, offline, agent help, accessibility features on the main path |
| Dignity | Does the design label or pity the user? | Describe users by what the product lacks for them; test wording with them |
| Exploitation | Who could profit at the user's expense, including us? | Price transparency; caps on fees; no dark patterns |
| Safety | Could the product put someone at risk (a shared phone, a monitored account)? | Private by default; hidden notifications; a quick exit |
| Consent | Does the person understand and agree? | Plain local-language terms; the price before commitment; a clear way out |
| Limit | What would we not do, even if it grew fastest? | A written limit with a threshold |

## 4. Answer architecture

### The new-market answer, for a 45-minute round

| Step | Minutes | What to produce |
|---|---|---|
| Clarify the market, product and goal | 4 | Two or three questions; the home market and the target named; the goal as an assumption |
| Read the market | 6 | The six-dimension scan with assumptions and what to verify; the one or two differences that matter |
| Choose the segment | 6 | Two to four segments inside the market; one chosen with a criterion; what you give up |
| Find the binding constraint and the problem | 6 | The constraint stack; the binding constraint; a specific pain point and the job |
| Shape the product | 8 | What to keep, adapt and rethink (the ladder); the first version as moments; trust signals |
| Distribution and economics | 7 | Channels with reasons; a unit-economics sketch with the swing assumption |
| Metrics and risks | 5 | Primary metric, an input, a guardrail, a counter metric; regulation, trust and ethical limits |
| Slack for interviewer questions | 3 | |

**Pacing rules.** If the interviewer names the market or the group, move the saved time to the constraint and the shape. If you run behind, give two dimensions of the scan, one constraint, a one-line economic sketch and one limit, but keep the binding constraint and the distribution route. Treat questions as steering and rejoin the spine. If the interviewer asks how big the opportunity is, use the market-sizing approach in C04 (answer Type B), and size the segment you can reach, not the whole population.

**What to clarify first.** The market and which segment of it, whether it is a new product or an existing one, the goal (growth, learning, a strategic position) and any constraint on entry (a local partner, a license). A useful opener: "I'll assume we are taking an existing product to this market and the goal is a sustainable first cohort. I know the market from public information only, so I'll flag what I'm assuming."

**Where to signpost.** After clarifying: "I'll cover what differs in the market, who to serve first, the binding constraint, the product, how people find and trust it, whether it pays for itself, and the risks." Before choosing a segment: "I'll pick by pain and reach." Before shaping the product: "My deciding constraint is X."

**How to close.** Two sentences: "I recommend [shape] for [segment], designed around [binding constraint], reached through [channel], and I'd judge it by [metric]. The main risks are [regulation or trust or harm], which I'd handle with [response], and I'd stop or change course if [condition]."

### Type: launch a known product in a new country

Spend the first half on the scan and the constraint, and say what you would keep and change. State the single largest difference from home first.

### Type: design for an underserved group

Replace the market scan with the underserved-user check (FW-C09-07). Describe the group by what products lack for them, and put access and exploitation early.

### Type: choose among markets

State two or three criteria (size of the segment you can reach, pain, ease of distribution, regulatory burden, fit with the product), score the options roughly and choose one with a reason. If the question becomes strategic, name it and point to C18.

### Type: the short version (20 to 25 minutes)

Keep every step and halve the time: one difference that matters, one constraint, one change at each ladder level, one channel, one metric, one limit.

### Common interviewer interventions, and what to do

| Interviewer says | What it means | What to do |
|---|---|---|
| "What is different about this market?" | You assumed it was like home | Give the one or two differences that matter most and why |
| "How do you know that?" | You stated an assumption as a fact | Say it is an assumption and how you would check it |
| "Who exactly is the user?" | You said "people there" | Name a segment by need and context |
| "How will people find it?" | You skipped distribution | Name a channel, why it builds trust, and its cost per user |
| "Can this make money?" | You skipped economics | Give revenue, cost to serve, cost to acquire, and the swing assumption |
| "What could go wrong?" | They want regulation and harm | Name a legal constraint and a way users could be harmed, with a response |
| "What would you not build?" | They want a limit | State a specific limit and the threshold |

## 5. Worked examples

All four examples are `Illustrative`. Where a real company or country is the setting (examples 1 and 4 use India, example 1 a payments company of the kind Stripe is), nothing here is a claim about that company's actual metrics, roadmap or decisions, and every figure is an invented assumption. Facts about the market and its rules are public and carry verify marks. Each answer follows the spine in FW-C09-01 and is written as notes you could say aloud.

### Worked example 1 — Payments: helping small online merchants in India accept payments (Illustrative)

*Setting: a developer-focused payments company of the kind Stripe is. No fact about any real company is claimed.*

**The prompt.** "A payments company wants to help small online merchants in India accept payments. How would you approach it?"

**Clarify and goal.** I'd ask whether the company already serves developers in other countries (assume yes), whether it holds the licenses it needs in India (assume it must get them), and what the goal is. Assume a sustainable first cohort of merchants who take payments reliably. I know India's market from public information only, so I'll mark assumptions.

**Scan (FW-C09-02).**

| Dimension | Assumption (labeled) | Difference from home | Verify | Matters most? |
|---|---|---|---|---|
| Users | Small sellers who sell through chat apps and social media, not websites; many are not developers | At home the user is a developer integrating an API | Interview ten sellers | Yes |
| Infrastructure | Buyers pay from a phone; interoperable account-to-account transfers are widely used; connections vary | At home, cards dominate checkout | The share of payments by method | Yes |
| Regulation | Payment data stored in India; payment intermediaries need authorization; sellers must be verified | A local entity and license come first | Current Reserve Bank of India rules `[as of 2026-10]` | Yes |
| Competition | Free interoperable payment apps, local gateways, cash on delivery and plain QR codes | The rival is often "a QR code and a screenshot" | Competitor offers | Medium |
| Distribution | Through marketplaces, banks, accountants and small-business tools more than developer documentation | At home, developers find the product themselves | Partner interest | Medium |
| Price | Small order values; a merchant fee on bank-account payments is not available by policy (zero since 2020; from 15 October 2026 a 0.4% merchant discount rate, capped at 300 rupees, applies to merchant payments above 2,000 rupees) `[V: merchant-fee FAQs of 15 September 2026, as reproduced by FinTech BizNews]` | At home, a percentage fee per payment is the main revenue | Current fee policy | Yes |

I mark three differences as decisive: the payment method, regulation and the revenue model.

**Segment.** By need: developers building stores (our home strength); sellers who take orders by chat and confirm payment by looking at a screenshot of a transfer; established online stores. I choose chat-based sellers. Their pain is daily and costly (confirming payments by hand, matching them to orders, fake screenshots), the segment is large, and they cannot use a developer product at all. I give up the developers and the established stores, where we have the edge and the lower risk, and I'd serve developers later with the same underlying platform.

**Constraint (FW-C09-03).** The binding constraint is payments: a card-only checkout fails the buyer. A second is trust: a buyer must believe a new payment page is the seller's and is safe, so the page shows the seller's name and opens the buyer's own payment app. Connectivity matters at the moment of payment, since a call can drop between "paid" and "confirmed," so the system must handle a pending state and confirm afterward without double charging.

**Shape (FW-C09-05).** *Keep:* the payments platform, the dashboard, notifications by webhook, the refund model. *Adapt:* the local bank-transfer method as a first-class option (a QR, a link that opens the buyer's payment app, a request sent to the buyer), the dashboard in local languages, settlement timing in local business days, invoices in the local format. *Rethink:* the product is not an API a developer integrates but a payment link a seller creates and shares in a chat, with automatic matching of each payment to the order, replacing the screenshot. Onboarding is by phone number with local verification of the seller.

First version as moments: (1) A seller signs up with a phone number and verifies her identity. (2) She creates a link for an order of ₹1,200 (invented) and shares it in a chat. (3) The buyer taps it, sees her shop name and pays in his usual payment app. (4) She sees "paid" with the order reference within seconds. (5) Money reaches her bank account the next business day. (6) A refund takes one tap.

**Distribution and economics (FW-C09-06).** Revenue cannot rest on a fee per bank-transfer payment, so I'd charge for the software: a monthly subscription for reconciliation, invoices and reports, ₹299 a month (invented), with card fees on the minority of card payments. Cost to serve: ₹120 a month (invented), mostly support in the local language and verification. Margin: ₹179. Monthly churn of sellers 4% (invented) gives a lifetime of 25 months and a lifetime margin of ₹4,475. Acquiring a seller through a partner (a small-business tool or a bank offering) costs ₹600 (invented): payback in 3.4 months, a ratio of 7.5. Through paid advertising it costs ₹1,800 (invented): payback in 10.1 months, a ratio of 2.5. The riskiest assumption is that sellers will pay ₹299, so the first test is a concierge version for twenty sellers who are charged from the start.

**Metrics.** Primary: the share of created payment links that are paid within 24 hours. Input: time from sign-up to first paid link. Guardrails: payment failure rate, settlement delay, and fraud and dispute rate. Counter metric: the share of sellers who go back to screenshots after a month, which would show that the matching is not trusted.

**Risks and limits.** Regulation could delay launch, so licensing and data storage start first. Merchant verification must not exclude honest sellers who lack formal documents, so I'd define a tiered process with lower limits at first. I would not launch before refunds and disputes work, since an unreliable payment product loses trust faster than any other. I'd change course if interviews showed that sellers would not leave their chat and use a link.

### Worked example 2 — Marketplace: launching ride-hailing where addresses and payment differ (Illustrative)

**The prompt.** "A ride-hailing company is entering a city of five million people. Many addresses are described by landmarks, and most riders pay in cash. How would you launch?"

**Clarify and goal.** The company runs ride-hailing in other cities, and the city has five million people (invented). Goal: a reliable service in one part of the city that can grow, which means supply (drivers) and demand (riders) together. It is a marketplace, so the first question is which side to win first.

**Scan.** The differences that matter: *infrastructure* (addresses by landmark; mid-range phones and variable connections), *payments* (cash), *competition* (informal taxis and motorbike taxis that riders already use and bargain with), *regulation* (licensing of drivers and vehicles, which I'd verify before anything else), *distribution* (drivers are reached in person, riders by referral and workplaces).

**Segment.** By need and behavior: office commuters who now bargain for informal taxis; late-evening riders who care most about safety; visitors. I choose commuters with a regular route: they ride often, the pain is repeated (haggling over fare, uncertainty about the driver), and a regular route lets us concentrate supply. I give up late-evening riders at launch only because safety needs its own design, which I'd put in the first version as a feature for everyone and not as a segment.

**Pain points.** (1) The rider and driver cannot find each other, because a map pin is imprecise and the landmark is described differently by each. (2) The fare is uncertain, with bargaining at pickup. (3) The rider is unsure whether the driver is who he says he is. (4) The driver has no change for a large note. I choose (1) and (2) as the first problems, since without a successful pickup and an agreed fare there is no trip, and treat (3) as a launch requirement.

**The ladder (FW-C09-05).**

| Level | Change |
|---|---|
| Translate | Rider and driver apps in the local language; support by voice |
| Adapt | Pickup by pin plus a typed landmark ("opposite the bakery on the main road") and a one-tap call between rider and driver; fare shown in local formats; a lighter driver app for mid-range phones and weak signals |
| Rethink | A fare shown upfront so there is nothing to bargain over; cash as a first-class payment method, with a driver wallet where the platform's commission is deducted from a prepaid balance; driver onboarding in person at a hub, which verifies documents and builds trust |

**Distribution and economics.** Supply first: hubs near the commuter routes, where drivers sign up, receive a verified badge and get help with the app. Demand follows through referral codes at offices. Economics hinge on cash: commission is owed to the platform, but the driver holds the money, so the wallet model needs a minimum balance. Without it, the platform carries the risk that drivers hold unpaid commissions. A quick sketch: an average fare of 150 (local currency, invented), commission 15%: 22.50 a trip; cost to serve (payment handling, support, insurance) 8: margin 14.50 a trip. With 40 trips a month per active rider (invented, a commuter), that is 580 a rider a month; the sketch shows a healthy unit if the commuter segment holds, and thin if pickups fail, since each failed pickup costs support time and a cancelled trip.

**First version as moments.** The rider enters a pickup with a pin and a landmark; the app shows the fare upfront; the driver accepts; the driver's app shows the landmark text and the rider's photo; they can call with one tap if they cannot find each other; the rider pays cash; the commission is deducted from the driver's wallet; both rate the trip.

**Metrics.** Primary: completed trips per 100 requests. Input: the share of trips where rider and driver meet within 10 minutes of the driver's arrival estimate. Guardrails: safety incidents per 10,000 trips, and driver earnings per hour compared with the alternative they have today. Counter metrics: the share of trips with a call between rider and driver (a sign the address system is failing), and the cancellation rate after acceptance.

**Risks and limits.** Regulation: I'd not operate before understanding license rules. Safety: a trip-sharing link with a family member and a driver verification flow are in the first version, and I'd not launch without them. Cash risk: a minimum wallet balance for drivers. I'd change course if pickup success stayed low after landmark entry, in which case the product needs a different way to locate people (for example, a human-readable pickup point list).

### Worked example 3 — Underserved users: a health-information service for people with basic phones (Illustrative)

**The prompt.** "Design a health-information service for people in rural areas who have basic phones."

**Clarify and goal.** I'd ask which country, whether a health authority or community organization is a partner (assume a partnership with a public health service and its community health workers), and what the goal is. Assume it is that people get the right care at the right time. I'd describe the users by access and not by label: adults in a rural district who use a basic phone without internet, often shared with family, and who live a long way from a clinic.

**Constraint stack (FW-C09-03).**

| Constraint | Answer here |
|---|---|
| Connectivity | Voice and text work; mobile data may not |
| Devices | Basic phones: no apps; voice calls, text messages and menu codes only |
| Payments | The service must be free or very low cost to the user |
| Trust | Health advice from a stranger is risky; a known clinic or a health worker is a trust signal |
| Literacy | Voice in local languages matters; text may be difficult |
| Shared use | A phone shared by a family: health queries and reminders are private |

Devices, literacy and shared use bind, so the design is a voice line plus text reminders, with no app.

**Pain points.** (1) People do not know when a symptom needs a clinic visit, and travel is costly, so they delay or go unnecessarily. (2) Scheduled care is missed: vaccinations, antenatal visits. (3) Rumors circulate by word of mouth. I choose (1) and (2): they have the greatest effect on health, and a reminder or a clear rule of thumb helps.

**Solutions that differ in kind.** *Assist:* a toll-free voice line with a menu in local languages that gives clinician-approved guidance on when to go to a clinic. *Automate:* text or voice reminders for appointments, enrolled by a community health worker. *Connect:* the voice line passes the caller to a nurse for a serious concern. *Reframe:* a community health worker uses the service as a tool during visits, so the worker, whom people already trust, is the primary user. *Eliminate:* mobile clinics, which are an operator's choice and outside what a product can do. I recommend the voice line with reminders, introduced by the community health worker.

**First version as moments.** A health worker enrolls a family and records their preferred language and appointment dates. A reminder call comes the day before. A caller dials the line, chooses a language, selects a topic, hears a short answer and the rule for when to go to a clinic, and can ask to be passed to a nurse. Reminders use neutral wording and codes ("your appointment is tomorrow"), not the name of a condition, because the phone is shared.

**Distribution and economics.** The channel is the health-worker network and clinics, which supply trust. The user pays nothing, so the funder (the health service or a charity) pays per enrolled family. A rough sketch: call and message costs of 0.30 a family a month (invented) plus the cost of nurse time for escalations, which I'd estimate by the share of calls passed on (assume 5%, invented).

**Metrics.** Primary: the share of scheduled appointments kept among enrolled families compared with similar families not yet enrolled (a staggered rollout gives the comparison). Input: the share of enrolled families who answer reminder calls. Guardrails: the share of advice that a clinician audit finds incorrect, which must be near zero, and the number of harm reports. Counter metric: the share of callers who hang up at the first menu, which shows whether the menu is usable.

**The check (FW-C09-07).** *Access:* voice and local languages are the main path. *Dignity:* the service is described as a way to reach a clinic when it is needed. *Exploitation:* no advertising, no sale of data, no paid tiers aimed at callers. *Safety:* neutral wording on a shared phone; a woman can ask to be called at a time of her choosing. *Consent:* the health worker explains the service in the local language and the family agrees before enrollment. *Limit:* the service never diagnoses, and any symptom that could be an emergency is directed to the emergency route first, whatever the menu. I'd change course if the audit found wrong advice, which would pause the line until it was fixed.

### Worked example 4 — Distribution: choosing how a savings app finds its first users in India (Illustrative)

*Setting: a micro-savings app for informal workers in India. No real company is described.*

**The prompt.** "Your savings app is ready to launch in India. How do you acquire the first 100,000 users?"

**Clarify and goal.** Assume users are informal workers (small traders, delivery workers) with irregular income and a smartphone. The goal is a base of active savers at a cost that the business can sustain. I'd say that the constraint is trust: a stranger's app asking for money.

**Channels and economics (FW-C09-06).** Revenue per active user is $0.50 a month (invented), cost to serve $0.20, so margin before the sharing of revenue is $0.30.

| Channel | Cost to acquire | Margin per month | Monthly churn | Lifetime | Lifetime margin | Ratio to cost | Payback |
|---|---|---|---|---|---|---|---|
| Paid advertising | $2.50 | $0.30 | 12% (invented) | 8.3 months | $2.50 | 1.0 | 8.3 months |
| Agent network (agents paid per activated user) | $1.00 | $0.30 | 7% (invented) | 14.3 months | $4.29 | 4.3 | 3.3 months |
| Carrier bundle (carrier keeps 30% of revenue) | $0.50 | $0.15 | 10% (invented) | 10 months | $1.50 | 3.0 | 3.3 months |

The carrier route earns $0.35 after the carrier's 30% share, minus $0.20 to serve, so $0.15 a month. Churn differs by channel because the way a person arrives shapes how long they stay: people who sign up with a trusted local agent are assumed to keep their account longer than people who tapped an advertisement. That assumption is the swing, and I'd test it with a pilot.

**Reading the table.** Advertising breaks even at best: the lifetime margin equals the cost, and a small rise in churn makes it lose money. Agents and the carrier bundle both return three to four times their cost. Agents have the best lifetime, and the carrier gives scale cheaply with a lower margin.

**Recommendation.** "I recommend starting with agents, to build trust and learn why users stay, then adding a carrier bundle for scale, and using advertising only to retarget people who have already visited. The agent route is the slowest to scale, and it is the one where the product's biggest risk (trust) is addressed. I'd switch to the carrier bundle first if the pilot showed that agents were hard to recruit or supervise."

**Risks and limits.** Agent fraud: an agent who signs up fake users to earn a fee. The payment is made only after a user has saved for a week and passed verification. Agent concentration: if one agent brings most users, the agent owns the relationship, so no agent may exceed a share of the base. Carrier dependence: a single carrier can change terms. Ethical limit: no savings product that hides fees or locks money in ways the person does not understand.

**Metrics.** Primary: the number of users who saved in each of their first four weeks, by channel. Input: cost per activated user by channel. Guardrails: complaint rate and the share of agent-recruited accounts that fail verification. Counter metric: the share of accounts that are active only while an incentive lasts, which shows users who came for the offer and not for the product. Regulation: financial products need local authorization, so I'd confirm what the app may offer before launch `[as of 2026-10]`.

## 6. Baseline, Strong, Standout

**Prompt:** "How would you launch a video-streaming service in a country where most people watch on phones and data is expensive?"

### Baseline answer

"I'd translate the interface, license local content, set a lower price, and run marketing campaigns. I'd also make sure the app works on Android."

*What is wrong:* nothing is specific to the market. The answer copies the home product, assumes a low price solves the problem, and says nothing about data cost, payments, distribution or economics. There is no user, constraint, metric or risk.

### Strong answer

"I'll assume the service is established elsewhere and the goal is a first cohort that stays. I'd start by naming what is different: people watch on phones, data is expensive and slow in many places, payment by card is uncommon, and the rival is free video platforms and pirated copies. I'd mark these as assumptions to verify.

"I'd segment by how people watch: heavy mobile viewers in cities, viewers who share one phone in a household, and viewers with a home connection. I choose heavy mobile viewers in cities because they watch the most, they have the best phones and they are easiest to reach, and I'd treat shared phones as the next segment.

"The binding constraint is data cost: if a film consumes a month's data, no one will watch it. So I'd offer downloads over Wi-Fi, low-resolution streaming that shows the data used, and a mobile-only plan. For payment I'd support the dominant local method and prepaid options. I'd distribute through a partnership with a mobile carrier and measure watch hours per subscriber, with data used per hour as a guardrail."

### Standout answer

Everything in the Strong answer, plus:

"The unit economics decide whether this is a business. If revenue per subscriber is low, the content licenses and the cost of delivering video must be small per user, so I'd sketch revenue, cost to serve and cost to acquire before committing. A carrier bundle lowers acquisition cost but gives up part of the revenue, so I'd compare lifetime margin by channel, and I'd test whether subscribers who come through the carrier stay as long as those who sign up on their own.

"I'd also be careful about the word 'cheap.' A lower price attracts people who would pay more, which is cannibalization of my own revenue, so I'd test a mobile-only plan with fewer features instead of a lower price for the same product.

"Trust and payment are linked: a prepaid or carrier-billed plan removes the need to enter a card, which removes a barrier and a fraud risk. And I'd check regulation, since local content and data rules affect what can be shown and stored `[as of 2026-10]`.

"The risk to others is the carrier's network: heavy video on a shared network can raise costs, and the carrier may impose limits on us. I'd stop the bundle if the cost to serve grew faster than revenue. I'd change my plan if research showed that most of the target viewers share phones, in which case profiles and downloads at a shop become the first problem."

### What moves an answer up a band

| From Baseline to Strong | From Strong to Standout |
|---|---|
| Names what differs in the market, as assumptions | Sketches the unit economics and compares channels by lifetime margin |
| Chooses a segment and a binding constraint | Separates a lower price from a different plan, and sees the revenue it could cannibalize |
| Adapts the product to the constraint (downloads, low bitrate, local payment) | Links trust, payment and distribution; states what regulation could change |
| Gives a metric with a guardrail | Names the risk to a partner, a stopping condition and what would change the plan |

## 7. Company lens

All claims describe what companies say publicly or what candidates commonly report, not insider knowledge. Interview formats change `[as of 2026-10]`.

> **Company lens: Google [as of 2026-10].** Google has publicly run programs and products aimed at people with limited connectivity and low-cost phones, often described as serving the next billion users `Public` `[V: Google Next Billion Users initiative; Android Go announced at Google I/O, May 2017, with Google Go, Maps Go and YouTube Go (YouTube Go was retired from August 2022, per YouTube's announcement as reported by 9to5Google, Android Authority and TechRadar)]`. Candidates commonly report prompts about low-bandwidth video, maps or search for users with unreliable connections `Inferred`. Practical consequence: lead with the connectivity and device constraint, and describe offline and low-data behavior concretely. Appendix A has briefs on eight Google products to practice against.

> **Company lens: Amazon [as of 2026-10].** Amazon publishes Customer Obsession as a leadership principle and operates in many countries `Public` `[V: Amazon's Leadership Principles, as cited by several summaries]`. Candidates commonly report launch prompts in which the customer's problem is stated first and logistics and trust are examined closely `Inferred`. Practical consequence: say the customer's problem in the customer's terms, and cover delivery, payment and trust, not only the interface.

> **Company lens: Meta [as of 2026-10].** Meta has described a mission to connect people worldwide `Public` `[V: Meta careers page: build the future of how people connect]`, and its free-data program in India was blocked after the telecom regulator ruled against differential pricing for data services in 2016 `Public` `[V: TRAI regulations of 8 February 2016, as reported by Reuters and the Financial Times]`. Candidates commonly report prompts on low-connectivity users and on how regulation and misuse shape growth `Inferred`. Practical consequence: treat regulation as a design input, and think about harm (misinformation, harassment) as well as reach.

> **Company lens: Microsoft [as of 2026-10].** Microsoft publishes inclusive-design principles `Public` `[V: Microsoft Inclusive Design toolkit manual]`, is described as publishing accessibility commitments (not rechecked here) `Inferred`, and its enterprise products often face local data-residency and licensing rules `Inferred`. Practical consequence: show inclusion as part of the main path, and name the data-storage or licensing requirement that would shape the launch.

> **Company lens: Apple [as of 2026-10].** Apple publishes a privacy position `Public` `[V: Apple privacy pages]`, and is described as supporting many languages and publishing accessibility features (not rechecked here) `Inferred`. Third-party guides report that prompts such as launching a wallet in a market where cards are uncommon test whether you understand local payment rails, privacy and the user's other devices `Inferred`. Practical consequence: find out what the dominant payment rail is before proposing a wallet, and say what stays on the device.

> **Company lens: Netflix [as of 2026-10].** Netflix expanded to a large number of countries at once in 2016 and has offered lower-priced mobile plans in some markets `Public` `[V: Netflix press release of 6 January 2016; Reuters on the 2019 India mobile plan]`. Candidates commonly report prompts on pricing, local content and mobile viewing `Inferred`. Practical consequence: separate a different plan from a lower price, and say how local content and delivery cost fit the economics.

> **Company lens: Stripe [as of 2026-10].** Stripe publishes documentation on supporting many local payment methods `Public` `[V: Stripe docs, Supported payment methods: cards, bank debits, vouchers, wallets and real-time methods such as UPI and Pix; some invite-only]`, and candidates report questions on how to choose which payment methods and compliance work to build first in a new country `Inferred`. Practical consequence: rank payment methods by the share of payments they carry in the target segment, and treat licensing, verification and data storage as part of the product.

## 8. Common mistakes

| # | Mistake | How to detect it | Fix |
|---|---|---|---|
| 1 | Treating a region as one market | You say "users in emerging markets" | Choose a country, a segment and a context |
| 2 | Copying the home product and translating it | Your plan is the same app in a new language | Climb the ladder: adapt the critical path, rethink where the model fails |
| 3 | Stating assumptions as facts | "Most people there use X" | Say "I'd expect," and name how you would check |
| 4 | Stereotyping users as poor or unsophisticated | Your user is "the poor" | Describe by access and context; assume skill |
| 5 | Ignoring payments | The checkout is a card form | Find the dominant local rail and who runs it |
| 6 | Ignoring trust | No trust signal in the flow | Ask what would make a stranger trust this |
| 7 | Skipping regulation | Nothing on licensing or data storage | Name the rule that sets the launch order |
| 8 | No distribution plan | "We'll market it" | Name a channel, why it builds trust and its cost per user |
| 9 | No economics | You never say how it pays for itself | Sketch revenue, cost to serve, cost to acquire and churn |
| 10 | A moral statement in place of a design | "We must help the poor" | State access, exploitation and consent checks with a stated limit |

## 9. Mental models applied

Four models, each tied to a decision in this chapter. [[first-principles-reasoning]] and [[inversion]] come from C02.

**First principles** (`MM-first-principles`, see [[first-principles-reasoning]], C02). When the home market's assumptions do not hold, rebuild from the job: what is the person trying to do, with what means, under what limits? A candidate who says "the job is moving money to relatives, and the means are cash, a shopkeeper and a basic phone" designs better than one who starts from "a wallet." This is the habit that avoids copying.

**Inversion** (`MM-inversion`, see [[inversion]], C02). Ask how you would guarantee failure in this market: assume everyone has a card, a fast connection and their own phone; ignore the rules; recruit users through channels that reach only the already-served. The answers are the checklist.

**Survivorship bias** (`MM-survivorship`, see [[survivorship-bias]], C12). The success stories of new markets (a mobile-money system, an instant-payment rail) are visible because they worked, and the attempts that failed are not told. Draw lessons from a success by asking which of its conditions were specific to the place and time (an operator with large market share, a regulator's stance), and do not assume the model transfers.

**The cold start** (`MM-cold-start`). A product that needs two sides, or a network, is useless until enough of each is present, as in the ride-hailing launch: riders will not come without drivers, and drivers will not come without riders. The usual answer is to win one side first with a subsidy, a partner or a concentrated area, and to say which side and why.

## Engineering, design and data-science perspectives

- **Engineering.** Build and test on the devices and connections the target users have, not on a flagship phone in the office. Ask early about app size, offline behavior, sync after a dropped connection, and which parts of the system touch regulated data (where it is stored, who can read it). A decision about where data lives is expensive to reverse.
- **Design and research.** Work with local researchers and designers who know the languages, scripts and norms. Test text length and layout in every script you will ship, and watch real users on real devices. A flow that tests well in a lab with a good connection may fail at the place of use.
- **Data science.** Measurement is harder where connections drop and many people share a device: events arrive late, and one phone may be several people. Ask how identity is defined (device, account, person) before reading any retention number (C05), and be careful that data from the people you can reach may not describe the people you cannot.
- **Legal, policy and partnerships.** In a new market, licensing, data storage, consumer protection and partner contracts can set the launch order. Involve these colleagues in the first week, since a missing license is a blocker, not a task.

## Checklist: before you recommend a launch or a design for a new market or group

1. Did I name what differs from the home market across the six dimensions, and mark my assumptions?
2. Did I choose a segment inside the market by need and context, not a region as a whole?
3. Did I find the binding constraint and design for it first?
4. Did I decide what to keep, adapt and rethink, and go beyond translation?
5. Did I say how people will find the product and why they would trust it?
6. Did I sketch revenue, cost to serve, cost to acquire and churn, and name the swing assumption?
7. Did I name a regulatory or legal requirement and a way users could be harmed, with a response and a stated limit?
8. Does the metric have a guardrail and a counter metric, and did I say what would change the plan?

## 10. Case studies

#### CS-C09-01 · The learning app and the shared phone · Illustrative · Beginner

*Fictional composite. Every number is invented (invented).*

**Situation.** A video-learning app has done well in its home market and launches in a new country after translating the interface and licensing local-language courses. Eight weeks after launch, 70% of installs are inactive after the first week (invented). The product team believes the cause is the quality of the translation and plans to re-record the narration of the 40 most popular courses.

**Constraints.** A local team of three, a fixed budget for the quarter, and a requirement to keep the cost per active learner low, since revenue per user is small.

**Data.** From the app's logs (invented): the median phone has 1.2 GB of free storage. A ten-minute lesson uses about 90 MB of data when streamed, and a typical monthly data plan among target users is 1 GB, which is about eleven lessons. Sessions often end abruptly when a connection fails. The team interviews 12 households (invented) and visits three of them. In eight of the twelve, one phone is shared by several family members, and learners use it in the evening when the owner is home. Three households download videos at a relative's shop that has Wi-Fi, using a different app. None of the twelve mentions translation quality as a problem. A short survey of the first 400 lapsed installs (invented) finds 41% saying they ran out of data, 24% saying the phone had no storage left and 9% mentioning language.

**Problem definition.** The belief was that translation caused the loss. The evidence points to the product's assumptions: it assumes a personal phone, steady and cheap data, and free storage, none of which holds for many learners. As an observable pain point: "A learner opens a lesson on a shared phone, streams ten minutes of video, uses a tenth of the month's data and runs out before finishing the course."

**Analysis.** The binding constraints from the stack are connectivity cost and shared use, with devices (storage) close behind. The interviews, the visits and the logs agree, and the survey, which could have been shaped by the team's own idea, instead contradicts it: only 9% mention language. The workaround is the evidence: downloading at a relative's shop shows both the need and the route. The riskiest assumption in a fix is that learners would complete courses if the data cost fell, which a cheap test can check. At the current size, a lesson uses 90 MB; a lower-bitrate version at 30 MB would allow about 33 lessons on a 1 GB plan (1,000 ÷ 30), three times as many, and a download over Wi-Fi uses none of the month's data.

**Options.**

| Option | Optimizes | Costs |
|---|---|---|
| A. Re-record the narration of 40 courses | Language quality | A quarter of the budget; does not touch the main cause |
| B. Downloads over Wi-Fi, a low-data video version (about 30 MB a lesson) and profiles for shared phones | Data cost, storage and shared use | About six weeks of engineering; slightly lower video quality |
| C. Cut the price | Affordability of the subscription | Revenue; does not change the data cost |
| D. Partner with local shops that have Wi-Fi to offer lesson downloads | Distribution and trust | Partner management; slower to scale |

**Tradeoffs.** B directly addresses the observed constraints and gives up some video quality. D builds on what households already do and brings a trusted face to the product, at the price of operations. A addresses the team's belief and the smallest share of the data. C is a pricing move that leaves the data constraint in place.

**Decision.** Build B, and pilot D with ten shops. Primary metric: the share of installs that are active learners in week four (baseline 14%, invented), which avoids counting the first-week drop twice. Input: lessons completed per active learner and megabytes used per lesson. Guardrails: crash rate and the share of lessons that fail to start. Counter metric: the share of users who switch profiles more than three times in a session, which shows whether sharing is being handled or made awkward.

**Outcome.** In this fictional scenario, inactivity after the first week fell from 70% to 52%, and the share of installs that were active in week four rose from 14% to 26% (invented). Learners using downloads completed more lessons per week than streamers, and the shops in the pilot brought in 15% of new installs (invented). The narration budget was kept for later use on the five courses that the data showed learners abandoned for content reasons.

**Alternative outcomes.** If activity had not moved after the downloads shipped, the team would have returned to the households to learn what else stopped learners, perhaps the evening availability of the phone. If profiles had confused users, they would have moved to a simple code on each learner's first screen. If the shop pilot had struggled, a carrier partnership would have been the next test. The lesson is the method: when your own belief gives the answer and your fieldwork gives another, trust the fieldwork, and check the constraints of the user's situation before the quality of the content.

#### CS-C09-02 · Kenya, 2007: M-Pesa and the product that changed course · Verified · Advanced

*Sources (types): a first-person account by the pilot's leaders, Nick Hughes and Susie Lonie, "M-PESA: Mobile Money for the 'Unbanked': Turning Cellphones into 24-Hour Tellers in Kenya," *Innovations: Technology, Governance, Globalization* 2(1-2), 63 to 81 (MIT Press, 2007; doi 10.1162/itgg.2007.2.1-2.63), read in full (primary); an overview by Financial Sector Deepening Kenya (a development-sector organization, 2009); the World Bank working paper "Mobile Payments Go Viral: M-PESA in Kenya" (2010); two NBER working papers on M-Pesa ("Mobile Money: The Economics of M-PESA" and "Mobile Banking: The Impact of M-Pesa in Kenya"), which cite Safaricom's figures; and a case summary by the Centre for Public Impact. The analysis is the author's. This is a design analysis from public information and does not claim knowledge of internal decisions beyond the published accounts. Re-read in October 2026.*

**Situation.** Safaricom, Kenya's largest mobile operator and partly owned by Vodafone, developed a mobile-money service, with Vodafone owning, hosting and developing the platform, with funding support from the UK's Department for International Development (a matched grant from its Financial Deepening Challenge Fund of nearly £1 million, matched by Vodafone), in partnership with a microfinance institution, Faulu Kenya, and a commercial bank, the Commercial Bank of Africa, which held the customers' money `[V: Hughes and Lonie, 2007]`. Its first concept was a way for microfinance borrowers to receive and repay loans using the operator's network of airtime resellers as agents, which would cut the cost of handling cash for lenders. During pilot use in and around Nairobi, customers were also sending money to one another. The pilot began on 11 October 2005 with eight agent stores and nearly 500 clients. Its leaders concluded that a mass-market launch with a microfinance institution would be too complex, and built the launch around the proposition "Send Money Home", with three features: cash deposit and withdrawal at agents, person-to-person transfer and prepaid airtime. Safaricom launched it commercially in March 2007 `[V: Hughes and Lonie, 2007]`.

**Constraints.** As documented or reported: in 2007 there were no regulations that applied to a mobile-money service, so the Central Bank of Kenya had to be engaged: after product demonstrations, documentation and a formal legal opinion it confirmed that it had no objection, and the service launched ten days after receiving that letter (Hughes and Lonie). The service needed places where people could turn cash into electronic value and back, and agents hesitated at first to pay out cash, which the project leaders say they solved by giving agents separate cash floats and head-office reassurance (Hughes and Lonie). The service had to work on the basic handsets customers already had, since smartphones were not abundant in Kenya, so the designers chose text messages and a menu on the SIM card (Hughes and Lonie). Safaricom's subscriber base had grown from a few thousand five years earlier to about 5 million by the pilot, and its several hundred airtime dealer outlets became the first agents, which reduced the cost of reaching customers (Hughes and Lonie).

**Data.** From the pilot, as the leaders' account describes: loan repayment was the intended use, and person-to-person transfers emerged in practice. From the launch: over 20,000 customers registered in the first month, ahead of expectation (Hughes and Lonie). Safaricom's own figures, as cited in the World Bank and NBER papers, show over 1.1 million registered customers within eight months of the March 2007 launch and about 8.5 million by September 2009; the World Bank paper gives the internal launch target as about 1 million customers within a year, (Vodafone's own 2017 account by Michael Joseph, who led Safaricom at the launch, says the original business plan aimed for 350,000 customers at the end of the first year and that he pushed the team to aim for a million, and reports 1.2 million customers at the end of the first year; other sources give higher first-year counts, so figures for the first twelve months vary by source) `[V: World Bank working paper, 2010; NBER working papers; Vodafone, 6 March 2017]`. Agent locations grew from about 450 in mid-2007 to over 18,000 by April 2010, and the 2009 FinAccess survey found that 40% of Kenyan adults had used the service `[V: NBER working papers; Financial Sector Deepening Kenya]`; the Centre for Public Impact reports about 40,000 agent outlets in April 2016, while Safaricom's own ten-year release counts more than 101,000 agents at the end of March 2016, so agent counts differ by what is counted `[V: Centre for Public Impact; Safaricom, 'Kenya Marks 10 Years of M-PESA']`. The service was marketed around sending money home (Financial Sector Deepening Kenya).

**Problem definition.** *The author's reading.* The designers' original problem was the cost of handling cash for microfinance repayment. The behavior in the pilot showed a different pain point: moving money to relatives across distance, which the sources describe as common, depended on informal channels (sending cash with someone travelling by bus, or costly formal services such as Western Union with few outlets in rural areas) and was costly, slow or risky `[V: Hughes and Lonie, 2007]`. As an observable pain point: "A person who wants to send money to a relative in another town must carry it, send it with someone, or travel."

**Analysis.** *The author's analysis.* Read through this chapter's frameworks, the case is a clear example of discovery without an existing market (C09.2): the team's plan was not confirmed by surveys but by what people did with the pilot. The team observed a workaround (people using the service to send money to each other) and followed it. The binding constraints from the stack were payments (cash was the endpoint, and the system had to turn cash into value and back), trust (a person gives cash to a stranger and expects a relative to be able to collect it) and devices (the service ran on the phones customers had). The design answered each: the agent network provided cash in and out, and it was a trust signal because the agents were shopkeepers customers already knew. The problem at the start (agents not wanting to hold cash) was solved with a change to the operator's design of floats, which is the kind of operational detail that a PM should expect to own. The distribution advantage was the operator's existing subscriber base and airtime-reseller network, which turned a costly step (reaching people and places) into something nearly pre-built. Regulation appears as a prerequisite that was handled by engagement and not by waiting.

The case also carries a caution. It is a survivor: the factors that mattered (an operator with a large share of subscribers, a regulator willing to let a pilot proceed, a dense network of small shops, a real remittance need) were particular to Kenya at that time. The same design in a market without them could have failed, and this case does not show that it would transfer.

**Options.** *The author's reconstruction of choices a team could have faced; not a record of the company's deliberations.*

| Option | Optimizes | Costs |
|---|---|---|
| A. Launch as designed, a loan disbursement and repayment tool for microfinance | The original plan and the partner's need | Ignores the behavior seen in the pilot; narrow use |
| B. Re-target to person-to-person transfers, using the same agents | The need observed in practice, reach through the existing network | New marketing and risk; regulatory ambiguity |
| C. Build a bank-style account requiring branches | Familiar financial product | Branches are the bottleneck the service was meant to avoid |
| D. Wait for regulation before launch | Legal certainty | Delay, and the opportunity to learn from live use |

**Tradeoffs.** B follows the evidence and uses the strongest asset (the agent network), at the cost of regulatory uncertainty and of operating a service for which the rules did not yet exist. A would have been simpler and narrower, C leaned on the bottleneck, and D traded learning for certainty.

**Decision.** As documented, Safaricom changed the service from a loan-repayment tool to a general money-transfer service and launched it commercially in March 2007 `[V: Hughes and Lonie, 2007]`.

**Outcome.** Reported: strong early adoption, over 1.1 million registered customers within eight months, over 18,000 agent locations by April 2010, use by 40% of Kenyan adults by the 2009 FinAccess survey, and additional services built on the platform `[V: NBER working papers; Financial Sector Deepening Kenya]`. Whether the success was caused by the design, by the operator's reach, by the regulatory stance, or by timing is a separate question that this case does not settle.

**Alternative outcomes.** *Inference.* Had the team treated the pilot's person-to-person use as misuse and held to the loan product, the service might have stayed small. Had agents refused to hold cash, the network would have stalled, which is why the float fix mattered. Had the regulator objected, the launch could have been delayed or changed in form. The method to carry away: observe what people do with a first version, follow the workaround, build the distribution and trust the product needs (not only the interface), and treat the rules as part of the design.

## 11. Interview questions and model answers

Seven questions: two Beginner, two Intermediate, three Hard. Model answers are `Illustrative`; every figure is an assumption. Each is written against the six behaviors in section 1 and uses the spine in FW-C09-01. The answers are fuller than the first pass of a real round; a spoken version keeps the same order with fewer words. Where a real company or country is the setting, the answer reasons from user needs and public information and states no internal fact. Market facts that may change carry verify marks.

#### IQ-C09-01 · Beginner · product design · PS

**Prompt.** A messaging app wants to grow in a country where many users have phones with very little free storage. What do you change?

**Rubric.**
- **Baseline:** "Make the app smaller," with no reasoning about who is affected or how storage is lost.
- **Strong:** Identifies how the storage problem shows up for users, chooses a segment, offers different kinds of move and recommends one with a metric.
- **Standout:** Sees that received media, not the app, is the main consumer of storage, protects users who want to keep media, links storage to data cost, and states what would change the plan.

**Model answer.** I'll state assumptions first, since I know this only in general terms: many phones have under about 1 GB of free storage, and these users are a sizable share of the target market. I'd verify that with device data on free storage at install and at uninstall.

*Segment.* Users on phones with little free space. I choose them over users with ample storage because they are the ones losing the product. I give up users on high-end phones, who have no problem.

*Problem.* A user's phone warns that storage is nearly full, and the easiest thing to delete is the largest app, or its media. The app is the first to go. Received photos and videos from large groups fill space quickly, and re-installing costs data. The workaround is the evidence: deleting the app and reinstalling later, or deleting media by hand.

*The four moves.* Fix: make the app and its updates smaller (updates that send only what changed). Add: a storage manager that shows what uses space by chat and clears it in one tap. Remove: stop automatically downloading video over mobile data by default. Reposition: offer a "lite" version. I recommend the Add and the Remove together: a storage manager and a default that downloads media on request, which saves storage and data cost at once. The Fix is useful and smaller in effect, since the app is a minor share of what fills the phone.

*Constraint scan.* Legacy users: people who like to keep every photo must be able to, so media they star is never cleared automatically, and nothing is deleted without a clear choice. Ecosystem: media removed from the phone should remain retrievable from the sender or the cloud where the product offers it, so nothing is lost for good.

*Size.* Assume 100,000,000 users and 30% storage-constrained: 30,000,000. Monthly uninstall rate is 12% for them against 4% for others (invented). If the change cuts the excess in half (4 points), that is 1,200,000 fewer uninstalls a month; with a 30% haircut, 840,000.

*Metrics.* Primary: 30-day retention among storage-constrained users. Input: the share who open the storage manager. Guardrails: media delivery success and the rate of "media not found" reports. Counter metric: the rate at which users complain about lost media, which would show that the default is too aggressive. I'd change my mind if the uninstall data showed that few exits followed a storage warning, in which case the cause is elsewhere.

**Follow-ups.**

- **Q.** What if users say they want to keep all received media on the phone? **A.** "Then the design should give them control, not decide for them. Deleting automatically would break a real need, so I would make a storage view that shows the largest chats and media by size, offer suggestions such as media older than 90 days that is already backed up, and let the user choose what to clear. I would keep a one-tap restore from a cloud copy or the sender where it is available. The measures are the share of low-storage users who free space with the tool and, as a guardrail, the rate of complaints about lost media. The default should protect media, and the tool should make space cheap to recover."
- **Q.** How does storage relate to data cost, and how would you use that? **A.** "Both are scarce for these users, and media is the main driver of each. Auto-downloading photos and videos uses data and storage at once. I would let the user choose automatic download by network type (Wi-Fi only, always, never), show an estimate of data used by media each week, and compress by default with a choice of quality. I would measure data used per active user and storage freed, with message delivery success as the guardrail. If many users choose Wi-Fi only, that tells me the default should change for this market."

#### IQ-C09-02 · Beginner · product design · DI

**Prompt.** You have two weeks and a small budget to learn whether people in a market you have never visited would use a savings product. What do you do?

**Rubric.**
- **Baseline:** "Run an online survey and ask whether people would use it."
- **Strong:** Studies today's workarounds, uses local researchers, observes behavior, and sets a decision rule before starting.
- **Standout:** Corrects for biases specific to the setting, tests with a commitment and not an opinion, spots the licensing issue in handling people's money, and says what would stop the project.

**Model answer.** I'd use the discovery plan (FW-C09-04). The decision this informs is whether to build a savings product for this market and for whom. I'd write the rule before I start: proceed if there is a widespread workaround that costs people something real, and if enough people show a behavior and not only an opinion.

*Week 1: workarounds, proxies and fieldwork.* I'd hire a local researcher, since they know the language and norms and will be trusted. I'd expect informal savings (groups that pool money, a shopkeeper or relative who holds cash), and I'd ask about the last time a person set money aside, where it went and what went wrong. I'd also look at proxies: how people top up their phones tells me how they handle small sums, and how they send money tells me about trust and distance. I'd visit three places (a market, a workplace, a neighborhood), speak to about 12 people, and watch what they do, not only what they say.

*Week 2: a cheap behavioral test.* A concierge test: with a licensed partner, because holding other people's money without a license is not something I can do informally, a local agent collects small deposits from 20 people for four weeks and records them in a notebook, with a simple receipt in the local language. The signal is deposits made, not interest expressed.

*Biases to correct.* Politeness: people may say they would use it to please a visitor, which is why I ask about behavior. Interviewer effects: a local researcher who is not visibly senior. Sampling: an online survey or a phone survey would miss people without a phone, so I'd reach people in person. Translation: I'd have the questions translated and translated back.

*Decision rule.* Proceed if at least 12 of the 20 deposit in at least three of the four weeks (invented), and if interviews show that today's workaround costs people through fees, loss or risk. Stop or reshape if people save but prefer the informal route for reasons of trust that a product cannot change. What I would not conclude: that the market "is not ready." If the test fails I'd find the reason.

**Follow-ups.**

- **Q.** How do you correct for biases specific to a market you have never visited? **A.** "I would hire a local researcher and let them shape the plan, because they know the language, the norms and the social dynamics of an interview. Typical biases here: respondents telling a foreigner what they think is polite (courtesy bias), a sample drawn from the people who are easiest to reach, who tend to be more educated and urban, and questions that do not translate. I would interview in the local language, include people from different incomes and from outside the capital, ask about what they did last month and not what they would do, and compare what they say with what the proxies show."
- **Q.** What commitment test would you use, and what would stop the project? **A.** "A test that asks for something real, such as a pilot in which 30 people deposit a small amount of their own money through an existing local mechanism and a local partner holds it, with consent and with the licensing question checked first. Proceed if at least 40% of invited people deposit and at least half make a second deposit within a month; stop if under 15%, or if the license route is closed or would take longer than the project can support. Handling people's money is regulated, so legal advice comes before any live money, not after."

#### IQ-C09-03 · Intermediate · product design · PS · Google

**Prompt.** Design a feature for a video app for people whose connections are unreliable and whose data is expensive.

**Rubric.**
- **Baseline:** "A lower-quality mode."
- **Strong:** Names the binding constraint, ranks the pain points, offers different kinds of solution, and handles storage and data use.
- **Standout:** Considers the effect on the people who make the videos, uses offline behavior as the primary design, protects users who want autoplay and quality, and sets guardrails on data use and storage.

**Model answer.** I'll assume the existing app on mid-range phones, and a goal of more watching by people who now watch little or not at all because of cost and connection quality. Role: a core product that people choose for entertainment and learning. I know this only from public information.

*Segment.* Viewers on a monthly data cap, on connections that drop, who commute or live where signal is poor. I give up viewers on home Wi-Fi, who have no issue.

*Constraint stack.* Connectivity binds: cost and reliability. Devices follow: storage is limited, so downloads must be managed. Shared use and payment are secondary.

*Pain points.* (1) A video buffers or fails mid-way and the data used is lost. (2) Autoplay and high default quality use the plan without the user choosing to. (3) The user cannot tell how much data a video will use. (4) Storage fills with downloads. I choose (1) to (3), which together are the data problem.

*Solutions.* Assist: show the data used per hour and an estimate before playing. Automate: smart downloads of videos that the user is likely to watch, fetched on Wi-Fi overnight. Reframe: treat Wi-Fi as the place where the library is filled and mobile data as the exception. Remove: turn autoplay off on mobile data by default. Connect: let a friend share a downloaded video directly between phones. I recommend smart downloads with the data display and autoplay off on mobile data. They address the cause (data use at the wrong moment and place) and use an existing habit.

*Constraint scan.* Legacy users: those who like autoplay keep a setting, and quality stays high on Wi-Fi. Ecosystem: downloaded videos must expire and respect rights, and people who make videos earn from views, so offline views have to be counted and credited. Storage: downloads are capped and cleared with a simple rule, such as removing the oldest watched ones first.

*Metrics.* Primary: watch time per month among capped users. Input: the share of watch time served from downloads. Guardrails: megabytes used per watched hour, and the share of downloads that expire unwatched, which measures waste. Counter metric: uninstalls linked to a full storage warning. I'd change my mind if capped users said their main problem was the cost of the plan itself, in which case a carrier partnership is the first move.

*Company note.* Google is the setting only: `Inferred` from candidate reports that prompts at Google often concern its products for users with limited connectivity `[unverified: candidate-reported]`. No Google data or product behavior is claimed.

**Follow-ups.**

- **Q.** How does the design affect the people who make the videos? **A.** "Creators lose views if low-bandwidth viewers get a lower-quality default or cannot find their videos offline. I would keep the original upload quality available, give creators a view of how many viewers watched in a data-saving mode, and make sure that offline downloads still count as views and credit the creator. A guardrail is the change in view counts and watch time for creators in these markets. If the feature raises viewing by new users and lowers creators' earnings, it needs a fix before it expands, since creators are the supply side of the product."
- **Q.** How do you protect users who want autoplay and full quality? **A.** "By making data-saving a choice with a clear default for people on a cap, not a loss for everyone. The setting would offer Standard, Data saver and Offline-first, with an estimate of data per hour for each, and the user can change it at any time. For someone on home Wi-Fi the app should not degrade the picture. I would measure watch time and the share of users who switch settings, and set guardrails on data used per session and on storage used by downloads, with an easy way to clear them."

#### IQ-C09-04 · Intermediate · product design · PS · Stripe

**Prompt.** A payments company wants to help small online merchants in a new country. How do you decide what to build first?

**Rubric.**
- **Baseline:** "Support the local currency and the most popular cards."
- **Strong:** Ranks payment methods by the share of payments they carry in the target segment, considers the licensing lead time, and builds in phases.
- **Standout:** Treats licensing, verification and data storage as part of the product, finds the revenue model the market allows, and says how to learn quickly while the license is pending.

**Model answer.** I'll assume a company with a payments platform elsewhere, and a goal of a first cohort of merchants taking payments reliably. Country details are assumptions: I'd verify them with public data on payment methods and with interviews.

*Segment.* Small merchants who sell through social media and chat and take orders without a website, over established stores that already integrate gateways. They have the most pain and the least service. I give up the developers and stores where our existing product fits, and I'd serve them with the same platform later.

*What the market uses.* Assume, for the target segment's sales by value (invented): bank transfers through a local QR system 55%, cash on delivery 30%, cards 15%. These numbers drive the ranking.

*Options.*

| Option | Share of target sales covered | Time to market | Risk |
|---|---|---|---|
| A. Cards first (our existing capability) | 15% | Short: about two months | Low, and a small market |
| B. The local bank-transfer method | 55% | Longer: about six months, with licensing | Medium: regulation and a new integration |
| C. Cash-on-delivery support and reconciliation | 30% | Medium | Medium: the cash is collected by a third party |

*Recommendation.* I recommend B as the main build, since it carries the most sales, with the licensing and verification work started in week one because it has the longest lead time. In parallel I'd launch A to a small group of merchants who also sell abroad, to learn about onboarding, settlement and support, which would otherwise wait six months. C comes next, built as a reconciliation tool that matches courier-collected cash to orders. This gives up an early broad launch.

*Beyond methods.* Merchant verification in local terms (a tiered process with lower limits at first, so honest sellers without formal papers are not excluded), data storage in the country if the rules require it, settlement timing in local business days, and a dashboard in the local language. Revenue: I'd check whether the local method carries a merchant fee by policy; if it does not, I'd price the software (reconciliation, invoices, reports) and earn on the minority of payments that allow a fee `[V: merchant-fee FAQs of 15 September 2026: a fee applies from 15 October 2026 to merchant payments above 2,000 rupees]`.

*Metrics.* Primary: the share of target merchants able to accept their most-used method, and the share of payment attempts that succeed, by method. Input: time from sign-up to first payment. Guardrails: fraud and dispute rates, and settlement delay. Counter metric: the share of merchants who keep using their old method in parallel after three months, which shows a gap. I'd change my mind if interviews showed that cash on delivery was the dominant pain, in which case C would move first.

*Company note.* Stripe is the setting only: `Public` that Stripe publishes documentation on local payment methods and `Inferred` from candidate reports that prompts ask how to prioritize payment methods and compliance in a new country `[V: Stripe docs, Supported payment methods; the prompt descriptions remain candidate-reported]`. No Stripe data or roadmap is claimed.

**Follow-ups.**

- **Q.** How do you learn quickly while the license is pending? **A.** "By separating what needs the license from what does not. Before approval I can run merchant interviews, build the onboarding and verification flow in a sandbox, test the dashboard and reporting with merchants using test money, and sign a banking or licensed partner who can process live payments under their license. I would write the plan with the regulator's timeline in view and set a decision date: if the license route takes more than, say, 12 months, move to the partner model for launch. The aim is to have a tested product and a first cohort ready the day the license arrives."
- **Q.** How would you find a revenue model the market allows? **A.** "By checking what fees are permitted, what merchants already pay and what they will pay for. Many small merchants resist percentage fees on low-margin sales but pay for working capital, faster settlement or tools that save time. I would test pricing in interviews with a commitment (a signed letter of intent) and compare the fee against local alternatives, such as cash on delivery costs. I would also check whether regulation limits the fee or requires disclosure. The first cohort's unit economics, with the cost of verification included, would tell me whether the model works at a small scale."

#### IQ-C09-05 · Hard · product design · PS · Apple

**Prompt.** Launch a mobile wallet in a market where card use is low. (Use India as the worked case.)

**Rubric.**
- **Baseline:** "Build a wallet where users can store money and pay at shops," with no analysis of what people use instead.
- **Strong:** Tests the premise by asking what people use in place of cards, identifies the rival, chooses a segment and designs around regulation and trust.
- **Standout:** Sees that a free interoperable rail changes what a wallet can offer, competes on what a device maker can uniquely provide (security, setup, integration across devices, privacy) and not on a new balance, and handles revenue, regulation and distribution.

**Model answer.** I'll test the premise first: "card use is low" does not mean people lack ways to pay. It means the way they pay is something else, and the answer depends on what. In India that is largely interoperable account-to-account transfers through the Unified Payments Interface (UPI), scanned from a QR code or approved in a payment app `Public` `[V: reference summaries of NPCI]`. Many different apps connect to the same rail, and merchant payments from bank accounts have carried no merchant fee by policy since 2020, with a 0.4% merchant discount rate (capped at ₹300) on merchant payments above ₹2,000 from 15 October 2026 `[V: merchant-fee FAQs of 15 September 2026, as reproduced by FinTech BizNews]`. So the rival is not cards; it is free, interoperable and already habitual. A new wallet with a stored balance of its own has to beat that, and it has no natural advantage.

*Goal and company.* I'll assume a device maker, so the setting is a phone, a watch and the services around them, and the goal is that the device becomes the way people pay, which strengthens the whole ecosystem. I know this only from public information, and nothing here describes any existing product.

*Segment.* By behavior: urban smartphone owners who pay in shops several times a day; people who have a bank account but no card; people new to digital payments in smaller towns. I choose the first, because the frequency is high, they have capable devices and the habit is established, so the switching question is clear. I give up first-time digital payers, who need a different, assisted design, and I'd treat them as a later segment.

*Constraint stack.* Payments bind: the dominant rail decides everything. Trust follows: people entrust money to an app, so the app's identity, security and dispute route matter. Regulation sets the order of work: payment intermediaries need authorization, and payment data must be stored in India (the Reserve Bank of India's 2018 directive) `Public` `[V: RBI FAQ, 2019; RBI payment aggregator directions, 2025]`, and general data-protection rules apply (the DPDP Act, in phases) `[V: law-firm summaries of the DPDP Rules]`.

*Options.*

| Option | Idea | Assessment |
|---|---|---|
| A. A closed wallet with its own balance | Users load money; pays within the wallet | Competes with free interoperable apps; needs licensing; no reason to switch |
| B. A front end to the interoperable rail | The wallet lets users pay from their bank accounts through the rail, with the device's strengths | Fits the market; differentiates on trust, ease and security |
| C. A pass wallet for tickets, transit and loyalty cards | Not payments; passes and identity | Lower regulatory burden; a smaller first step |
| D. Stay out of payments | Focus on identity and passes | Safe and passive |

*What a device maker adds.* On-device authentication (a fingerprint or face check), secure storage of credentials, a quick setup that finds the user's existing bank account, a tap or a scan that works the same on a phone and a watch, and a privacy stance (what stays on the device and what the company never sees). These are reasons to prefer the device's wallet that do not require a new balance.

*Recommendation.* I recommend B with C: a wallet that connects to the interoperable rail through an authorized app provider and a partnership with banks, plus passes for transit and tickets as a second use. It gives up the control of a closed wallet and a revenue stream from float, and gains fit with how people pay. Revenue is indirect (a stronger ecosystem) and perhaps from services, since a fee per payment is limited on this rail (none up to 2,000 rupees; 0.4% above that from 15 October 2026) `[V: merchant-fee FAQs of 15 September 2026, as reproduced by FinTech BizNews]`. Distribution: bank partnerships and merchant acceptance through QR codes that merchants already display. Next I'd add the watch and assisted setup for first-time users.

*Metrics.* Primary: the share of eligible users who complete setup and make a first payment within seven days. Input: the share of setups that succeed on the first try. Guardrails: payment success rate, fraud losses and time to resolve a dispute. Counter metric: users who set the wallet up and go back to their previous payment app within a month, which shows whether it adds anything.

*Risks and limits.* Regulation could delay the start, so authorization and data storage begin first. Trust: a failed payment with no clear dispute route loses a user for good. I would not launch without a dispute route and clear refund rules. I'd change my plan if research showed that the habit was so strong, and the free apps so good, that setup alone would not move people; then C becomes the product.

*Company note.* Apple is the setting only: `Public` that Apple publishes a privacy position and designs hardware and software together, and `Inferred` from third-party reports that wallet and payments prompts test local-rail understanding and privacy `[V: Apple privacy pages and integrated hardware, software and services; the prompt descriptions are candidate-reported]`. No claim is made about any existing Apple product or its availability in any country.

**Follow-ups.**

- **Q.** What can a device maker offer that an existing payments rail and its apps do not? **A.** "Not a new balance or a new rail; that would compete where the free rail is already strong. What it can offer is what only a device maker controls: secure hardware that makes payment approval easy and safe, a fast setup that links an existing bank account in a minute, integration across the user's phone, watch and computer, and privacy features such as not sharing the full account number with the merchant. The measures are setup completion, repeat use at a merchant within 30 days and fraud rate, with a guardrail on failed payments. I would verify these capabilities against the rail's rules before promising them."
- **Q.** How would the wallet earn revenue and handle regulation and distribution? **A.** "Revenue cannot rely on a fee on a rail that is free for users, so it would come from adjacent value: device sales and retention, paid services, or merchant-side services where the rules allow. I would check what regulation says about who may charge what, who must hold a license and where payment data must be stored `[V: RBI payment aggregator directions, 2025; RBI storage directive FAQ]`. Distribution is the strength of a device maker: pre-installed on the device and tied to account setup. The risk is a regulator treating a gatekeeper's wallet differently, so I would plan to work with the rail's operators and publish how the wallet interoperates."

#### IQ-C09-06 · Hard · product design · PS

**Prompt.** Design a short-term credit feature for delivery workers whose income is irregular. How do you avoid harming them?

**Rubric.**
- **Baseline:** "A quick loan with a clear interest rate," with no analysis of harm.
- **Strong:** Identifies the real need, designs a product that fits irregular income, and names the risk of a debt cycle with design responses.
- **Standout:** Sets a written limit and a stop rule, measures repeat borrowing as a harm signal, protects data and consent, and notes the conflict of interest in a platform lending to its own workers.

**Model answer.** I'll start with the check (FW-C09-07), because for credit the harm question shapes the product. The user is described by what products lack for them: delivery workers who are paid per job, whose earnings vary week to week while costs (fuel, repairs, a phone bill) come on fixed dates. The need is bridging a gap of a few days. Existing options are informal lenders or loans with high fees and fixed monthly repayments that do not fit irregular income.

*Design.* An advance against earnings already scheduled to arrive, repaid automatically from those earnings, with a flat, stated fee and no compounding interest. A cap: an advance may be at most a set share of average weekly earnings (say 30%, invented). No rollover: an advance cannot be extended or refinanced, and a new one cannot be taken until the last is repaid. The price is shown in the local language before the person agrees, as a single figure and in the effective annual cost, with a clear way to say no. Support is by voice as well as text.

*Harm signals.* The main risk is a debt cycle: a worker takes an advance every week because the last one left a gap. I'd measure the repeat-advance rate, the share of users who take a new advance within seven days of repaying, and treat a high rate as a sign that the product is creating dependence, not bridging a gap.

*Metrics.* Primary: the share of users who repay on time and do not take another advance within seven days. Guardrails: the effective cost of the fee, complaints, and the share of earnings taken by repayment. Counter metrics: the repeat-advance rate and the share of users who use it every week. Stop rule: if more than 25% of users take an advance in each of eight consecutive weeks (invented), I'd stop growth and redesign, since that pattern signals dependence.

*Conflict of interest and data.* A platform that employs the worker and lends to the worker has more power than an ordinary lender. Repayment from earnings makes repayment safe for the company and can leave the worker with too little, so the repayment share is capped. The platform's earnings data is used to decide the limit, and the worker must understand and agree to that use; the data is not sold or used for other purposes.

*Regulation.* Lending usually needs authorization and consumer-protection compliance, and details vary by country `[as of 2026-10]`, so I'd involve legal teams first or partner with a licensed lender.

*My limit.* I would not launch credit with fees that trap people in repeated borrowing, with hidden or rolling charges, or with collection methods that shame or threaten, even if that version grew fastest. I'd change my plan if the first cohort showed that most advances were repaid and not repeated; I'd widen the cap carefully, and if the opposite, I'd not launch at scale.

**Follow-ups.**

- **Q.** What written limit and stop rule would you set? **A.** "Limits in advance: an advance no larger than a stated share of the worker's recent weekly earnings (say 30%), a flat fee that is clear before acceptance with no compounding, and repayment taken as a percentage of future earnings, so a slow week means a smaller repayment. The stop rule: if repeat borrowing (the same worker advancing in more than half of the last eight weeks) exceeds a set share, say 15% of users, or if more than 3% of advances are repaid late, pause expansion and review the product. The rules are written before launch, and changes need sign-off by someone outside the team that earns from the product."
- **Q.** How do you handle the conflict of interest when a platform lends to its own workers? **A.** "By naming it and constraining it. The platform controls the workers' income and could pressure them through the loan, so I would separate decisions: workers cannot be penalized in work allocation for borrowing or not, advance decisions use limited data and not the worker's behavior on the platform beyond earnings, and the data is not used for other purposes. I would give workers an independent complaint route, publish the fees and outcomes, and review the product with an outside adviser. If these protections cannot be met, a partnership with a regulated lender may be better than lending directly."

#### IQ-C09-07 · Hard · product design · PS

**Prompt.** Your product succeeded in its home market and failed in the first country it entered. You have two weeks to write a post-mortem. What do you do?

**Rubric.**
- **Baseline:** "Conclude that the market was not ready and list lessons."
- **Strong:** Separates assumptions from evidence, finds which dimension broke, uses funnel data and interviews, and proposes a decision.
- **Standout:** Compares the new market's funnel step by step with the home one, includes people who left, tests alternative explanations, sets criteria for another attempt or an exit, and avoids blame.

**Model answer.** I'd treat it as a diagnosis with a decision at the end, and I'd refuse the conclusion "the market was not ready" until the evidence earns it. The product has a funnel in both markets, so the first move is to compare them.

*Week 1: evidence.* Day 1 and 2: funnel by step for the new market and the home market, split by device, connection and channel, to find where the new market loses people (acquisition, sign-up, first use, payment, return). Day 2 to 4: the six dimensions as a checklist of what we assumed against what was true: users, infrastructure, regulation, competition, distribution and price. Day 3 to 5: interviews with ten people who installed and left, and five who stayed; calls with the local team and any partners; support tickets by theme. I'd include the people who left, because the success stories are not where the answer is.

*Example of what the evidence might show (invented).*

| Assumption | Evidence | Verdict |
|---|---|---|
| Users have a personal phone | 8 of 12 interviewees shared a phone | Wrong; shared use |
| Card payment works | 60% of payment attempts failed or were abandoned at the card step | Wrong; payments |
| Paid ads will bring users at home-market cost | Cost per install was three times higher and retention was lower | Wrong; distribution |
| Translation is enough | Support tickets about language were 5% of the total | Mostly right |

*Alternative explanations.* A single cause is unusual. I'd ask whether launch timing, a competitor's move, or a technical fault (a payment provider outage) explains part of it, and whether the home market's success depended on conditions that do not exist here (for example, a network effect that needs density).

*Week 2: synthesis and decision.* A short decision memo (FW-C02-06): what happened, which assumptions failed and what the evidence is, what we do not know, the options, and a recommendation. Options: iterate in the same market with specific fixes, narrow to one city or segment, change the model (a partner for distribution or a local payment method), or exit. For each, I'd write the condition that would make it right, such as "continue only if payment success reaches 85% and week-four retention reaches 20% within a quarter (invented)."

*Blame and learning.* I'd write the post-mortem about decisions and information, not about people, and I'd hold a pre-mortem (FW-C02-05) for any second attempt: assume it failed in a year and ask why. I'd also record what worked, since a failed entry usually contains a part that did. I'd change my recommendation if the funnel showed that most of the loss happened before the product was even seen, in which case the question is distribution and not the product.

**Follow-ups.**

- **Q.** How do you compare the new market's funnel with the home market's? **A.** "Step by step, with the same definitions, split by device, connection and channel. Acquisition, sign-up, first use, payment and return are the steps; I would find where the new market loses people compared with home: for example 60% of sign-ups complete the first task at home against 25% in the new market, concentrated on low-end phones. Then I would interview people who left at that step, and not only active users. This turns "the market was not ready" into a specific, testable finding: a step, a segment and a cause, such as slow load times or an unavailable payment method."
- **Q.** What criteria would you set for another attempt or an exit? **A.** "Written in the post-mortem, with numbers. For another attempt: the failure step is identified with evidence, a fix is feasible within a stated budget and time, and a small test can show a result, for example reaching a first-week completion of 50% in a pilot of 5,000 users within three months. For an exit: no segment shows at least a threshold of retention, the cost to fix exceeds the expected return, or the license or payment route is unavailable. The post-mortem avoids blame by describing decisions in light of what was known then and what the team would do differently now."

## 12. Exercises

Ten exercises. Each has a model solution and an alternative. Figures are assumptions unless marked.

#### EX-C09-01 · The six-dimension scan

**Problem.** A food-delivery app from a large, card-based market plans to launch in a city of five million where, as you assume, many addresses are landmark-based, cash on delivery is common, and couriers ride motorbikes. Fill the market-difference scan and mark the two differences that matter most.

**Context.** You have two minutes in an interview to say what differs.

**Data.** Use the assumptions in the problem, and add your own labeled ones.

**Constraints.** One line per dimension.

**Expected approach.** Use FW-C09-02: assumption, difference from home, what to verify, and a mark on the decisive ones.

**Solution.** Users: customers who order for families and workplaces; verify with ten interviews. Infrastructure: landmark addresses, phones of mid-range quality, variable connections; at home an address is a street number. Regulation: courier and food-safety licensing; verify first. Competition: restaurants' own delivery and phone orders; the rival is the phone call. Distribution: restaurant partnerships and workplace referrals more than app-store advertising. Price: low order value; a delivery fee that is high relative to the meal. Decisive: addresses (the core flow depends on finding the customer) and payment (cash changes settlement and risk).

**Alternative solution.** Mark regulation as decisive if a license is needed before any launch.

**Tradeoffs.** Marking two keeps the answer focused and risks leaving out a decisive dimension; say what you would check to be sure.

#### EX-C09-02 · Find the binding constraint

**Problem.** A language-learning app is launching in a market where, as you learn: 70% of target users share a phone with family; data plans are small; phones have limited storage; people are comfortable reading; payment is by prepaid top-up. Which constraint binds, and what is the first design move?

**Context.** The app currently streams video lessons and requires a personal account.

**Data.** As above.

**Constraints.** Five minutes.

**Expected approach.** Use the stack (FW-C09-03): trace the flow (find, sign up, learn, pay, return) and mark where each constraint stops it.

**Solution.** Shared use stops sign-up and progress tracking (a personal account assumes one person); data and storage stop learning (streaming video uses the plan; storage is limited). Literacy is not binding. Payment can be handled by prepaid top-up. The binding constraints are shared use and data. First moves: profiles on one device with a simple code, and lessons that download over Wi-Fi in a small file size.

**Alternative solution.** Choose data cost as the single binding constraint, since without it no lesson plays, and treat shared use as the next problem.

**Tradeoffs.** A design for the tightest case can reduce quality for people with ample data; allow a richer path where bandwidth exists.

#### EX-C09-03 · Translate, adapt or rethink?

**Problem.** Classify each change as translate, adapt or rethink: (a) interface text in the local language; (b) displaying numbers with lakh and crore groupings; (c) a date format; (d) support for cash on delivery, with reconciliation of cash collected by couriers; (e) identifying users by phone number instead of email; (f) onboarding by a local agent instead of self-service; (g) replacing stock photos with local ones; (h) voice support in the local language; (i) a local legal entity and terms in the local language.

**Context.** You are scoping a launch.

**Data.** None.

**Constraints.** One word each and a line on the launch scope.

**Expected approach.** Use the ladder (FW-C09-05).

**Solution.** (a) Translate. (b) Adapt. (c) Adapt. (d) Rethink: the home model assumed card payment. (e) Adapt, or rethink if email is rarely used and the whole sign-up flow rests on it. (f) Rethink. (g) Adapt. (h) Adapt (a support channel). (i) Adapt, and a prerequisite. Launch scope: translate and adapt everything on the critical path (sign-up, ordering, payment, support), do (d) and (f) if cash and trust are binding, and defer (g).

**Alternative solution.** Treat (e) and (h) as rethink if most users cannot or will not use text.

**Tradeoffs.** Deeper localization costs time and delays learning; shallow localization can break trust at the first payment.

#### EX-C09-04 · Low-revenue economics

**Problem.** A savings app earns $0.50 per active user per month, costs $0.20 a month to serve, and loses 10% of users each month. Acquiring a user through advertising costs $2.50; through a partner network, $1.00. Compute margin, lifetime, lifetime margin, payback and the ratio of lifetime margin to acquisition cost for each channel. Then repeat for 15% churn.

**Context.** The team must pick a first channel.

**Data.** As above.

**Constraints.** Show each step.

**Expected approach.** Use FW-C09-06.

**Solution.** Margin = $0.50 − $0.20 = $0.30. Lifetime = 1 ÷ 0.10 = 10 months. Lifetime margin = $0.30 × 10 = $3.00. Advertising: payback $2.50 ÷ $0.30 = 8.3 months; ratio $3.00 ÷ $2.50 = 1.2. Partner: payback $1.00 ÷ $0.30 = 3.3 months; ratio 3.0. At 15% churn: lifetime = 1 ÷ 0.15 = 6.7 months; lifetime margin = $2.00; advertising ratio $2.00 ÷ $2.50 = 0.8 (loses money); partner ratio 2.0. The advertising route is fragile: a small rise in churn turns it from marginal to unprofitable, and the partner route stays positive.

**Alternative solution.** Compare payback with the expected lifetime directly: advertising pays back in 8.3 of 10 months at 10% churn, and in 8.3 of 6.7 months at 15%, so it never pays back.

**Tradeoffs.** Churn may differ by channel (users from partners may stay longer), which would widen the gap, and the numbers should be checked with a pilot.

#### EX-C09-05 · A discovery plan for street vendors

**Problem.** You want to learn whether street vendors in a city you do not know would accept digital payments. You have two weeks and a small budget. Write the plan using FW-C09-04.

**Context.** The company has no presence in the city.

**Data.** None.

**Constraints.** Five minutes.

**Expected approach.** Workarounds, proxies, fieldwork with local partners, a cheap test, and bias corrections.

**Solution.** Workarounds: how vendors take payment today (cash, a customer's transfer to a personal account, a regular customer's tab), and what it costs them (change, theft, time). Proxies: how they pay suppliers, whether they keep a phone and use it for transfers, how they handle small sums. Fieldwork: a local researcher spends a day at three markets with 12 vendors, watching a busy hour. Cheap test: a printed QR code for the vendor's bank account, with a local partner recording how many customers use it over a week. Biases: politeness (vendors may say yes to a visitor), the busy hour (a vendor cannot talk during it), and selecting only vendors who speak to visitors. Decision rule: proceed if at least a quarter of customers at a vendor use the code within a week (invented) and vendors report a real cost of cash handling.

**Alternative solution.** Start with suppliers and customers: ask what stops them from paying vendors digitally.

**Tradeoffs.** A QR test with a personal account means vendors take payment through an existing rail and says little about a new product; it tests demand for digital payment, which is the first question.

#### EX-C09-06 · Fix the research design

**Problem.** A team surveys a new market by calling randomly chosen phone numbers on weekday afternoons with an interviewer from the capital city, asking, "Would you use a savings app if it were available?" Ninety percent say yes. Name four problems and propose a better design.

**Context.** The team plans to build on this result.

**Data.** The 90% figure.

**Constraints.** Five minutes.

**Expected approach.** Use the biases in C09.2 and FW-C09-04.

**Solution.** Problems: sampling (people without a phone, people who do not answer during working hours, and people who share a phone are missed); interviewer effect (a visitor from the capital invites polite answers); a hypothetical question ("would you use," not "when did you last"); and the lack of a commitment (saying yes costs nothing). Better design: recruit in person at markets and workplaces; use local interviewers; ask about the last time the person saved and what they did with the money; observe a few cases; and offer a small, real commitment, such as signing up for a concierge deposit service, and count sign-ups.

**Alternative solution.** Keep the phone survey but use it only to size what interviews found, with questions about behavior, and report the sample's limits.

**Tradeoffs.** In-person work is slower and costlier than calling, and its results describe people you can actually learn from.

#### EX-C09-07 · Apply the underserved-user check

**Problem.** A shopping app proposes "buy now, pay later" for low-income shoppers, with a late fee. Apply the check (FW-C09-07), decide, and state a limit.

**Context.** Revenue would come mostly from late fees (invented: 70% of the feature's revenue).

**Data.** Late fees are 70% of the feature's revenue.

**Constraints.** Five minutes.

**Expected approach.** Go through access, dignity, exploitation, safety, consent and limit.

**Solution.** *Access:* the feature widens access to goods for people without credit cards. *Dignity:* describe it by what it offers, not as help for the poor. *Exploitation:* a business model in which 70% of revenue comes from late fees profits when customers fail, which is the clearest warning; the incentive must not depend on lateness. *Safety:* repeated late fees can lead to debt and collections. *Consent:* the fee schedule must be shown before purchase, in plain language. Decision: proceed only with a different revenue model, such as a fee paid by the merchant for a larger sale, no late fees beyond a small cap, and credit limits tied to the person's ability to repay. *Limit:* I would not launch if the plan needed more than a small share of revenue from late fees. Stop rule: if more than 20% of users are late in two consecutive months (invented), pause growth.

**Alternative solution.** Do not build it, and say that a product whose economics reward customer failure cannot be made safe by disclosures.

**Tradeoffs.** A safer model earns less per user and may grow slowly; the alternative can harm the people it claims to help.

#### EX-C09-08 · Pick the product shape by payment environment

**Problem.** For a new wallet or checkout, choose a product shape in each environment: (A) cards are widely used; (B) interoperable account-to-account transfers are widely used and free for merchants; (C) mobile-money agents with cash-in and cash-out are the main way to move money.

**Context.** The company is a device maker and a payments platform.

**Data.** None.

**Constraints.** Two sentences each.

**Expected approach.** Find the dominant rail first, then decide what the product adds (C09.4).

**Solution.** (A) Card-based wallet: tokenized cards, device authentication and tap to pay; compete on security and convenience. (B) A front end to the shared rail with the device's strengths (authentication, quick setup, a scan or tap that works on a phone and a watch); do not rely on a fee per payment, and compete on trust, ease and software for merchants. (C) Integrate with the mobile-money operator and its agents: flows that work on basic phones through menus, cash-out at agents, receipts in the local language, and a trust signal from the agent.

**Alternative solution.** In (B), start with passes and identity (tickets, transit) where there is no incumbent, and add payments later.

**Tradeoffs.** Each choice leans on the dominant rail, which brings reach and dependence on whoever runs it.

#### EX-C09-09 · A timed full run

**Problem.** Give a 25-minute answer to: "Launch a fitness-tracking app in a country you do not know well."

**Context.** Self-scored; record yourself. Choose a country or describe a market and say your assumptions aloud.

**Data.** None. Label what you assume.

**Constraints.** Use the short-version budget in section 4: one difference that matters, one constraint, one change per ladder level, one channel, one metric, one limit.

**Expected approach.** Use the full spine (FW-C09-01) and score yourself against the six behaviors in section 1.

**Solution.** An outline of a strong answer. Clarify: an existing app with a free tier; goal: a first cohort that stays. Scan: the decisive differences are devices (many users have no wearable and mid-range phones) and trust and payment (a subscription needs a local payment method). Segment: office workers who walk and run at fixed times, as a context-based segment. Constraint: devices and battery (continuous location tracking drains a mid-range phone).

Shape: translate; adapt units, local sports and festival-based challenges; rethink by tracking steps from the phone's motion sensor, with no wearable needed. Distribution: workplaces and a carrier bundle; economics: low revenue per user, so a sponsor-funded or B2B2C model may be the first source of revenue. Metric: users active in week four. Limit: no location data kept without consent; no health claims.

**Alternative solution.** Choose a different segment (runners with wearables) and say you traded size for fit.

**Tradeoffs.** A phone-only design reaches more people and measures less accurately than a wearable.

#### EX-C09-10 · Handling interventions

**Problem.** Write a one- to two-sentence reply to each interviewer intervention: (a) "What is different about this market?" (b) "How do you know that?" (c) "Who exactly is the user?" (d) "How will people find it?" (e) "Can this make money?"

**Context.** You are partway through an answer about launching a ride-hailing service in a new city.

**Data.** Use any assumptions you state.

**Constraints.** Two minutes.

**Expected approach.** Use the table of interventions in section 4: each points to a missing step.

**Solution.** (a) "Two things matter most: addresses are given by landmark, and most riders pay in cash, so finding the rider and collecting commission are both different from home." (b) "I don't know it; it's an assumption from public information. I'd check it with a local researcher and a week of observation." (c) "Office commuters who today bargain for informal taxis on a regular route, chosen for frequency and a repeated pain." (d) "Drivers through in-person hubs and riders through workplace referrals; both build trust and avoid paying for advertising that few would see." (e) "Per trip I'd expect a margin of about 14.50 on a fare of 150 (invented); it works if pickups succeed and fails if they do not, so pickup success is the number I'd watch."

**Alternative solution.** Record yourself and check that each reply takes under 20 seconds and returns to the spine.

**Tradeoffs.** Short replies keep momentum and can hide nuance; offer more if asked.

## 13. Practice protocol

**Timed drills (three a week for four weeks).**

- *Week 1: the market and the segment.* Take a prompt from the exercises or questions (IQ-C09-01, EX-C09-01, EX-C09-02) and spend ten minutes on the scan, the segment and a criterion. Say which differences are assumptions.
- *Week 2: the constraint and the shape.* Use IQ-C09-02, IQ-C09-03, EX-C09-03 and EX-C09-05. Find the binding constraint, sort changes into translate, adapt and rethink, and write a first version as moments. Twelve minutes.
- *Week 3: economics, regulation and ethics.* Use IQ-C09-04, IQ-C09-05, IQ-C09-06, EX-C09-04 and EX-C09-07. Sketch unit economics by channel, name a rule that sets the order of work, and write a limit. Fifteen minutes.
- *Week 4: full rounds.* Run two 45-minute answers and one 25-minute answer (EX-C09-09) on markets you have not prepared, with a partner who uses the interventions in section 4.

**With a partner.** Ask your partner to interrupt with "How do you know that?" and "Who exactly is the user?" at random points, and once with "Can this make money?" Practice answering in under a minute, and practice saying "that is an assumption, and I'd check it by..."

**Read before you drill.** Read one public source on the market you will practice with (a central bank's payments statistics, a regulator's guidelines, a field report) so that your assumptions rest on something. Label every fact from it with a verify mark.

**Record and review.** Record every full run. Listen once for structure and once for wording. Count how many statements about the market were stated as facts, whether you gave a segment and a binding constraint, and whether you mentioned payments, trust and regulation.

**Feedback checklist (yes, partly, no).**

1. Did I name what differs from the home market and mark assumptions as assumptions?
2. Did I choose a segment inside the market by need and context?
3. Did I find the binding constraint and design for it first?
4. Did I sort changes into translate, adapt and rethink, and go beyond language?
5. Did I say how people will find the product and why they would trust it?
6. Did I sketch revenue, cost to serve, cost to acquire and churn?
7. Did I name a regulatory requirement and a way users could be harmed, with a response?
8. Did I state a limit on what I would not build?
9. Did I avoid stereotypes and describe users by access and context?
10. Did I finish with the two-sentence close from section 4?

**Answer journal.** For each drill record the date, the market, the segment, the binding constraint, the channel chosen, your score out of ten and the step you rushed. After eight drills, find the step you skip most (usually economics or the limit) and drill it alone for a week.

## 14. Implementation playbook

Apply the chapter on real work over the next three weeks. Each deliverable doubles as an interview story, and it works whether or not your product is international: the same questions apply to any group of users whom the product serves poorly.

**Days 1 to 3.** Split one core funnel in your product by country, device type and connection speed, or by any segment you suspect is served poorly. Note the steps where one segment loses far more than the others, and list your guesses about why.

**Week 1.** Test the product on a low-end device or a throttled connection for the core task. Write down every step that is slow, heavy or fails. Share the list with an engineer and a designer and ask which two matter most.

**Week 1.** Talk to a colleague or a user who knows a market or group you do not serve well. Ask about the last time they tried to do the product's task, and what they used instead. Write the workaround down.

**Week 2.** Fill the market-difference scan (FW-C09-02) for a country or group you might serve next, from public sources. Mark each fact as known, assumed or to verify, and bring it to a conversation with someone who knows the place.

**Week 3.** Sketch the unit economics (FW-C09-06) for one channel in your own product: revenue per user, cost to serve, cost to acquire, churn. Name the assumption you are least sure of and how you would check it.

**Deliverables that become stories:** the segmented funnel (a time you found who the product failed and why), the low-end device test (a time you found a constraint before users did), and the scan or economics sketch (a time you planned for conditions you could not see). Keep the numbers real, and keep what you did separate from what the team did.

## 15. Key takeaways and further reading

### Key takeaways

1. A new market changes the conditions a product relies on: users, infrastructure, regulation, competition, distribution and price. Name what differs, mark what you assume, and never treat a region as one market.
2. Find evidence without an existing market by studying today's workarounds, using proxies and local researchers, and testing behavior in one place, with the biases of cross-cultural research in mind.
3. Find the binding constraint (connectivity, devices, payments, trust, literacy, shared use) and design for it first; go beyond translation to adapt and, where the home model fails, rethink.
4. Distribution and economics are part of the product: at low revenue per user, the cost to acquire and serve and the rate of churn decide whether the business works.
5. Design for underserved users by describing what products lack for them, check for exploitation and consent, and state a limit on what you would not build.

### Further reading

- Nick Hughes and Susie Lonie, "M-PESA: Mobile Money for the 'Unbanked': Turning Cellphones into 24-Hour Tellers in Kenya," *Innovations: Technology, Governance, Globalization* 2(1-2), 63 to 81 (MIT Press, 2007). The primary source for CS-C09-02.
- Jan Chipchase, *The Field Study Handbook* (2017), and Jan Chipchase and Simon Steinhardt, *Hidden in Plain Sight* (2013). Practical guides to fieldwork in unfamiliar places.
- Abhijit V. Banerjee and Esther Duflo, *Poor Economics* (2011). A research-based view of how people on low incomes make decisions, useful against stereotypes.
- Daryl Collins, Jonathan Morduch, Stuart Rutherford and Orlanda Ruthven, *Portfolios of the Poor* (2009). How households with low incomes manage money, from financial diaries.
- Nandan Nilekani and Viral Shah, *Rebooting India* (2015). Background on India's digital public infrastructure and the thinking behind its payment systems `[V: Allen Lane (Penguin India), November 2015, ISBN 9780670087891; about technology-led public institutions built on Aadhaar]`.
- Reserve Bank of India, "Storage of Payment System Data" (circular of 6 April 2018), and National Payments Corporation of India, UPI product statistics. Primary sources for the regional facts in this chapter `[V: RBI circular of 6 April 2018, via RBI FAQ]`.
- Kat Holmes, *Mismatch: How Inclusion Shapes Design* (2018), cited in C07, for inclusive design applied to groups that products leave out.
